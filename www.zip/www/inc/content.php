<?php
// Editable text blocks + renderers for rules / staff / vote pages.
function fields(): array { static $f = null; return $f ??= (require __DIR__.'/fields.php'); }

function fv(string $k): string {              // saved value or the original default
    $f = fields(); $saved = settings_load()['texts'][$k] ?? null;
    return is_string($saved) ? $saved : (string)($f[$k]['d'] ?? '');
}
function tok(string $s, bool $html = false): string {   // {site_name} etc.
    $banner = asset(s('news_banner', 'uploads/post_images/season1_banner.png'));
    return strtr($s, ['{site_name}'=>e(s('site_name')), '{server_ip}'=>e(s('server_ip')), '{news_banner}'=>$banner]);
}
function t(string $k): string { return e(strtr(fv($k), ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')])); }
function lines(string $k): array { return array_values(array_filter(array_map('trim', preg_split('/\R/', fv($k))), fn($x)=>$x !== '')); }
function hl(string $s): string {              // **bold**  and  [[highlight]]
    $s = e(strtr($s, ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')]));
    $c = color('primary_color', '#911AEE');
    $s = preg_replace('/\*\*(.+?)\*\*/s', '<strong style="color:#fff;">$1</strong>', $s);
    return preg_replace('/\[\[(.+?)\]\]/s', '<span style="color:'.$c.';">$1</span>', $s);
}
function safe_css_color(string $c): string { $c = trim($c); return preg_match('/^#[0-9a-fA-F]{3,8}$/', $c) ? $c : '#FFFFFF'; }
function safe_url(string $u): string { $u = trim($u); return preg_match('~^https?://~i', $u) ? e($u) : '#'; }

function render_rules_home(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <div id="rule-home">
 <h1 style="color:#fff;font-size:24px;font-weight:600;margin:0 0 6px;"><?= t('rules_title') ?></h1>
 <div style="color:#666;font-size:13px;margin-bottom:22px;"><?= t('rules_updated') ?></div>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('rules_intro'))) as $p): if (trim($p) === '') continue; ?>
 <p style="color:#bbb;line-height:1.7;font-size:14.5px;"><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; ?>
 <p style="color:#bbb;"><strong style="color:#fff;"><?= t('rules_signature') ?></strong></p>
 <a href="https://discord.gg/<?= e(s('discord_code')) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;background:<?= $c ?>;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:500;font-size:14px;margin-top:10px;">
 <i class="fa-brands fa-discord"></i> <?= t('rules_join_btn') ?>
 </a>
 </div>
<?php }
function rules_icons(): array {
    return ['cube'=>'fa-solid fa-cube','discord'=>'fa-brands fa-discord','shield'=>'fa-solid fa-shield-halved','gavel'=>'fa-solid fa-gavel','scale'=>'fa-solid fa-scale-balanced','user'=>'fa-solid fa-user-shield','chat'=>'fa-solid fa-comments','star'=>'fa-solid fa-star','ban'=>'fa-solid fa-ban','heart'=>'fa-solid fa-heart','bolt'=>'fa-solid fa-bolt','flag'=>'fa-solid fa-flag','cart'=>'fa-solid fa-cart-shopping','game'=>'fa-solid fa-gamepad','crown'=>'fa-solid fa-crown','lock'=>'fa-solid fa-lock','fire'=>'fa-solid fa-fire','book'=>'fa-solid fa-book'];
}
function rules_sections(): array {           // saved sections, or the original Minecraft + Discord ones
    $raw = settings_load()['texts']['rules_sections'] ?? null;
    if (is_string($raw)) { $j = json_decode($raw, true); if (is_array($j)) return $j; }
    return [
        ['nav'=>fv('rules_nav_mc'), 'title'=>fv('rules_mc_title'), 'icon'=>'cube', 'intro'=>fv('rules_mc_intro'), 'rules'=>lines('rules_mc_list'), 'note'=>fv('rules_mc_note')],
        ['nav'=>fv('rules_nav_dc'), 'title'=>fv('rules_dc_title'), 'icon'=>'discord', 'intro'=>fv('rules_dc_intro'), 'rules'=>lines('rules_dc_list'), 'note'=>fv('rules_dc_note')],
    ];
}
function tx(string $s): string { return e(strtr($s, ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')])); }
function render_rules_section(int $i, array $sec): void {
    $c = color('primary_color', '#911AEE'); $title = (string)($sec['title'] ?? ''); $intro = trim((string)($sec['intro'] ?? '')); $note = trim((string)($sec['note'] ?? '')); ?>
 <div id="rule-s<?= $i ?>" style="display:none;">
 <h2 style="color:#fff;font-size:22px;font-weight:600;margin:0 0 16px;padding-bottom:10px;border-bottom:1px solid <?= tint(42) ?>;"><?= tx($title) ?></h2>
<?php if ($intro !== ''): ?> <p style="color:#bbb;font-size:14px;"><?= tx($intro) ?></p>
<?php endif; ?>
 <ul style="list-style:none;padding:0;margin:0;">
<?php foreach ((array)($sec['rules'] ?? []) as $li): if (trim((string)$li) === '') continue; ?>
 <li style="padding:6px 0 6px 18px;position:relative;color:#ccc;font-size:14px;"><span style="color:<?= $c ?>;position:absolute;left:0;">•</span> <?= hl((string)$li) ?></li>
<?php endforeach; ?>
 </ul>
<?php if ($note !== ''): ?> <p style="color:#999;font-size:13px;margin-top:14px;"><?= tx($note) ?></p>
<?php endif; ?>
 </div>
<?php }
function render_staff(): void {
    $groups = []; $cur = null;
    foreach (lines('staff_list') as $ln) {
        if (preg_match('/^#+\s*(.+?)\s*(?:\|\s*(#[0-9a-fA-F]{3,8}))?\s*$/', $ln, $m)) { $cur = count($groups); $groups[] = ['name'=>$m[1], 'color'=>$m[2] ?? '#FFFFFF', 'p'=>[]]; }
        elseif ($cur !== null) $groups[$cur]['p'][] = $ln;
    }
    foreach ($groups as $g): ?>
 <div style="margin-bottom:22px;">
 <div style="color:<?= safe_css_color($g['color']) ?>;font-weight:600;font-size:15px;margin-bottom:10px;"><?= e($g['name']) ?></div>
 <div style="display:flex;flex-wrap:wrap;gap:10px;">
<?php foreach ($g['p'] as $name): $n = preg_replace('/[^A-Za-z0-9_]/', '', $name); ?>
 <div class="staff-card" style="background:<?= tint(34) ?>;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;min-width:150px;">
 <?php render_skin_head($name, 32); ?>
 <span style="color:#ddd;font-size:13px;font-weight:500;"><?= e($name) ?></span>
 </div>
<?php endforeach; ?>
 </div>
 </div>
<?php endforeach;
}
function render_vote_links(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <style>.vote-btn,.staff-card{transition:transform .18s ease,box-shadow .18s ease}.vote-btn:hover{transform:translateY(-3px);box-shadow:0 10px 22px rgba(<?= rgb($c) ?>,.38);filter:brightness(1.06)}.staff-card:hover{transform:translateY(-2px);box-shadow:0 6px 14px rgba(0,0,0,.35)}</style>
 <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
<?php foreach (lines('vote_links') as $ln): [$label, $url] = array_pad(array_map('trim', explode('|', $ln, 2)), 2, ''); if ($url === '') { $url = $label; } ?>
 <a class="vote-btn" href="<?= safe_url($url) ?>" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:center;gap:8px;background:<?= $c ?>;color:#fff;text-decoration:none;padding:14px 20px;border-radius:8px;font-weight:600;font-size:14px;"><?= e($label) ?> <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:12px;opacity:0.8;"></i></a>
<?php endforeach; ?>
 </div>
<?php }

function render_news_body(): void { ?>
 <p style="margin:0 0 12px 0;"><img src="<?= asset(s('news_banner', 'uploads/post_images/season1_banner.png')) ?>" alt="" style="width:100%;border-radius:6px;display:block;"></p>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('news_body'))) as $p): if (trim($p) === '') continue; ?>
 <p><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; }

function render_credit(): void {
    if (!s('show_powered_by', true)) return; ?>
<div style="display:flex;justify-content:center;padding:14px 0 22px;position:relative;z-index:50">
 <a href="https://github.com/mrtome101" target="_blank" rel="noopener" title="github.com/mrtome101" style="display:inline-flex;align-items:center;gap:9px;color:#fff;opacity:.6;font-size:12.5px;font-family:inherit;text-decoration:none;padding:6px 10px;border-radius:8px">
 <span>Created by TOME</span><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg></a>
</div>
<?php }
function font_choices(): array {
    return ['default'=>'Original', 'Poppins'=>'Poppins', 'Inter'=>'Inter', 'Montserrat'=>'Montserrat', 'Rubik'=>'Rubik', 'Nunito'=>'Nunito', 'Outfit'=>'Outfit', 'Roboto'=>'Roboto', 'Oswald'=>'Oswald', 'Orbitron'=>'Orbitron (techy)', 'Press Start 2P'=>'Press Start 2P (pixel / Minecraft)'];
}
function render_head_extras(): void {
    $css = '';
    if (!s('show_footer_play', true))  $css .= '.footer .footer-about{display:none!important}';
    if (!s('show_footer_links', true)) $css .= '.footer .footer-col:nth-of-type(2){display:none!important}';
    if (!s('show_footer_store', true)) $css .= '.footer .footer-col:nth-of-type(3){display:none!important}';
    if (s('themed_scrollbar', false)) { $m = color('primary_color', '#911AEE'); $css .= "html{scrollbar-color:$m ".color('bg_color','#101010')."}::-webkit-scrollbar{width:11px}::-webkit-scrollbar-track{background:".color('bg_color','#101010')."}::-webkit-scrollbar-thumb{background:$m;border-radius:8px}"; }
    if ($css !== '') echo "<style>$css</style>\n";
    $f = (string)s('font', 'default'); $ok = font_choices();
    if ($f === 'default' || !isset($ok[$f])) return;
    $fam = str_replace(' ', '+', $f); $w = ($f === 'Press Start 2P' || $f === 'Orbitron') ? '' : ':wght@400;500;600;700'; ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=<?= $fam . $w ?>&display=swap">
<style>body, body *:not(i):not([class^="fa-"]):not([class*=" fa-"]):not(svg):not(path){font-family:'<?= e($f) ?>',system-ui,sans-serif !important}</style>
<?php }

// ---- dark panel colours follow the chosen background (keeps original look on the default theme)
function tint(int $lv): string {
    [$r, $g, $b] = array_map('hexdec', str_split(ltrim(color('bg_color', '#101010'), '#'), 2));
    $d = $lv - 16; $cl = fn($x) => max(0, min(255, $x + $d));
    return sprintf('#%02X%02X%02X', $cl($r), $cl($g), $cl($b));
}
// ---- skins
function skin_key(string $n): string { return preg_replace('/[^a-z0-9_]/', '', strtolower($n)); }
function skin_entry(string $key): ?array {
    $e = settings_load()['skins'][$key] ?? null;
    return (is_array($e) && !empty($e['path']) && is_file(ROOT.'/'.$e['path'])) ? $e : null;
}
function skin_layer(array $e, float $x, float $y, float $w, float $h, float $sc, float $left, float $top, bool $flip = false): string {
    $bw = 64*$sc; $bh = 64*$sc*($e['h']/$e['w']);
    return '<span style="position:absolute;left:'.$left.'px;top:'.$top.'px;width:'.($w*$sc).'px;height:'.($h*$sc).'px;background:url('.asset($e['path']).') -'.($x*$sc).'px -'.($y*$sc).'px / '.$bw.'px '.$bh.'px no-repeat;image-rendering:pixelated;'.($flip ? 'transform:scaleX(-1);' : '').'"></span>';
}
function render_skin_head(string $name, int $size = 32): void {
    $e = skin_entry(skin_key($name));
    if ($e && $e['kind'] === 'skin') { $sc = $size/8;
        echo '<span style="position:relative;display:inline-block;flex:none;width:'.$size.'px;height:'.$size.'px;border-radius:4px;overflow:hidden">'.skin_layer($e,8,8,8,8,$sc,0,0).skin_layer($e,40,8,8,8,$sc,0,0).'</span>';
    } elseif ($e) {
        echo '<img src="'.asset($e['path']).'" alt="" style="width:'.$size.'px;height:'.$size.'px;border-radius:4px;object-fit:cover;image-rendering:pixelated;flex:none">';
    } else {
        echo '<img src="https://mc-heads.net/avatar/'.e(preg_replace('/[^A-Za-z0-9_]/', '', $name)).'/'.$size.'" style="width:'.$size.'px;height:'.$size.'px;border-radius:4px;image-rendering:pixelated;" alt="">';
    }
}
function render_home_skin(): void {
    $e = skin_entry('__home'); $name = preg_replace('/[^A-Za-z0-9_]/', '', (string)s('home_skin_name', 'MrTome_')) ?: 'MrTome_';
    if ($e && $e['kind'] === 'skin') { $sc = 150/32; $o = $e["h"] / $e["w"];
        $legacy = $o < 0.75;
        echo '<span class="full-body" style="position:relative;display:inline-block;width:'.(16*$sc).'px;height:'.(32*$sc).'px;max-width:none">';
        echo skin_layer($e,8,8,8,8,$sc,4*$sc,0).skin_layer($e,40,8,8,8,$sc,4*$sc,0);
        echo skin_layer($e,20,20,8,12,$sc,4*$sc,8*$sc);
        echo skin_layer($e,44,20,4,12,$sc,0,8*$sc);
        echo $legacy ? skin_layer($e,44,20,4,12,$sc,12*$sc,8*$sc,true) : skin_layer($e,36,52,4,12,$sc,12*$sc,8*$sc);
        echo skin_layer($e,4,20,4,12,$sc,4*$sc,20*$sc);
        echo $legacy ? skin_layer($e,4,20,4,12,$sc,8*$sc,20*$sc,true) : skin_layer($e,20,52,4,12,$sc,8*$sc,20*$sc);
        echo '</span>';
    } elseif ($e) { echo '<img class="full-body" src="'.asset($e['path']).'" alt="">';
    } else { echo '<img class="full-body" src="https://mc-heads.net/body/'.e($name).'/left.png" alt="'.e($name).'">'; }
}
// ---- news link, announcement bar, maintenance mode
function news_href(): string { $l = trim((string)s('news_link', '')); return ($l !== '' && preg_match('~^(https?://|/)~i', $l)) ? ' href="'.e($l).'"' : ''; }
function render_announce(): void {
    $t = trim((string)s('announce_text', '')); if (!s('announce_on', false) || $t === '') return;
    $bg = color('announce_bg', '#19D3DA'); $fg = color('announce_fg', '#021A1C'); $l = trim((string)s('announce_link', ''));
    $inner = e($t); if ($l !== '' && preg_match('~^(https?://|/)~i', $l)) $inner = '<a href="'.e($l).'" style="color:inherit;text-decoration:underline">'.$inner.'</a>'; ?>
<div style="background:<?= $bg ?>;color:<?= $fg ?>;text-align:center;padding:10px 16px;font-size:14px;font-weight:600;position:relative;z-index:9999"><?= $inner ?></div>
<?php }
function is_admin_visitor(): bool { $a = auth_load(); return $a && !empty($_COOKIE['tome_pv']) && hash_equals(hash('sha256', $a['hash']), (string)$_COOKIE['tome_pv']); }
function maintenance_check(): void {
    if (!s('maintenance', false)) return;
    if (isset($_GET['pv']) && is_admin_visitor()) return;   // only the live-preview frame inside /admin; nobody else gets past

    http_response_code(503); header('Retry-After: 3600'); $c = color('primary_color', '#911AEE'); $bg = color('bg_color', '#101010'); $rgb = rgb($c); ?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e(s('site_name')) ?></title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:<?= $bg ?>;color:#fff;font-family:system-ui,Segoe UI,Roboto,sans-serif;text-align:center;padding:24px;overflow:hidden;position:relative}
body:before{content:"";position:absolute;width:520px;height:520px;max-width:90vw;max-height:90vw;border-radius:50%;background:radial-gradient(circle,rgba(<?= $rgb ?>,.18),transparent 70%);top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none}
.b{position:relative;max-width:520px}
.code{font-size:clamp(88px,22vw,168px);font-weight:800;line-height:1;letter-spacing:4px;margin:0;color:<?= $c ?>;opacity:.9;text-shadow:0 0 40px rgba(<?= $rgb ?>,.35)}
.b h1{margin:14px 0 8px;font-size:clamp(18px,4vw,24px);font-weight:600;color:rgba(255,255,255,.9)}
.b p{margin:0;font-size:15px;line-height:1.6;color:rgba(255,255,255,.55)}
</style></head>
<body><div class="b"><div class="code">404</div><h1><?= e(s('maint_title', 'We will be back soon')) ?></h1><p><?= nl2br(e(s('maint_text', 'The website is being updated. Please check back in a little while.'))) ?></p></div></body></html>
<?php exit; }
