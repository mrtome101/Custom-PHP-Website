<?php
// Core helpers. Everything on the site reads from data/settings.json
define('ROOT', dirname(__DIR__));
define('SETTINGS_FILE', ROOT . '/data/settings.json');
define('AUTH_FILE', ROOT . '/admin/password.php');

// URL of the site root (so /rules/ /staff/ /vote/ still find their CSS, JS and images)
$__doc = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false; $__root = realpath(dirname(__DIR__));
$__rel = ($__doc && $__root && strpos($__root, $__doc) === 0) ? substr($__root, strlen($__doc)) : '';
define('BASE_URL', '/' . trim(str_replace('\\', '/', $__rel), '/') . (trim($__rel, '/\\') === '' ? '' : '/'));

if (PHP_SAPI !== 'cli' && !headers_sent()) header('Cache-Control: no-cache, must-revalidate');

function settings_raw(): array {
    // original defaults + whatever the admin saved (so updating the zip never wipes your settings)
    $def = is_file(ROOT.'/data/defaults.json') ? json_decode(file_get_contents(ROOT.'/data/defaults.json'), true) : [];
    $sav = is_file(SETTINGS_FILE) ? json_decode(file_get_contents(SETTINGS_FILE), true) : [];
    return array_merge(is_array($def) ? $def : [], is_array($sav) ? $sav : []);
}
function settings_save(array $d): bool {
    $tmp = SETTINGS_FILE . '.tmp';
    $ok = file_put_contents($tmp, json_encode($d, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE), LOCK_EX);
    return $ok !== false && rename($tmp, SETTINGS_FILE);
}
function auth_load(): ?array {            // login comes from admin/password.php
    if (!is_file(AUTH_FILE)) return null;
    $a = include AUTH_FILE;
    if (!is_array($a) || !isset($a['user'], $a['pass'])) return null;
    return ['user'=>(string)$a['user'], 'pass'=>(string)$a['pass'], 'hash'=>hash('sha256', $a['user'].'|'.$a['pass'])];
}

// Live preview: only the logged-in admin can temporarily override colours/name
function preview_overrides(): array {
    // Only the admin's own preview frame (URL has ?pv) ever sees unsaved changes. The real site never does.
    if (!isset($_GET['pv']) || empty($_COOKIE['tome_pv']) || empty($_COOKIE['tome_pvset'])) return [];
    $a = auth_load(); if (!$a) return [];
    if (!hash_equals(hash('sha256', $a['hash']), (string)$_COOKIE['tome_pv'])) return [];
    $o = json_decode((string)$_COOKIE['tome_pvset'], true); if (!is_array($o)) return [];
    $out = [];
    foreach (['primary_color','bg_color'] as $k)
        if (isset($o[$k]) && preg_match('/^#[0-9a-fA-F]{6}$/', $o[$k])) $out[$k] = strtoupper($o[$k]);
    if (isset($o['site_name'])) $out['site_name'] = substr(strip_tags((string)$o['site_name']), 0, 60);
    if (isset($o['layout']) && preg_match('/^[a-z]{3,12}$/', (string)$o['layout'])) $out['layout'] = (string)$o['layout'];
    foreach (['server_ip','store_url','discord_code','news_link'] as $k)
        if (isset($o[$k])) $out[$k] = substr(trim(strip_tags((string)$o[$k])), 0, 200);
    foreach (['logo','favicon','og_image','news_banner'] as $k) {
        $u = (string)($o['use_'.$k] ?? '');
        if ($u !== '' && preg_match('~^uploads/[A-Za-z0-9_./-]+$~', $u) && strpos($u, '..') === false && is_file(ROOT.'/'.$u)) $out[$k] = $u;
    }
    foreach (['particles_color','particles_line_color'] as $k)
        if (isset($o[$k]) && preg_match('/^#[0-9a-fA-F]{6}$/', $o[$k])) $out[$k] = strtoupper($o[$k]);
    foreach (['particles_enabled','particles_follow','particles_lines','particles_hover','particles_click'] as $k)
        if (isset($o[$k])) $out[$k] = (bool)$o[$k];
    foreach (['particles_count','particles_speed','particles_size','particles_distance','particles_opacity','particles_line_opacity','particles_line_width'] as $k)
        if (isset($o[$k]) && is_numeric($o[$k])) $out[$k] = 0 + $o[$k];
    return $out;
}
function settings_load(): array {
    static $c = null;
    return $c ??= array_merge(settings_raw(), preview_overrides());
}
function pv_q(): string { return isset($_GET['pv']) ? '?pv=1' : ''; }
function s(string $k, $def = '') { $d = settings_load(); return array_key_exists($k, $d) ? $d[$k] : $def; }
function site_url(): string { $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'); $h = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? '')); return $h === '' ? '/' : ($https ? 'https' : 'http').'://'.$h.'/'; }
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function color($k, $def) { $v = trim((string)s($k, $def)); return preg_match('/^#[0-9a-fA-F]{6}$/', $v) ? strtoupper($v) : $def; }
function asset(string $p): string { $f = ROOT.'/'.ltrim($p,'/'); return e(BASE_URL . ltrim($p,'/')).'?v='.(is_file($f) ? filemtime($f) : 1); }
function rgb(string $hex): string { $h = ltrim($hex,'#'); return hexdec(substr($h,0,2)).', '.hexdec(substr($h,2,2)).', '.hexdec(substr($h,4,2)); }

require_once __DIR__ . '/content.php';
require_once __DIR__ . '/layouts.php';
