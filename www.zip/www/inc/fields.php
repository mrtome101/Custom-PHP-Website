<?php
// Editable text blocks. d = default (original) text. All plain text.
return array (
  'news_title' => 
  array (
    'g' => 'Home page',
    'l' => 'News title',
    't' => 'text',
    'd' => '{site_name} SEASON 1',
    'h' => '',
  ),
  'news_author' => 
  array (
    'g' => 'Home page',
    'l' => 'News author name',
    't' => 'text',
    'd' => 'MrTome',
    'h' => '',
  ),
  'news_time' => 
  array (
    'g' => 'Home page',
    'l' => 'News time label',
    't' => 'text',
    'd' => '10 months ago',
    'h' => '',
  ),
  'news_body' => 
  array (
    'g' => 'Home page',
    'l' => 'News post text',
    't' => 'area',
    'd' => '📰 Hello everyone!

We would like to inform you that for the past several weeks we have been working on a total revamp of {site_name}.

We are bringing you this update because in our eyes {site_name} does not look like it once was in its former glory, and that hurts to see. Therefore, we are developing a massive update which will bring back many old features and much fewer bugs.

As part of this update, we have chosen to reduce the number of gamemodes available, because many have simply gone unplayed, which results in us having less time to release critical updates and bug fixes for the major gamemodes. Please see ...',
    'h' => 'Plain text only. Leave a blank line between paragraphs. Use **bold** if you want. {site_name} = your site name. Change the picture in the Images tab.',
  ),
  'hero_copy' => 
  array (
    'g' => 'Home page',
    'l' => 'Top text under play button',
    't' => 'text',
    'd' => 'Click to copy IP',
    'h' => '',
  ),
  'hero_join' => 
  array (
    'g' => 'Home page',
    'l' => 'Top text under Discord button',
    't' => 'text',
    'd' => 'Click to join',
    'h' => '',
  ),
  'rules_title' => 
  array (
    'g' => 'Rules page',
    'l' => 'Main title',
    't' => 'text',
    'd' => '{site_name} Official Rules',
    'h' => '',
  ),
  'rules_updated' => 
  array (
    'g' => 'Rules page',
    'l' => '"Last updated" line',
    't' => 'text',
    'd' => 'Last updated: October 2025',
    'h' => '',
  ),
  'rules_intro' => 
  array (
    'g' => 'Rules page',
    'l' => 'Intro paragraphs',
    't' => 'area',
    'd' => 'Welcome to the official rules page for **{site_name}**. Here you will find our network-wide guidelines and Discord server rules.

Should you fail to abide by these rules, you may lose the ability to participate in our community. Staff can issue punishments for offences not listed here. You are responsible for your own account.

We hope you enjoy your time on our server. Thank you!',
    'h' => 'Separate paragraphs with a blank line. Use **bold** and {site_name}.',
  ),
  'rules_signature' => 
  array (
    'g' => 'Rules page',
    'l' => 'Signature line',
    't' => 'text',
    'd' => '- {site_name} Management and Staff',
    'h' => '',
  ),
  'rules_join_btn' => 
  array (
    'g' => 'Rules page',
    'l' => 'Discord button text',
    't' => 'text',
    'd' => 'Join {site_name} Discord',
    'h' => '',
  ),
  'rules_mc_title' => 
  array (
    'g' => 'Rules page',
    'l' => 'Minecraft rules: title',
    't' => 'text',
    'd' => 'Minecraft Server Rules',
    'h' => '',
  ),
  'rules_mc_intro' => 
  array (
    'g' => 'Rules page',
    'l' => 'Minecraft rules: intro line',
    't' => 'text',
    'd' => 'The following actions are not permitted:',
    'h' => '',
  ),
  'rules_mc_list' => 
  array (
    'g' => 'Rules page',
    'l' => 'Minecraft rules: one rule per line',
    't' => 'area',
    'd' => 'Spamming, disrespect, bigotry
Griefing/Stealing [[(ALLOWED ON LIFESTEAL)]]
Staff disrespect, advertising, unfair advantage / cheats
Inappropriate names/skins, politics/religion, drama
Duplication exploits, lag machines, suspicious links
Scamming [[(ALLOWED ON LIFESTEAL)]], real-life trades, alts abuse
IP-grabbing, bot attacks, impersonation',
    'h' => 'One rule per line. Wrap text in [[double brackets]] to highlight it in your main color.',
  ),
  'rules_mc_note' => 
  array (
    'g' => 'Rules page',
    'l' => 'Minecraft rules: note at the end',
    't' => 'text',
    'd' => 'Claims may be unclaimed if owner is inactive 30+ days.',
    'h' => '',
  ),
  'rules_dc_title' => 
  array (
    'g' => 'Rules page',
    'l' => 'Discord rules: title',
    't' => 'text',
    'd' => 'Discord Server Rules',
    'h' => '',
  ),
  'rules_dc_intro' => 
  array (
    'g' => 'Rules page',
    'l' => 'Discord rules: intro line',
    't' => 'text',
    'd' => 'The following actions are not permitted:',
    'h' => '',
  ),
  'rules_dc_list' => 
  array (
    'g' => 'Rules page',
    'l' => 'Discord rules: one rule per line',
    't' => 'area',
    'd' => 'Non-English language, spamming, disrespect
Inappropriate names/profiles, advertising, chat filter bypass
Bigotry, staff disrespect, trolling, suspicious links
Sensitive topics, discussing punishments, impersonation
Politics/religion, drama, predatory behavior
Wrong channel commands, duplicate tickets, real-life trades',
    'h' => 'One rule per line. Wrap text in [[double brackets]] to highlight it in your main color.',
  ),
  'rules_dc_note' => 
  array (
    'g' => 'Rules page',
    'l' => 'Discord rules: note at the end',
    't' => 'text',
    'd' => 'If it is not allowed in-game, it is not allowed on Discord either.',
    'h' => '',
  ),
  'rules_nav_home' => 
  array (
    'g' => 'Rules page',
    'l' => 'Side menu: Home',
    't' => 'text',
    'd' => 'HOME',
    'h' => '',
  ),
  'rules_nav_mc' => 
  array (
    'g' => 'Rules page',
    'l' => 'Side menu: Minecraft Server',
    't' => 'text',
    'd' => 'MINECRAFT SERVER',
    'h' => '',
  ),
  'rules_nav_dc' => 
  array (
    'g' => 'Rules page',
    'l' => 'Side menu: Discord Server',
    't' => 'text',
    'd' => 'DISCORD SERVER',
    'h' => '',
  ),
  'rules_side_title' => 
  array (
    'g' => 'Rules page',
    'l' => 'Side menu title',
    't' => 'text',
    'd' => 'Rules',
    'h' => '',
  ),
  'rules_sections' => 
  array (
    'g' => 'Rules page',
    'l' => 'Rule sections',
    't' => 'area',
    'd' => '',
    'h' => '',
  ),
  'staff_list' => 
  array (
    'g' => 'Staff page',
    'l' => 'Staff team',
    't' => 'area',
    'd' => '## Owner | #00FFFF
NOT_PLAYER_25
GBR_TRG

## Manager | #FF0000
MrTome_

## Senior Administrator | #CC3333
Steve

## Administrator | #FF6666
Steve

## Developer | #911AEE
Steve

## Senior Moderator | #FFE066
Steve

## Moderator | #FFD700
Steve

## Helper | #00CC66
Steve',
    'h' => 'Start each rank with "## Rank name | #color". Then write one player name per line.',
  ),
  'vote_label' => 
  array (
    'g' => 'Vote page',
    'l' => 'Small label above title',
    't' => 'text',
    'd' => 'Vote',
    'h' => '',
  ),
  'vote_title' => 
  array (
    'g' => 'Vote page',
    'l' => 'Title',
    't' => 'text',
    'd' => 'Vote for {site_name}!',
    'h' => '',
  ),
  'vote_info' => 
  array (
    'g' => 'Vote page',
    'l' => 'Info text',
    't' => 'area',
    'd' => 'You can receive up to **6 VOTE KEYS** by voting for our server!',
    'h' => 'Plain text only. Use **bold** for emphasis.',
  ),
  'vote_links' => 
  array (
    'g' => 'Vote page',
    'l' => 'Vote buttons',
    't' => 'area',
    'd' => 'VOTE #1 | https://minecraft-mp.com/
VOTE #2 | https://minecraft-server-list.com/
VOTE #3 | https://topminecraftservers.org/
VOTE #4 | https://minecraftservers.org/
VOTE #5 | https://www.minecraft-server.net/
VOTE #6 | https://servers-minecraft.net/',
    'h' => 'One button per line: "Button text | https://link"',
  ),
  'nav_home' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Menu: Home',
    't' => 'text',
    'd' => 'Home',
    'h' => '',
  ),
  'nav_rules' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Menu: Rules',
    't' => 'text',
    'd' => 'Rules',
    'h' => '',
  ),
  'nav_vote' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Menu: Vote',
    't' => 'text',
    'd' => 'Vote',
    'h' => '',
  ),
  'nav_store' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Menu: Store',
    't' => 'text',
    'd' => 'Store',
    'h' => '',
  ),
  'nav_staff' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Menu: Staff',
    't' => 'text',
    'd' => 'Staff',
    'h' => '',
  ),
  'nav_menu' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Mobile menu button',
    't' => 'text',
    'd' => 'Menu',
    'h' => '',
  ),
  'title_index' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Browser tab title: Home page',
    't' => 'text',
    'd' => 'Home',
    'h' => '',
  ),
  'title_rules' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Browser tab title: Rules page',
    't' => 'text',
    'd' => 'Rules',
    'h' => '',
  ),
  'title_staff' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Browser tab title: Staff page',
    't' => 'text',
    'd' => 'Staff',
    'h' => '',
  ),
  'title_vote' => 
  array (
    'g' => 'Menu & titles',
    'l' => 'Browser tab title: Vote page',
    't' => 'text',
    'd' => 'Vote',
    'h' => '',
  ),
  'footer_play_title' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: "Play Now" title',
    't' => 'text',
    'd' => 'Play Now',
    'h' => '',
  ),
  'footer_play_text' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: play text',
    't' => 'text',
    'd' => 'Start your journey today! Join the server now to play the best Lifesteal, Survival, and Practice!',
    'h' => '',
  ),
  'footer_links_title' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: "Links" title',
    't' => 'text',
    'd' => 'Links',
    'h' => '',
  ),
  'footer_link_rules' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: rules link',
    't' => 'text',
    'd' => 'Server Rules',
    'h' => '',
  ),
  'footer_link_vote' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: vote link',
    't' => 'text',
    'd' => 'Vote Rewards',
    'h' => '',
  ),
  'footer_store_text' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: store text',
    't' => 'text',
    'd' => 'Check out our store to purchase ranks, crate keys, and more!',
    'h' => '',
  ),
  'footer_disclaimer' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: disclaimer',
    't' => 'text',
    'd' => 'Not affiliated with Mojang or Microsoft.',
    'h' => '',
  ),
  'footer_rights' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: "All rights reserved"',
    't' => 'text',
    'd' => 'All rights reserved.',
    'h' => '',
  ),
  'footer_store_title' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: "Store" title',
    't' => 'text',
    'd' => 'Store',
    'h' => '',
  ),
  'footer_store_btn' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: store button',
    't' => 'text',
    'd' => 'Shop Now',
    'h' => '',
  ),
  'footer_year' => 
  array (
    'g' => 'Footer (all pages)',
    'l' => 'Footer: copyright year',
    't' => 'text',
    'd' => '2025',
    'h' => '',
  ),
);
