<?php
// Website layouts (chosen in the admin panel > Layout). "default" = the original simple look.
// Each layout is only CSS (+ one Google font), so every page (home, rules, vote, staff) follows it.

function layouts_list(): array {
    return [
        'default' => ['name' => 'Default',     'tag' => 'Simple & clean',      'desc' => 'The original look. Logo in the middle, server and Discord on the sides.'],
        'blocks'  => ['name' => 'Blocks',      'tag' => 'Minecraft pixel UI',  'desc' => 'Chunky Minecraft-menu style: stone buttons, pixel headings, hard block shadows.'],
        'glass'   => ['name' => 'Glass',       'tag' => 'Modern & floating',   'desc' => 'Floating pill menu, frosted glass cards, soft glow, server and Discord as pills.'],
        'arena'   => ['name' => 'Neon Arena',  'tag' => 'Esports / PvP',       'desc' => 'Sharp angled panels, slanted menu, neon glow lines and a diagonal banner.'],
    ];
}
function layout_id(): string {
    $v = (string)s('layout', 'default');
    return isset(layouts_list()[$v]) ? $v : 'default';
}

function layout_css(string $id): string {
    $A   = color('primary_color', '#911AEE');
    $RGB = rgb($A);
    $P   = tint(22);
    $LH  = min(220, max(60, (int)s('logo_height', 200)));
    $px  = ((string)s('font', 'default') === 'default');   // only use the layout's own fonts when no custom font is picked
    $css = '';

    if ($id === 'blocks') {
        $css = <<<'CSS'
html.lay-blocks .navbar-top-new{background:#232323 !important;border-bottom:4px solid {A};box-shadow:0 5px 0 #000;position:relative;z-index:60}
html.lay-blocks .navbar-top-new .nav-link{background:#3b3b3b;border:3px solid #000;border-radius:0;box-shadow:inset 3px 3px 0 rgba(255,255,255,.22),inset -3px -3px 0 rgba(0,0,0,.5);margin:.55rem .3rem !important;padding:.55em 1.1em !important;text-transform:uppercase;font-size:.78rem !important;letter-spacing:.04em;text-shadow:2px 2px 0 #000;transition:none}
html.lay-blocks .navbar-top-new .nav-link:hover{background:#4d4d4d;box-shadow:inset 3px 3px 0 rgba(255,255,255,.3),inset -3px -3px 0 rgba(0,0,0,.5)}
html.lay-blocks .navbar-top-new .nav-link.nav-link-active{background:{A} !important;color:#fff !important}
html.lay-blocks .navbar-top-new .nav-link.store-link{background:{A} !important}
html.lay-blocks .navbar-top-new .nav-link.store-link:after{display:none}
html.lay-blocks .color-overlay{position:relative;border-bottom:6px solid #000;box-shadow:0 6px 0 {A}}
html.lay-blocks .color-overlay:after{content:"";position:absolute;inset:0;z-index:4;pointer-events:none;background-image:linear-gradient(rgba(0,0,0,.22) 2px,transparent 2px),linear-gradient(90deg,rgba(0,0,0,.22) 2px,transparent 2px);background-size:32px 32px}
html.lay-blocks .logo{filter:drop-shadow(0 8px 0 rgba(0,0,0,.7)) !important}
html.lay-blocks .status-text,html.lay-blocks .discord-text{background:rgba(24,24,24,.88);border:4px solid #000;border-radius:0;box-shadow:inset 3px 3px 0 rgba(255,255,255,.2),inset -3px -3px 0 rgba(0,0,0,.55),7px 7px 0 rgba(0,0,0,.55);padding:12px 16px}
html.lay-blocks .status-text .icon:after,html.lay-blocks .discord-text .icon:after{display:none}
html.lay-blocks .status-text .icon,html.lay-blocks .discord-text .icon{margin-top:0}
html.lay-blocks .top-text{text-shadow:2px 2px 0 #000}
html.lay-blocks .card{border-radius:0 !important;background:{P} !important;border:4px solid #000 !important;box-shadow:inset 3px 3px 0 rgba(255,255,255,.14),inset -3px -3px 0 rgba(0,0,0,.4),9px 9px 0 rgba(0,0,0,.55) !important}
html.lay-blocks .news-header{background:rgba(0,0,0,.28);border-bottom:4px solid #000 !important}
html.lay-blocks .card-body img{border:4px solid #000;box-shadow:6px 6px 0 rgba(0,0,0,.5)}
html.lay-blocks .btn,html.lay-blocks .btn-theme,html.lay-blocks .btn-play,html.lay-blocks .btn-secondary{border-radius:0 !important;border:3px solid #000 !important;box-shadow:inset 3px 3px 0 rgba(255,255,255,.25),inset -3px -3px 0 rgba(0,0,0,.45);text-transform:uppercase;text-shadow:2px 2px 0 rgba(0,0,0,.6)}
html.lay-blocks .footer{border-top:6px solid #000;box-shadow:0 -6px 0 {A};background:rgba(0,0,0,.28)}
html.lay-blocks .footer-text-header:after{border-radius:0;height:8px}
html.lay-blocks .footer-link:hover{text-decoration:underline}
@media (max-width:600px){html.lay-blocks .card{box-shadow:inset 3px 3px 0 rgba(255,255,255,.14),inset -3px -3px 0 rgba(0,0,0,.4),4px 4px 0 rgba(0,0,0,.55) !important}}
html.lay-blocks ::-webkit-scrollbar{width:14px}html.lay-blocks ::-webkit-scrollbar-thumb{background:{A};border:3px solid #000}html.lay-blocks ::-webkit-scrollbar-track{background:#111}
html.lay-blocks .vote-btn{border-radius:0 !important;border:4px solid #000;background:{A} !important;box-shadow:inset 4px 4px 0 rgba(255,255,255,.32),inset -4px -4px 0 rgba(0,0,0,.45),6px 6px 0 rgba(0,0,0,.6);text-transform:uppercase;text-shadow:2px 2px 0 rgba(0,0,0,.65);letter-spacing:.04em;padding:16px 18px !important;transition:none !important}
html.lay-blocks .vote-btn:hover{transform:translate(-2px,-2px) !important;filter:brightness(1.12);box-shadow:inset 4px 4px 0 rgba(255,255,255,.38),inset -4px -4px 0 rgba(0,0,0,.45),9px 9px 0 rgba(0,0,0,.6) !important}
html.lay-blocks .vote-btn:active{transform:translate(4px,4px) !important;box-shadow:inset 4px 4px 0 rgba(0,0,0,.35),inset -4px -4px 0 rgba(255,255,255,.2),2px 2px 0 rgba(0,0,0,.6) !important}
html.lay-blocks .staff-card{border-radius:0 !important;background:#2a2a2a !important;border:3px solid #000 !important;box-shadow:inset 3px 3px 0 rgba(255,255,255,.14),inset -3px -3px 0 rgba(0,0,0,.45),5px 5px 0 rgba(0,0,0,.5);transition:none !important}
html.lay-blocks .staff-card:hover{transform:translate(-2px,-2px) !important;border-color:{A} !important;box-shadow:inset 3px 3px 0 rgba(255,255,255,.2),inset -3px -3px 0 rgba(0,0,0,.45),8px 8px 0 rgba(0,0,0,.55) !important}
html.lay-blocks .staff-card canvas,html.lay-blocks .staff-card img{border-radius:0 !important;image-rendering:pixelated}
html.lay-blocks #staffGuiBox{border-radius:0 !important;border:4px solid #000 !important;box-shadow:inset 3px 3px 0 rgba(255,255,255,.14),inset -3px -3px 0 rgba(0,0,0,.4),12px 12px 0 rgba(0,0,0,.65) !important}
html.lay-blocks #staffGuiBox button{border-radius:0 !important;border:3px solid #000 !important}
html.lay-blocks #staffGuiBox *{border-radius:0 !important}
html.lay-blocks .card [style*="border-radius"]{border-radius:0 !important}
CSS;
        if ($px) $css .= "\nhtml.lay-blocks .navbar-top-new .nav-link,html.lay-blocks .news-title,html.lay-blocks .footer-text-header,html.lay-blocks .top-text,html.lay-blocks .btn,html.lay-blocks .vote-btn,html.lay-blocks .rules-menu-link,html.lay-blocks h1,html.lay-blocks h2,html.lay-blocks h3,html.lay-blocks h4{font-family:'Press Start 2P','VT323',monospace !important;line-height:1.5}\nhtml.lay-blocks .news-title{font-size:1rem !important}\nhtml.lay-blocks .footer-text-header{font-size:1rem !important}\nhtml.lay-blocks .top-text{font-size:.7rem !important}\n";
    }

    if ($id === 'glass') {
        $css = <<<'CSS'
html.lay-glass body{background-image:radial-gradient(900px 520px at 12% -6%,rgba({RGB},.30),transparent 62%),radial-gradient(760px 520px at 105% 38%,rgba({RGB},.16),transparent 60%);background-attachment:fixed}
html.lay-glass .navbar-top-new{background:rgba(14,14,20,.5) !important;-webkit-backdrop-filter:blur(16px) saturate(150%);backdrop-filter:blur(16px) saturate(150%);border:1px solid rgba(255,255,255,.14);box-shadow:0 12px 36px rgba(0,0,0,.4)}
html.lay-glass .navbar-top-new .nav-link{border-radius:999px;padding:.5em 1.1em !important;margin:.35rem .15rem !important;font-weight:600;transition:background .2s,box-shadow .2s}
html.lay-glass .navbar-top-new .nav-link:hover{background:rgba(255,255,255,.1)}
html.lay-glass .navbar-top-new .nav-link.nav-link-active{background:rgba({RGB},.35);box-shadow:inset 0 0 0 1px rgba({RGB},.8),0 0 18px rgba({RGB},.45)}
html.lay-glass .navbar-top-new .nav-link.store-link{background:linear-gradient(135deg,{A},rgba({RGB},.65)) !important;border-radius:999px}
html.lay-glass .color-overlay{-webkit-mask-image:linear-gradient(#000 70%,transparent);mask-image:linear-gradient(#000 70%,transparent)}
html.lay-glass .status-text .icon:after,html.lay-glass .discord-text .icon:after{display:none}
html.lay-glass .status-text,html.lay-glass .discord-text{background:rgba(14,14,20,.5);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.16);border-radius:999px;box-shadow:0 10px 30px rgba(0,0,0,.35);align-items:center;padding:8px 22px 8px 12px}
html.lay-glass .status-text:hover,html.lay-glass .discord-text:hover{border-color:rgba({RGB},.8);box-shadow:0 10px 30px rgba(0,0,0,.35),0 0 22px rgba({RGB},.45)}
html.lay-glass .card{background:rgba(255,255,255,.055) !important;-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.13) !important;border-radius:22px !important;box-shadow:0 20px 55px rgba(0,0,0,.38) !important;overflow:hidden;transition:transform .25s,box-shadow .25s}
html.lay-glass .card:hover{transform:translateY(-3px);box-shadow:0 26px 60px rgba(0,0,0,.42),0 0 0 1px rgba({RGB},.4) !important}
html.lay-glass .news-header{background:linear-gradient(90deg,rgba({RGB},.2),transparent);border-bottom:1px solid rgba(255,255,255,.1) !important}
html.lay-glass .card-body img{border-radius:16px}
html.lay-glass .btn,html.lay-glass .btn-theme,html.lay-glass .btn-play,html.lay-glass .btn-secondary{border-radius:999px !important}
html.lay-glass .btn-theme,html.lay-glass .nav-link.store-link{box-shadow:0 8px 22px rgba({RGB},.4)}
html.lay-glass .footer{background:rgba(255,255,255,.04);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border-top:1px solid rgba(255,255,255,.1)}
html.lay-glass .vote-btn{border-radius:999px !important;box-shadow:0 10px 26px rgba({RGB},.4)}
html.lay-glass .staff-card{border-radius:16px !important;background:rgba(255,255,255,.07) !important;border:1px solid rgba(255,255,255,.15) !important}
html.lay-glass #staffGuiOverlay{background:rgba(6,6,12,.62) !important;-webkit-backdrop-filter:blur(10px) !important;backdrop-filter:blur(10px) !important}
html.lay-glass #staffGuiBox{border-radius:26px !important;background:rgba(20,20,30,.82) !important;-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.18) !important;box-shadow:0 30px 80px rgba(0,0,0,.6),0 0 0 1px rgba({RGB},.25) !important}
@media (min-width:992px){
html.lay-glass .navbar-top-new{position:absolute;top:16px;left:50%;transform:translateX(-50%);width:auto;max-width:calc(100% - 28px);border-radius:999px;padding:0 14px;z-index:200}
html.lay-glass .logo-ds-flex{flex-wrap:wrap;align-content:flex-start;justify-content:center;gap:10px 22px;padding-top:84px}
html.lay-glass .logo-container{order:0;flex:0 0 100%;text-align:center}
html.lay-glass .logo{height:{LH}px !important;width:auto;max-width:80%;margin-top:0 !important}
html.lay-glass .header{height:410px !important}
html.lay-glass .status-box-container,html.lay-glass .discord-box-container{order:1;flex:0 0 auto;display:block !important}
html.lay-glass .status-text,html.lay-glass .discord-text{margin:0 !important}
html.lay-glass .status-box-container .text,html.lay-glass .discord-box-container .text{display:block !important}
}
CSS;
        if ($px) $css .= "\nhtml.lay-glass .nav-link,html.lay-glass .news-title,html.lay-glass .footer-text-header,html.lay-glass .top-text,html.lay-glass .btn{font-family:'Outfit','Montserrat',system-ui,sans-serif !important}\n";
    }

    if ($id === 'arena') {
        $css = <<<'CSS'
html.lay-arena .navbar-top-new{background:linear-gradient(180deg,rgba(0,0,0,.9),rgba(0,0,0,.45)) !important;border-bottom:2px solid {A};box-shadow:0 4px 28px rgba({RGB},.55);position:relative;z-index:60}
html.lay-arena .navbar-top-new .nav-link{transform:skewX(-14deg);background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:0;padding:.4em 1.5em !important;margin:.5rem .3rem !important;text-transform:uppercase;letter-spacing:.09em;font-weight:700;font-size:.95rem !important;transition:background .18s,box-shadow .18s}
html.lay-arena .navbar-top-new .nav-link:hover{background:rgba({RGB},.3);box-shadow:0 0 16px rgba({RGB},.55)}
html.lay-arena .navbar-top-new .nav-link.nav-link-active,html.lay-arena .navbar-top-new .nav-link.store-link{background:{A} !important;box-shadow:0 0 20px rgba({RGB},.65)}
html.lay-arena .navbar-top-new .nav-link.store-link:after{display:none}
html.lay-arena .color-overlay{clip-path:polygon(0 0,100% 0,100% 88%,0 100%);margin-bottom:-34px}
html.lay-arena .logo{filter:drop-shadow(0 0 22px rgba({RGB},.75)) !important}
html.lay-arena .status-text .icon:after,html.lay-arena .discord-text .icon:after{display:none}
html.lay-arena .status-text,html.lay-arena .discord-text{background:linear-gradient(90deg,rgba(0,0,0,.82),rgba(0,0,0,.4));border-left:4px solid {A};padding:10px 22px 10px 16px;clip-path:polygon(0 0,100% 0,calc(100% - 14px) 100%,0 100%);text-transform:uppercase;letter-spacing:.05em}
html.lay-arena .discord-text{background:linear-gradient(270deg,rgba(0,0,0,.82),rgba(0,0,0,.4));border-left:0;border-right:4px solid {A};padding:10px 16px 10px 22px;clip-path:polygon(14px 0,100% 0,100% 100%,0 100%)}
html.lay-arena .top-text{text-shadow:0 0 12px rgba({RGB},.9)}
html.lay-arena .card{border-radius:0 !important;border:1px solid rgba({RGB},.35) !important;border-left:5px solid {A} !important;background:linear-gradient(135deg,rgba(255,255,255,.06),rgba(0,0,0,.28)),{P} !important;box-shadow:none !important;clip-path:polygon(0 0,calc(100% - 24px) 0,100% 24px,100% 100%,24px 100%,0 calc(100% - 24px))}
html.lay-arena .news-header{background:linear-gradient(90deg,rgba({RGB},.22),transparent);border-bottom:1px solid rgba({RGB},.4) !important}
html.lay-arena .news-title,html.lay-arena .footer-text-header{text-transform:uppercase;letter-spacing:.07em;text-shadow:0 0 14px rgba({RGB},.65)}
html.lay-arena .card-body img{clip-path:polygon(0 0,calc(100% - 18px) 0,100% 18px,100% 100%,18px 100%,0 calc(100% - 18px))}
html.lay-arena .btn,html.lay-arena .btn-theme,html.lay-arena .btn-play,html.lay-arena .btn-secondary{border-radius:0 !important;clip-path:polygon(10px 0,100% 0,calc(100% - 10px) 100%,0 100%);text-transform:uppercase;letter-spacing:.08em;font-weight:700;padding-left:1.6rem;padding-right:1.6rem}
html.lay-arena .footer{border-top:2px solid {A};box-shadow:0 -10px 34px rgba({RGB},.28);background:linear-gradient(180deg,rgba(0,0,0,.35),rgba(0,0,0,.6))}
html.lay-arena .footer-text-header:after{border-radius:0;width:34px;transform:skewX(-20deg)}
html.lay-arena .vote-btn{border-radius:0 !important;clip-path:polygon(12px 0,100% 0,calc(100% - 12px) 100%,0 100%);text-transform:uppercase;letter-spacing:.09em;font-weight:700}
html.lay-arena .staff-card{border-radius:0 !important;border:1px solid rgba({RGB},.3) !important;border-left:4px solid {A} !important;clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px))}
html.lay-arena #staffGuiBox{border-radius:0 !important;border:1px solid rgba({RGB},.5) !important;border-left:5px solid {A} !important;clip-path:polygon(0 0,calc(100% - 26px) 0,100% 26px,100% 100%,26px 100%,0 calc(100% - 26px));box-shadow:none !important}
html.lay-arena #staffGuiBox button{border-radius:0 !important}
CSS;
        if ($px) $css .= "\nhtml.lay-arena .nav-link,html.lay-arena .news-title,html.lay-arena .footer-text-header,html.lay-arena .top-text,html.lay-arena .bottom-text,html.lay-arena .btn,html.lay-arena .vote-btn,html.lay-arena h1,html.lay-arena h2,html.lay-arena h3,html.lay-arena h4{font-family:'Rajdhani','Oswald','Montserrat',system-ui,sans-serif !important}\nhtml.lay-arena .news-title{font-size:1.5rem !important}\n";
    }

    return strtr($css, ['{A}' => $A, '{RGB}' => $RGB, '{P}' => $P, '{LH}' => $LH]);
}

function render_layout(): void {
    $id = layout_id();
    if ($id === 'default') return;
    $fonts = ['blocks' => 'Press+Start+2P', 'glass' => 'Outfit:wght@400;600;700', 'arena' => 'Rajdhani:wght@500;600;700'];
    if ((string)s('font', 'default') === 'default' && isset($fonts[$id])) {
        echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
           . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=' . $fonts[$id] . '&display=swap">' . "\n";
    }
    echo '<script>document.documentElement.classList.add("lay-' . $id . '")</script>' . "\n";
    echo '<style id="layout-css">' . layout_css($id) . "</style>\n";
}
