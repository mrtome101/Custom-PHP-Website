/* Shared admin theme + effects.
   Loaded on the login page AND on the panel, so the theme works on every admin page. */
(function () {
  'use strict';
  var ATH = [['purple', 'Purple', '#911aee'], ['midnight', 'Midnight', '#4f8cff'], ['ocean', 'Ocean', '#00b4d8'], ['dark', 'Aqua', '#19d3da'], ['emerald', 'Emerald', '#10b981'], ['forest', 'Forest', '#4ade80'], ['lime', 'Lime', '#a3e635'], ['gold', 'Gold', '#f5b301'], ['amber', 'Amber', '#ff9f1c'], ['sunset', 'Sunset', '#ff6b6b'], ['crimson', 'Crimson', '#e11d48'], ['rose', 'Rose', '#fb7185'], ['candy', 'Candy', '#ec4899'], ['magenta', 'Magenta', '#d946ef'], ['violet', 'Violet', '#8b5cf6'], ['slate', 'Slate', '#94a3b8'], ['mono', 'Mono', '#e5e5e5'], ['pureblack', 'Pure black', '#19d3da'], ['light', 'Light', '#0ea5b0']];
  var body = document.body;

  var OLD = { blue: 'midnight', green: 'emerald', orange: 'amber', pink: 'candy' };  /* old saved names */
  function current() { try { var v = localStorage.getItem('adm') || 'dark'; return OLD[v] || v; } catch (e) { return 'dark'; } }

  /* ---- custom admin color (any accent + background the admin picks) ---- */
  var CVARS = ['--aqua', '--aqua-d', '--aqua-l', '--bg', '--card', '--line', '--inp', '--side-bg', '--glow', '--onaqua'];
  function hex2rgb(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)]; }
  function rgb2hex(c) { return '#' + c.map(function (v) { return Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'); }).join(''); }
  function mixHex(a, b, t) { var A = hex2rgb(a), B = hex2rgb(b); return rgb2hex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]); }
  function lum(h) { var c = hex2rgb(h).map(function (v) { return v / 255; }); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; }
  function deriveCustom(acc, bg) {
    var rgb = hex2rgb(acc);
    var bgc = mixHex(bg, '#000000', .15);
    var card = mixHex(mixHex(bgc, '#ffffff', .045), acc, .05);
    var line = mixHex(mixHex(bgc, acc, .16), '#ffffff', .04);
    var inp = mixHex(bgc, '#000000', .25);
    var side = mixHex(bgc, '#000000', .10);
    var accd = mixHex(acc, '#ffffff', .30);
    var onacc = lum(acc) < .42 ? '#ffffff' : mixHex(bg, '#000000', .55);
    return { '--aqua': acc, '--aqua-d': accd, '--aqua-l': 'rgba(' + rgb.join(',') + ',.13)', '--bg': bgc, '--card': card, '--line': line, '--inp': inp, '--side-bg': side, '--glow': 'rgba(' + rgb.join(',') + ',.3)', '--onaqua': onacc };
  }
  function clearCustomVars() { CVARS.forEach(function (v) { body.style.removeProperty(v); }); }
  function applyCustom() {
    try {
      var raw = localStorage.getItem('adm_custom'); if (!raw) return false;
      var o = JSON.parse(raw);
      if (!o || !/^#[0-9a-fA-F]{6}$/.test(o.accent || '') || !/^#[0-9a-fA-F]{6}$/.test(o.bg || '')) return false;
      var v = deriveCustom(o.accent, o.bg);
      Object.keys(v).forEach(function (k) { body.style.setProperty(k, v[k]); });
      return true;
    } catch (e) { return false; }
  }
  window.setCustomTheme = function (accent, bg) {
    if (!/^#[0-9a-fA-F]{6}$/.test(accent) || !/^#[0-9a-fA-F]{6}$/.test(bg)) return;
    try { localStorage.setItem('adm_custom', JSON.stringify({ accent: accent.toUpperCase(), bg: bg.toUpperCase() })); } catch (e) {}
    setTheme('custom');
  };

  function paint(n) {
    body.className = body.className.replace(/\b(light|th-\w+)\b/g, '').replace(/\s+/g, ' ').trim();
    clearCustomVars();
    if (n === 'light') body.classList.add('light');
    else if (n === 'custom') { if (applyCustom()) body.classList.add('th-custom'); else n = 'dark'; }
    else if (n !== 'dark') body.classList.add('th-' + n);
    document.documentElement.style.colorScheme = n === 'light' ? 'light' : 'dark';
  }
  function setTheme(n) {
    if (n !== 'custom' && !ATH.some(function (t) { return t[0] === n; })) n = 'dark';
    paint(n);
    try { localStorage.setItem('adm', n); } catch (e) {}
    document.dispatchEvent(new CustomEvent('admthemechange', { detail: n }));
  }
  window.setTheme = setTheme;
  window.ADM_THEMES = ATH;
  paint(current());
  window.addEventListener('storage', function (e) { if (e.key === 'adm') { paint(current()); document.dispatchEvent(new CustomEvent('admthemechange', { detail: current() })); } });

  function markActive() {
    var c = current();
    [].forEach.call(document.querySelectorAll('[data-th]'), function (el) { el.classList.toggle('on', el.dataset.th === c); });
  }
  document.addEventListener('admthemechange', markActive);

  /* ---- big theme cards (Admin / Theme tab) ---- */
  var grid = document.getElementById('adm-theme-cards');
  var PREV = '<span class="pv-side"><i></i><i class="on"></i><i></i><i></i></span><span class="pv-main"><span class="pv-top"></span><span class="pv-card"><i></i><i></i><span class="pv-btn"></span></span></span>';
  if (grid) ATH.forEach(function (t) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'adm-th-card'; b.dataset.th = t[0]; b.title = t[1];
    b.innerHTML = '<span class="adm-prev th-' + t[0] + '">' + PREV + '</span>' +
      '<span class="adm-th-foot"><span class="adm-th-swatch" style="background:' + t[2] + ';box-shadow:0 0 14px ' + t[2] + '66"></span><span class="adm-th-name">' + t[1] + '</span></span>';
    b.onclick = function () { setTheme(t[0]); };
    grid.appendChild(b);
  });

  /* live preview for the custom accent/background pickers */
  var cpa = document.getElementById('adm_custom_a'), cpb = document.getElementById('adm_custom_b');
  if (cpa && cpb) {
    var cprev = document.createElement('span');
    cprev.className = 'adm-prev'; cprev.innerHTML = PREV;
    cpb.parentNode.parentNode.insertBefore(cprev, document.getElementById('adm_custom_apply'));
    var drawCustom = function () {
      var v = deriveCustom(cpa.value, cpb.value);
      Object.keys(v).forEach(function (k) { cprev.style.setProperty(k, v[k]); });
    };
    cpa.addEventListener('input', drawCustom); cpb.addEventListener('input', drawCustom);
    setTimeout(drawCustom, 0);
  }

  /* ---- quick theme popover (palette button on every page) ---- */
  var pop = document.createElement('div');
  pop.className = 'thp'; pop.id = 'thp'; pop.hidden = true; pop.setAttribute('role', 'menu');
  ATH.forEach(function (t) {
    var b = document.createElement('button');
    b.type = 'button'; b.dataset.th = t[0]; b.setAttribute('role', 'menuitemradio');
    b.innerHTML = '<i style="background:' + t[2] + '"></i>' + t[1];
    b.onclick = function () { setTheme(t[0]); };
    pop.appendChild(b);
  });
  body.appendChild(pop);
  function place(btn) {
    var r = btn.getBoundingClientRect(), pw = pop.offsetWidth || 230, ph = pop.offsetHeight || 170, m = 8;
    var left = Math.min(Math.max(m, r.left), window.innerWidth - pw - m);
    var top = r.top - ph - m; if (top < m) top = Math.min(r.bottom + m, window.innerHeight - ph - m);
    pop.style.left = left + 'px'; pop.style.top = Math.max(m, top) + 'px';
  }
  var openBtn = null;
  function closePop() { pop.hidden = true; openBtn = null; }
  [].forEach.call(document.querySelectorAll('[data-theme-open]'), function (btn) {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (!pop.hidden && openBtn === btn) { closePop(); return; }
      openBtn = btn; pop.hidden = false; place(btn); markActive();
    });
  });
  document.addEventListener('click', function (e) { if (!pop.hidden && !pop.contains(e.target)) closePop(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });
  window.addEventListener('resize', function () { if (openBtn) place(openBtn); });
  markActive();

  /* ---- toggleable effects ---- */
  var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var DEF = { particles: !calm, btnShine: true, cardLift: true, navSlide: true, clickRipple: !calm, savePulse: !calm };
  var st = {}; for (var k in DEF) st[k] = DEF[k];
  try { var raw = localStorage.getItem('adm_fx_v1'); if (raw) { var o = JSON.parse(raw); for (var k2 in o) st[k2] = o[k2]; } } catch (e) {}
  var clsMap = { particles: 'afx-particles', btnShine: 'afx-btn-shine', cardLift: 'afx-card-lift', navSlide: 'afx-nav-slide', clickRipple: 'afx-click-ripple', savePulse: 'afx-save-pulse' };
  var loop = null;
  function applyFx() {
    Object.keys(clsMap).forEach(function (k) { body.classList.toggle(clsMap[k], !!st[k]); });
    [].forEach.call(document.querySelectorAll('[data-adm-fx]'), function (el) { el.checked = !!st[el.dataset.admFx]; });
    if (st.particles) startParticles(); else stopParticles();
  }
  [].forEach.call(document.querySelectorAll('[data-adm-fx]'), function (el) {
    el.addEventListener('change', function () {
      st[el.dataset.admFx] = el.checked;
      try { localStorage.setItem('adm_fx_v1', JSON.stringify(st)); } catch (e) {}
      applyFx();
    });
  });

  document.addEventListener('click', function (e) {
    if (!st.clickRipple) return;
    if (!e.target.closest('button,a,.chip,.drop')) return;
    var r = document.createElement('span');
    r.className = 'adm-click-burst'; r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
    body.appendChild(r); setTimeout(function () { r.remove(); }, 520);
  });

  /* ambient particles behind the panel */
  var cv = document.getElementById('adm-bg-particles'), ctx = cv && cv.getContext('2d'), W = 0, H = 0, pts = [];
  function size() { W = cv.width = window.innerWidth; H = cv.height = window.innerHeight; }
  function seed() {
    var n = Math.min(48, Math.max(22, Math.floor(W * H / 32000))); pts = [];
    for (var i = 0; i < n; i++) pts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .38, vy: (Math.random() - .5) * .38, r: 1.2 + Math.random() * 1.8 });
  }
  function tick() {
    ctx.clearRect(0, 0, W, H);
    var col = getComputedStyle(body).getPropertyValue('--aqua').trim() || '#19d3da';
    ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineWidth = 1;
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i]; p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.globalAlpha = .35; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
      for (var j = i + 1; j < pts.length; j++) {
        var q = pts[j], d = Math.hypot(p.x - q.x, p.y - q.y);
        if (d < 125) { ctx.globalAlpha = (1 - d / 125) * .14; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
      }
    }
    loop = requestAnimationFrame(tick);
  }
  function startParticles() { if (!cv || loop) return; size(); if (!pts.length) seed(); loop = requestAnimationFrame(tick); }
  function stopParticles() { if (loop) { cancelAnimationFrame(loop); loop = null; } if (ctx) ctx.clearRect(0, 0, W, H); }
  if (cv) window.addEventListener('resize', function () { size(); seed(); });
  applyFx();
})();
