<?php require __DIR__.'/inc/config.php'; ?>
<html lang="en" dir="ltr" class="dark" id="html">
	<!--
* PHP Engine [8.4-8.5]
* Copyright 2020; MrTome
* File mirrored from [https://<?= e(s('server_ip')) ?>/]
* IST UTC datetime: [2026-11-5 12:30:18]
--><head>
<base href="<?= e(BASE_URL) ?>">
    		  
		<!-- Optimization -->
		<link rel="preload" href="custom/templates/Cobalt/js/core/mod.min.js" as="script">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com">
				<link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" as="style">
		
		<!-- Early loading scripts -->
		<script src="custom/templates/Cobalt/js/core/mod.min.js"></script>

		<title>Vote &#8226; <?= e(s('site_name')) ?></title>
		<meta name="title" content="Vote &#8226; <?= e(s('site_name')) ?>">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="theme-color" content="#1a0a2e">
		<meta name="keywords" content=" ">
		<meta name="description" content=" ">
					<link rel="shortcut icon" href="<?= asset(s('favicon')) ?>" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="<?= asset(s('favicon')) ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= asset(s('favicon')) ?>">
		
		<!-- Opengraph / Facebook -->
		<meta property="og:type" content="website">
        <meta property="og:url" content="https://www.diesiremc.fun/">
		<meta property="og:site_name" content="<?= e(s('site_name')) ?>">
					<meta property="og:title" content="Vote &#8226; <?= e(s('site_name')) ?>">
			<meta property="og:description" content=" ">
							<meta property="og:image" content="<?= asset(s('logo')) ?>">
					
		<!-- Twitter -->
		<meta property="twitter:url" content="https://www.diesiremc.fun/">
					<meta property="twitter:title" content="Vote &#8226; <?= e(s('site_name')) ?>">
			<meta property="twitter:description" content=" ">
							<meta property="twitter:card" content="summary_large_image">
				<meta property="twitter:image" content="<?= asset(s('logo')) ?>">
					
					<link rel="stylesheet" href="core/assets/vendor/fortawesome/fontawesome-free/css/all.min.css">
					<link rel="stylesheet" href="core/assets/plugins/prism/prism_light_default.css">
					<link rel="stylesheet" href="core/assets/plugins/tinymce_spoiler/css/spoiler.css">
					
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
					
                <link rel="stylesheet" href="custom/templates/Cobalt/css/cobalt_v_1.8.3.css.php">
					
                <link rel="preload" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
					<style>
		
			:root {
		        --p-color: <?= color('primary_color','#911AEE') ?>;
		    }
		
		    /* Primary Color */
		    .discord-text .st0, .status-text path, .discord-icon .st0, .status-icon path {fill: var(--p-color) !important;}
			.swal2-icon.swal2-info, .cobalt-update-box .update-icon, .header-theme, .news-title, .top-text, .error-title, .lr-title, .p-icon, .theme-text, .other-btn:after, .other-btn:focus:after, .footer-text-header:after, .widget-header-txt:after, .discord-text .icon:after, .status-text .icon:after, .dropdown-item.d-header, .rules-menu .active span, .rules-menu .active i, .welcome-title, .profile-tabs-new .profile-nav-link.active {color: var(--p-color) !important;}
			a, a:hover, a:focus, .mcs-server-name {color: var(--p-color)}
			.color-overlay {background: linear-gradient(var(--p-color), <?= color('bg_color','#101010') ?>);}
			.swal2-icon.swal2-info, .page-item.active .page-link, .user-nav-link.active, .profile-about-box, .rules-menu-link.active {border-color: <?= color('primary_color','#911AEE') ?> !important;}
			.swal2-styled.swal2-confirm, .widget-header-txt:after, .discord-text .icon:after, .status-text .icon:after, .nav-link.store-link, .footer-text-header:after, .badge-theme, #toast-container, .progress-bar, .login-overlay, .register-overlay, .vote-tabs .btn.btn-theme.active, .p-color-overlay, .modal-header, .btn-theme, .button-checkbox>.active, .spoiler .spoiler-toggle, .spoiler .spoiler-title, .page-item.active .page-link, .btn.profile-btn.active:after, .cc-window.cc-floating .cc-highlight .cc-btn.cc-allow, .referrals .copy-text button {background-color: var(--p-color) !important;}
			.swal2-styled.swal2-confirm:hover, .spoiler .spoiler-toggle:hover, .spoiler .spoiler-title:hover, .btn-theme:hover {background-color: var(--p-color) !important; filter: brightness(0.85)}
			.wiki-menu .active.dropdown-toggle::after, .profile-tabs-new .profile-nav-link.active {
				border-top-color: var(--p-color) !important;
				border-bottom-color: var(--p-color) !important;
			}			
			
			/* Header */
			.header:after {height: 227.5px; background: linear-gradient(rgba(0, 0, 0, 0.3), transparent);} .header:before {background: linear-gradient(rgba(0, 0, 0, 0.3), <?= color('bg_color','#101010') ?>);}
			.header {background-position: center center !important}
			@media (min-width: 769px) {.header {height: 475px}}
			@media (max-width: 768px) {.header {height: 340px}}
		    @media (min-width: 769px) {.logo {height: 200px; margin-top: 122.5px}}
		    @media (max-width: 768px) {.logo {height: 130px; margin-top: 85px}}
		    .status-text, .discord-text {margin-top: 203.5px}
		    @media (max-width: 1050px) {.status-box-container .text, .discord-box-container .text {display: none}}
		    .line-scale > div {background-color: #FFFFFF;}
		    
		    /* Other */
		    .login-overlay, .register-overlay {opacity: 0.5 !important}
		
		</style>
					<style>.navbar-nav .nav-item:first-child {margin-left: 10 !important}</style>
					<style>.header, .webp .header, .no-webp .header {background: url('<?= asset(s('hero_bg')) ?>') no-repeat center center / cover !important;}</style>
					
					<style>.navbar-bottom .store-link:after, .navbar-bottom .store-link:focus:after, .navbar-top-new .store-link:after, .navbar-top-new .store-link:focus:after {box-shadow: 0px 0px 12px 0px <?= color('primary_color','#911AEE') ?>}</style>
					<style>.p-image-frame {z-index: 1; opacity: 0.7}</style>
					<style>
				.store-box {
					border: 3px solid <?= color('primary_color','#911AEE') ?>;
					box-shadow: 0 0 10px rgb(250 73 73 / 50%);
				}
				.webp .store-box {
					background: linear-gradient(to bottom, rgba(250 73 73 / 70%), rgba(250 73 73 / 70%));
				}
				.no-webp .store-box {
					background: linear-gradient(to bottom, rgba(250 73 73 / 70%), rgba(250 73 73 / 70%));
				}
		</style>
						
		    </head>
	<body>
            <div class="load-wrapper"><div class="loader"><div class="loader-inner line-scale"><div></div><div></div><div></div><div></div><div></div></div></div></div>
         <nav class="navbar navbar-expand-lg navbar-theme navbar-double navbar-top-new">
        <div class="container">
            <button class="navbar-toggler nav-link" type="button"><i class="fa-solid fa-bars"></i> Menu</button>
            
                        <div class="status-icon" onclick="copyToClipboard('#ip')">
                <svg class="creeper" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512"><!--! Font Awesome Pro 1.0 by @TomeStudios - https://www.tomestudios.fun/ License - https://www.tomestudios.fun/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zM188.3 147.1c-7.6 4.2-12.3 12.3-12.3 20.9V344c0 8.7 4.7 16.7 12.3 20.9s16.8 4.1 24.3-.5l144-88c7.1-4.4 11.5-12.1 11.5-20.5s-4.4-16.1-11.5-20.5l-144-88c-7.4-4.5-16.7-4.7-24.3-.5z"></path></svg>
            </div>
            
            <a href="https://discord.gg/<?= e(s('discord_code')) ?>" target="_blank">
                <div class="discord-icon">
                            <svg class="discord" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 245 240">
                                <path class="st0" d="M104.4 103.9c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1.1-6.1-4.5-11.1-10.2-11.1zM140.9 103.9c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1s-4.5-11.1-10.2-11.1z">
                                </path>
                                <path class="st0" d="M189.5 20h-134C44.2 20 35 29.2 35 40.6v135.2c0 11.4 9.2 20.6 20.5 20.6h113.4l-5.3-18.5 12.8 11.9 12.1 11.2 21.5 19V40.6c0-11.4-9.2-20.6-20.5-20.6zm-38.6 130.6s-3.6-4.3-6.6-8.1c13.1-3.7 18.1-11.9 18.1-11.9-4.1 2.7-8 4.6-11.5 5.9-5 2.1-9.8 3.5-14.5 4.3-9.6 1.8-18.4 1.3-25.9-.1-5.7-1.1-10.6-2.7-14.7-4.3-2.3-.9-4.8-2-7.3-3.4-.3-.2-.6-.3-.9-.5-.2-.1-.3-.2-.4-.3-1.8-1-2.8-1.7-2.8-1.7s4.8 8 17.5 11.8c-3 3.8-6.7 8.3-6.7 8.3-22.1-.7-30.5-15.2-30.5-15.2 0-32.2 14.4-58.3 14.4-58.3 14.4-10.8 28.1-10.5 28.1-10.5l1 1.2c-18 5.2-26.3 13.1-26.3 13.1s2.2-1.2 5.9-2.9c10.7-4.7 19.2-6 22.7-6.3.6-.1 1.1-.2 1.7-.2 6.1-.8 13-1 20.2-.2 9.5 1.1 19.7 3.9 30.1 9.6 0 0-7.9-7.5-24.9-12.7l1.4-1.6s13.7-.3 28.1 10.5c0 0 14.4 26.1 14.4 58.3 0 0-8.5 14.5-30.6 15.2z">
                                </path>
                            </svg>
                </div>
            </a>
            
            <div class="collapse navbar-collapse" id="navbar">


            
                <ul class="navbar-nav mx-auto">
                                                                                                        <li class="nav-item">
                                    <a class="nav-link" href="index.html"><i class="fa-solid fa-house"></i> Home</a>
                                </li>
                                                                                                                                                            <li class="nav-item">
                                    <a class="nav-link" href="rules.html"><i class="fa-solid fa-scale-balanced"></i> Rules</a>
                                </li>
                                                                                                                                                            <li class="nav-item">
                                    <a class="nav-link nav-link-active" href="vote.html"><i class="fa-solid fa-check-to-slot"></i> Vote</a>
                                </li>
                                                                                                                                                            <li class="nav-item">
                                    </li>
                                                                                                                                                            <li class="nav-item">
                                    <a class="nav-link" href="<?= e(s('store_url')) ?>/" target="_blank"><i class="fa-solid fa-store"></i> Store</a>
                                </li>
                                                                                                                                                            <li class="nav-item">
                                    <a class="nav-link" href="staff.html"><i class="fa-solid fa-clipboard-user"></i> Staff</a>
                                </li>
                                                                                                                                                            <li class="nav-item">
                                    </li>
                                                                                        </ul>
                
            







            </div>
        </div>
    </nav>

<div class="color-overlay">
    <div class="header" id="header-pjs" style="opacity: 0.7; z-index: 1"></div>
</div>

<div class="logo-ds-flex">

            <div class="status-box-container">
            <div class="status-text" onclick="copyToClipboard('#ip')">
                <div class="text">
                    <div class="top-text"><span class="server-status">Loading...</span></div>
                    <div class="bottom-text">
                        <div class="reel-1"><span id="ip"><?= e(s('server_ip')) ?></span></div>
                        <div class="reel-1">Click to copy IP</div>
                    </div>
                </div>
                <div class="icon">
                    <div class="icon-wrapper">
                        <svg class="creeper" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512"><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zM188.3 147.1c-7.6 4.2-12.3 12.3-12.3 20.9V344c0 8.7 4.7 16.7 12.3 20.9s16.8 4.1 24.3-.5l144-88c7.1-4.4 11.5-12.1 11.5-20.5s-4.4-16.1-11.5-20.5l-144-88c-7.4-4.5-16.7-4.7-24.3-.5z"></path></svg>
                    </div>
                </div>
            </div>
        </div>
    
    <div class="logo-container">
        <a id="logo-link" href="/">
                        <picture>
                <img class="logo animated-logo" alt="<?= e(s('site_name')) ?> Logo" src="<?= asset(s('logo')) ?>">
            </picture>
                    </a>
    </div>

            <div class="discord-box-container">
            <a href="https://discord.gg/<?= e(s('discord_code')) ?>" target="_blank">
                <div class="discord-text">
                    <div class="icon">
                        <div class="icon-wrapper">
                            <svg class="discord" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 245 240">
                                <path class="st0" d="M104.4 103.9c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1.1-6.1-4.5-11.1-10.2-11.1zM140.9 103.9c-5.7 0-10.2 5-10.2 11.1s4.6 11.1 10.2 11.1c5.7 0 10.2-5 10.2-11.1s-4.5-11.1-10.2-11.1z">
                                </path>
                                <path class="st0" d="M189.5 20h-134C44.2 20 35 29.2 35 40.6v135.2c0 11.4 9.2 20.6 20.5 20.6h113.4l-5.3-18.5 12.8 11.9 12.1 11.2 21.5 19V40.6c0-11.4-9.2-20.6-20.5-20.6zm-38.6 130.6s-3.6-4.3-6.6-8.1c13.1-3.7 18.1-11.9 18.1-11.9-4.1 2.7-8 4.6-11.5 5.9-5 2.1-9.8 3.5-14.5 4.3-9.6 1.8-18.4 1.3-25.9-.1-5.7-1.1-10.6-2.7-14.7-4.3-2.3-.9-4.8-2-7.3-3.4-.3-.2-.6-.3-.9-.5-.2-.1-.3-.2-.4-.3-1.8-1-2.8-1.7-2.8-1.7s4.8 8 17.5 11.8c-3 3.8-6.7 8.3-6.7 8.3-22.1-.7-30.5-15.2-30.5-15.2 0-32.2 14.4-58.3 14.4-58.3 14.4-10.8 28.1-10.5 28.1-10.5l1 1.2c-18 5.2-26.3 13.1-26.3 13.1s2.2-1.2 5.9-2.9c10.7-4.7 19.2-6 22.7-6.3.6-.1 1.1-.2 1.7-.2 6.1-.8 13-1 20.2-.2 9.5 1.1 19.7 3.9 30.1 9.6 0 0-7.9-7.5-24.9-12.7l1.4-1.6s13.7-.3 28.1 10.5c0 0 14.4 26.1 14.4 58.3 0 0-8.5 14.5-30.6 15.2z">
                                </path>
                            </svg>
                        </div>
                    </div>
                    <div class="text">
                        <div class="top-text"><span class="discord-status">Loading...</span></div>
                        <div class="bottom-text">
                            <div class="reel-1">discord.gg/<?= e(s('discord_code')) ?></div>
                            <div class="reel-1">Click to join</div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    
</div>

<div class="coldfire-navbar-menu">
    <div class="nav-header">
        <div class="nav-header-text theme-text"><?= e(s('site_name')) ?></div>
        <div id="nav-header-close" class="nav-header-close btn btn-secondary ml-4"><i class="fa-solid fa-xmark"></i></div>
    </div>
    <ul>
                                    <li class="nav-item">
                    <a class="nav-link" href="index.html"><i class="fa-solid fa-house"></i>
                        Home</a>
                </li>
                                                <li class="nav-item">
                    <a class="nav-link" href="rules.html"><i class="fa-solid fa-scale-balanced"></i>
                        Rules</a>
                </li>
                                                <li class="nav-item">
                    <a class="nav-link" href="vote.html"><i class="fa-solid fa-check-to-slot"></i>
                        Vote</a>
                </li>
                                                <li class="nav-item">
                    </li>
                                                <li class="nav-item">
                    <a class="nav-link" href="<?= e(s('store_url')) ?>/" target="_blank"><i class="fa-solid fa-store"></i>
                        Store</a>
                </li>
                                                <li class="nav-item">
                    <a class="nav-link" href="staff.html"><i class="fa-solid fa-clipboard-user"></i>
                        Staff</a>
                </li>
                                                <li class="nav-item">
                    </li>
                                    
        </ul>
    </div>

    <div class="overlay"></div>
            </div>


            <div id="registerModal" class="modal fade register-modal-lg" tabindex="-1" role="dialog" aria-labelledby="registerModal" aria-hidden="true">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="register-menu"></div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="loginRegisterError" tabindex="-1" role="dialog" aria-labelledby="loginRegisterErrorLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modal-title" id="loginRegisterErrorLabel">Error</span>
            </div>
            <div class="modal-body">
            There was an error loading this menu. The website owner needs to follow these steps to fix it:<br>
            1. Make sure the hostname value in core/config.php in FTP matches your site url.<br>
            2. If you are using the www. prefix make sure the force www option is enabled in StaffCP -&gt; Configuration -&gt; General Settings.
            </div>
        </div>
    </div>
</div>

                
                <div class="container" style="margin-top:20px;margin-bottom:30px;max-width:720px;">
    <div class="card" style="background:#1a1a1a;border:none;border-radius:12px;padding:28px 32px;">
        <div style="color:<?= color('primary_color','#911AEE') ?>;font-size:13px;font-weight:600;margin-bottom:6px;"><?= t('vote_label') ?></div>
        <h1 style="color:#fff;font-size:26px;font-weight:600;text-align:center;margin:0 0 20px 0;"><?= t('vote_title') ?></h1>
        
        <div style="display:flex;align-items:center;gap:12px;background:#222;border-radius:8px;padding:14px 18px;margin-bottom:22px;">
            <img src="uploads/vote_key.webp" alt="Vote Key" style="width:40px;height:40px;object-fit:contain;">
            <span style="color:#ccc;font-size:14px;"><?= hl(fv('vote_info')) ?></span>
        </div>
        
        <?php render_vote_links(); ?>
    </div>
</div>

<div class="footer-spacer"></div>

<div class="footer">


<div class="f-large">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 footer-col footer-about">
                    <div class="footer-text-header"><?= t('footer_play_title') ?></div>
                    <p><?= t('footer_play_text') ?></p>
                                            <button class="btn btn-play" onclick="copyToClipboard('#play-ip')" data-toggle="tooltip" title="Click to copy"><span id="play-ip"><?= e(s('server_ip')) ?></span> <i class="fa-solid fa-angles-right"></i></button>
                                    </div>
                <div class="col-lg-4 footer-col">
                    <div class="footer-text-header"><?= t('footer_links_title') ?></div>
                    <a class="footer-link" href="rules.html"><?= t('footer_link_rules') ?></a>
                    <a class="footer-link" href="vote.html"><?= t('footer_link_vote') ?></a>
                    
                                    </div>
                <div class="col-lg-4 footer-col">
                    <div class="footer-text-header"><?= t('footer_store_title') ?></div>
                    <p><?= t('footer_store_text') ?></p>
                    <a href="<?= e(s('store_url')) ?>" class="btn btn-theme other-btn"><?= t('footer_store_btn') ?> <i class="fas fa-shopping-cart"></i></a>
                </div>
            </div>
        </div>
</div>



<div class="f-small">
    <div class="container d-flex">
        <div class="f-copyright">
            <div class="f-top-copy"><span><?= e(s('site_name')) ?> <i class="fa-regular fa-copyright"></i> <?= t('footer_year') ?>.</span> <?= t('footer_rights') ?></div>
            <div class="f-bottom-copy"><?= t('footer_disclaimer') ?></div>
        </div>
            </div>
</div>

</div>

<script type="text/javascript" src="core/assets/plugins/prism/prism.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.min.js"></script>
<script type="text/javascript" src="core/assets/plugins/tinymce_spoiler/js/spoiler.js"></script>
<script type="text/javascript" src="core/assets/vendor/jquery.cookie/jquery.cookie.js"></script>

                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@11.2.0/dist/sweetalert2.all.min.js"></script>

                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/tsparticles@1.39.3/tsparticles.min.js"></script>
<script type="text/javascript">
			var particles = "<?= s('particles_enabled', true) ? 'yes' : 'no' ?>";
			var winter = "no";
			var swal_server_copy = "Now go join the server!";
			var discord_server = "1363913059306836272";
			var mc_server = "<?= e(s('server_ip')) ?>";
			var ds_box = "yes";
			var ds_breakpoint = "1050";
			var users_online = "users online";
			var user_online = "user online";
			var players_online = "players online";
			var player_online = "player online";
			var server_offline = "Server is offline";
		</script>
<script type="text/javascript">var siteName = "<?= e(s('site_name')) ?>", siteURL = "\/", fullSiteUrl = "https:\/\/www.diesiremc.fun\/", page = "vote", pjsPath = "custom/templates/Cobalt/js/particles-settings.php", copied = "Copied!", close = "Close", loading = "Loading...", cookieNotice = "This website uses cookies to enhance your browsing experience. By registering on our website or closing this notice you agree with their use.", cookieAgree = "general\/cookie_agree", noMessages = "No new messages", newMessage1 = "You have 1 new message", newMessagesX = "You have {{count}} new messages", noAlerts = "No new alerts", newAlert1 = "You have 1 new alert", newAlertsX = "You have {{count}} new alerts", debugging = "0", loggedIn = "0", cookie = "0", confirmDelete = "Are you sure you wish to delete this?", offline = "Offline", noPlayersOnline = "There are no players online.", bungeeInstance = "This server is a Bungee instance.", online = "Online", avatarSource = "https:\/\/cravatar.eu\/helmavatar\/{identifier}\/{size}.png", andMoreX = "and {{count}} more", loadingTime = "", route = "\/", csrfToken = "4b68cb0b002bf0d0ab624990c657e47c"</script>

                <script type="text/javascript" src="custom/templates/Cobalt/js/core/core_v_18.js"></script>

                <script type="text/javascript" src="custom/templates/Cobalt/js/core/user_v_5.js"></script>

                <script type="text/javascript" src="custom/templates/Cobalt/js/core/pages_v_5.js"></script>
<script type="text/javascript">$.getJSON('/queries/servers/', function(data) {});</script>
<script type="text/javascript">$.getJSON('/queries/queue/', function(data) {});</script>


<script src="https://instant.page/5.1.0" type="module"></script>


  
<script>
// Discord online count (direct + proxy fallback)
(function(){
  function setDC(n){
    var el = document.querySelector(".discord-status");
    if(!el) return;
    var label = (n === 1) ? "user online" : "users online";
    el.innerHTML = "<span class=\"status-number\">" + n + "</span> " + label;
  }
  function tryFetch(url, parse){
    return fetch(url).then(function(r){ return r.json(); }).then(function(d){
      var n = d.approximate_presence_count || d.presence_count || 0;
      if(parse && typeof d.contents === "string"){ try{ d = JSON.parse(d.contents); n = d.approximate_presence_count||0;}catch(e){} }
      setDC(n);
    });
  }
  tryFetch("https://discord.com/api/v9/invites/<?= e(s('discord_code')) ?>?with_counts=true")
    .catch(function(){ return tryFetch("https://api.allorigins.win/raw?url=" + encodeURIComponent("https://discord.com/api/v9/invites/<?= e(s('discord_code')) ?>?with_counts=true")); })
    .catch(function(){ setDC(0); });
})();
</script>

<?php if (s('show_powered_by', true)): ?>
<div style="text-align:center;padding:14px 0 22px;font-size:12px;opacity:.55;color:#fff;font-family:inherit">Powered by TOME</div>
<?php endif; ?>
</body>
  </html>
