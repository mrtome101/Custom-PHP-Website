<?php
// Editable text blocks + renderers for rules / staff / vote pages.
function fields(): array { static $f = null; return $f ??= (require __DIR__.'/fields.php'); }

function fv(string $k): string {              // saved value or the original default
    $f = fields(); $saved = settings_load()['texts'][$k] ?? null;
    return is_string($saved) ? $saved : (string)($f[$k]['d'] ?? '');
}
function tok(string $s, bool $html = false): string {   // {site_name} etc.
    $banner = asset(s('news_banner', 'uploads/post_images/season1_banner.png'));
    return strtr($s, ['{site_name}'=>e(s('site_name')), '{server_ip}'=>e(s('server_ip')), '{news_banner}'=>$banner]);
}
function t(string $k): string { return e(strtr(fv($k), ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')])); }
function lines(string $k): array { return array_values(array_filter(array_map('trim', preg_split('/\R/', fv($k))), fn($x)=>$x !== '')); }
function hl(string $s): string {              // **bold**  and  [[highlight]]
    $s = e(strtr($s, ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')]));
    $c = color('primary_color', '#911AEE');
    $s = preg_replace('/\*\*(.+?)\*\*/s', '<strong style="color:#fff;">$1</strong>', $s);
    return preg_replace('/\[\[(.+?)\]\]/s', '<span style="color:'.$c.';">$1</span>', $s);
}
function safe_css_color(string $c): string { $c = trim($c); return preg_match('/^#[0-9a-fA-F]{3,8}$/', $c) ? $c : '#FFFFFF'; }
function safe_url(string $u): string { $u = trim($u); return preg_match('~^https?://~i', $u) ? e($u) : '#'; }

function render_rules_home(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <div id="rule-home">
 <h1 style="color:#fff;font-size:24px;font-weight:600;margin:0 0 6px;"><?= t('rules_title') ?></h1>
 <div style="color:#666;font-size:13px;margin-bottom:22px;"><?= t('rules_updated') ?></div>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('rules_intro'))) as $p): if (trim($p) === '') continue; ?>
 <p style="color:#bbb;line-height:1.7;font-size:14.5px;"><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; ?>
 <p style="color:#bbb;"><strong style="color:#fff;"><?= t('rules_signature') ?></strong></p>
 <a href="https://discord.gg/<?= e(s('discord_code')) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;background:<?= $c ?>;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:500;font-size:14px;margin-top:10px;">
 <i class="fa-brands fa-discord"></i> <?= t('rules_join_btn') ?>
 </a>
 </div>
<?php }
function render_rules_list(string $key): void {
    $c = color('primary_color', '#911AEE'); ?>
 <div id="rule-<?= $key ?>" style="display:none;">
 <h2 style="color:#fff;font-size:22px;font-weight:600;margin:0 0 16px;padding-bottom:10px;border-bottom:1px solid #2a2a2a;"><?= t("rules_{$key}_title") ?></h2>
 <p style="color:#bbb;font-size:14px;"><?= t("rules_{$key}_intro") ?></p>
 <ul style="list-style:none;padding:0;margin:0;">
<?php foreach (lines("rules_{$key}_list") as $li): ?>
 <li style="padding:6px 0 6px 18px;position:relative;color:#ccc;font-size:14px;"><span style="color:<?= $c ?>;position:absolute;left:0;">•</span> <?= hl($li) ?></li>
<?php endforeach; ?>
 </ul>
<?php if (trim(fv("rules_{$key}_note")) !== ''): ?>
 <p style="color:#999;font-size:13px;margin-top:14px;"><?= t("rules_{$key}_note") ?></p>
<?php endif; ?>
 </div>
<?php }
function render_staff(): void {
    $groups = []; $cur = null;
    foreach (lines('staff_list') as $ln) {
        if (preg_match('/^#+\s*(.+?)\s*(?:\|\s*(#[0-9a-fA-F]{3,8}))?\s*$/', $ln, $m)) { $cur = count($groups); $groups[] = ['name'=>$m[1], 'color'=>$m[2] ?? '#FFFFFF', 'p'=>[]]; }
        elseif ($cur !== null) $groups[$cur]['p'][] = $ln;
    }
    foreach ($groups as $g): ?>
 <div style="margin-bottom:22px;">
 <div style="color:<?= safe_css_color($g['color']) ?>;font-weight:600;font-size:15px;margin-bottom:10px;"><?= e($g['name']) ?></div>
 <div style="display:flex;flex-wrap:wrap;gap:10px;">
<?php foreach ($g['p'] as $name): $n = preg_replace('/[^A-Za-z0-9_]/', '', $name); ?>
 <div style="background:#222;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;min-width:150px;">
 <img src="https://mc-heads.net/avatar/<?= e($n) ?>/32" style="width:32px;height:32px;border-radius:4px;image-rendering:pixelated;" alt="">
 <span style="color:#ddd;font-size:13px;font-weight:500;"><?= e($name) ?></span>
 </div>
<?php endforeach; ?>
 </div>
 </div>
<?php endforeach;
}
function render_vote_links(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
<?php foreach (lines('vote_links') as $ln): [$label, $url] = array_pad(array_map('trim', explode('|', $ln, 2)), 2, ''); if ($url === '') { $url = $label; } ?>
 <a href="<?= safe_url($url) ?>" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:center;gap:8px;background:<?= $c ?>;color:#fff;text-decoration:none;padding:14px 20px;border-radius:8px;font-weight:600;font-size:14px;"><?= e($label) ?> <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:12px;opacity:0.8;"></i></a>
<?php endforeach; ?>
 </div>
<?php }

function render_news_body(): void { ?>
 <p style="margin:0 0 12px 0;"><img src="<?= asset(s('news_banner', 'uploads/post_images/season1_banner.png')) ?>" alt="" style="width:100%;border-radius:6px;display:block;"></p>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('news_body'))) as $p): if (trim($p) === '') continue; ?>
 <p><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; }
