<?php
require dirname(__DIR__).'/inc/config.php';
session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
$auth = auth_load(); $msg = ''; $err = '';
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
function csrf_ok(): bool { return hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? ''); }
function head(string $t): void { echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($t).'</title><style>'.file_get_contents(__DIR__.'/style.css').'</style></head><body>'; }

if (!$auth) { head('Error'); echo '<div class="login"><h1>Login file missing</h1><p>Create <code>admin/password.php</code> with a user and pass.</p></div></body></html>'; exit; }
if (isset($_GET['logout'])) { setcookie('tome_pv','',time()-3600,'/'); setcookie('tome_pvset','',time()-3600,'/'); session_destroy(); header('Location: index.php'); exit; }

if (empty($_SESSION['in'])) {                   // login
    if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_ok()) {
        usleep(400000);
        if (hash_equals($auth['user'], (string)($_POST['user'] ?? '')) && hash_equals($auth['pass'], (string)($_POST['pass'] ?? ''))) {
            session_regenerate_id(true); $_SESSION['in'] = true; $_SESSION['csrf'] = bin2hex(random_bytes(16)); header('Location: index.php'); exit;
        } $err = 'Wrong username or password.';
    }
    head('Login'); ?><div class="login"><h1>Admin login</h1><p>Sign in to customize your site.</p>
    <?php if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
    <form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
    <input type="text" name="user" placeholder="Username" required><input type="password" name="pass" placeholder="Password" required>
    <button class="btn">Sign in</button></form></div></body></html><?php exit;
}
// logged in: allow live-preview cookie
setcookie('tome_pv', hash('sha256', $auth['hash']), ['path'=>'/','httponly'=>true,'samesite'=>'Strict']);

const DEFAULTS = ['logo'=>'uploads/1024x_HD.png','favicon'=>'uploads/favicons/favicon-32x32.png','hero_bg'=>'uploads/hero-bg.jpg','og_image'=>'uploads/1024x_HD.png','news_banner'=>'uploads/post_images/season1_banner.png'];
function upload_image(string $field, string $old): string {
    if (empty($_FILES[$field]['tmp_name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return $old;
    $f = $_FILES[$field];
    if ($f['size'] > 5*1024*1024) throw new Exception('Image is larger than 5 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $map = ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/gif'=>'gif','image/x-icon'=>'ico','image/vnd.microsoft.icon'=>'ico'];
    if (!isset($map[$mime])) throw new Exception('Only PNG, JPG, WEBP, GIF or ICO images are allowed.');
    if ($map[$mime] !== 'ico' && !@getimagesize($f['tmp_name'])) throw new Exception('That file is not a valid image.');
    $dir = ROOT.'/uploads/custom'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $name = $field.'-'.bin2hex(random_bytes(5)).'.'.$map[$mime];
    if (!@move_uploaded_file($f['tmp_name'], "$dir/$name")) throw new Exception('Could not save the image. Make the "uploads" folder writable.');
    return 'uploads/custom/'.$name;
}
const NUMS = ['particles_count'=>[80,0,300],'particles_speed'=>[2,0.2,12],'particles_size'=>[3,1,12],'particles_distance'=>[150,20,400],'particles_opacity'=>[0.5,0,1],'particles_line_opacity'=>[0.4,0,1],'particles_line_width'=>[1,1,5]];
$fields = fields(); $d = settings_raw();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!csrf_ok()) $err = 'Your session expired. Reload the page and try again.';
    else try {
        foreach (['site_name','server_ip','store_url','discord_code'] as $k) $d[$k] = trim(strip_tags($_POST[$k] ?? ''));
        foreach (['primary_color','bg_color','particles_color','particles_line_color'] as $k) if (preg_match('/^#[0-9a-fA-F]{6}$/', $_POST[$k] ?? '')) $d[$k] = strtoupper($_POST[$k]);
        foreach (['show_powered_by','particles_enabled','particles_follow','particles_lines','particles_hover','particles_click'] as $k) $d[$k] = !empty($_POST[$k]);
        foreach (NUMS as $k => [$def,$lo,$hi]) $d[$k] = max($lo, min($hi, is_numeric($_POST[$k] ?? null) ? 0 + $_POST[$k] : $def));
        foreach (DEFAULTS as $k => $def) $d[$k] = !empty($_POST['reset_'.$k]) ? $def : upload_image($k, $d[$k] ?? $def);
        if (!empty($_POST['reset_texts'])) unset($d['texts']);
        elseif (isset($_POST['tx']) && is_array($_POST['tx'])) {
            $d['texts'] = [];
            foreach ($fields as $k => $f) if (isset($_POST['tx'][$k])) {
                $v = trim(str_replace("\r\n", "\n", (string)$_POST['tx'][$k]));
                $v = strip_tags($v);
                if ($v !== trim($f['d'])) $d['texts'][$k] = $v;
            }
        }
        if (!settings_save($d)) throw new Exception('Could not write data/settings.json. Make the "data" folder writable.');
        setcookie('tome_pvset','',time()-3600,'/');
        $msg = 'Saved! Your site is updated.';
    } catch (Exception $ex) { $err = $ex->getMessage(); }
}
$g = fn($k,$def) => $d[$k] ?? $def;
$presets = [['Purple','#911AEE','#101010'],['Blue','#2F7BFF','#0B101A'],['Cyan','#12D6C9','#0A1515'],['Green','#22C55E','#0C140F'],['Lime','#A3E635','#12150B'],['Orange','#FF7A18','#17100A'],['Red','#EF4444','#170B0B'],['Pink','#EC4899','#160B12'],['Gold','#F5B301','#15120A'],['Mono','#E5E5E5','#0A0A0A']];
function img_field(string $k, string $label, string $hint, array $d): void { global $g; ?>
<div class="card"><h2><?= e($label) ?></h2><p class="sub"><?= e($hint) ?></p>
  <div class="img"><img class="thumb" id="t_<?= $k ?>" src="/<?= e($d[$k] ?? DEFAULTS[$k]) ?>?v=<?= time() ?>" alt="">
    <label class="drop">Click to choose an image<input type="file" name="<?= $k ?>" accept="image/*" data-t="t_<?= $k ?>"></label></div>
  <label class="reset"><input type="checkbox" name="reset_<?= $k ?>" value="1"> Restore original</label></div>
<?php }
function num_field(string $k, string $label, array $d, float $step): void { [$def,$lo,$hi] = NUMS[$k]; $v = $d[$k] ?? $def; ?>
  <label class="f"><span class="rl"><?= e($label) ?> <b id="v_<?= $k ?>"><?= e($v) ?></b></span><input type="range" class="rng" name="<?= $k ?>" data-pv min="<?= $lo ?>" max="<?= $hi ?>" step="<?= $step ?>" value="<?= e($v) ?>" oninput="document.getElementById('v_<?= $k ?>').textContent=this.value"></label>
<?php }
function tog(string $k, string $label, string $sub, bool $on, bool $pv = true): void { ?>
  <label class="switch row"><span><b><?= e($label) ?></b><small><?= e($sub) ?></small></span><input type="checkbox" name="<?= $k ?>" value="1" <?= $pv ? 'data-pv' : '' ?> <?= $on ? 'checked' : '' ?>><span class="tg"></span></label>
<?php }
head('Site Customizer'); ?>
<div class="top"><div class="brand"><span>Site Customizer</span></div><nav><a href="/" target="_blank">View site ↗</a><a href="?logout=1">Log out</a></nav></div>
<div class="wrap"><form method="post" enctype="multipart/form-data" id="f">
<input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
<?php if($msg) echo '<div class="alert ok">✔ '.e($msg).'</div>'; if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
<div class="tabs" id="tabs"><button type="button" data-tab="theme" class="on">🎨 Theme</button><button type="button" data-tab="images">🖼 Images</button><button type="button" data-tab="particles">✨ Particles</button><button type="button" data-tab="info">📝 Info</button><button type="button" data-tab="text">📄 Page text</button><button type="button" data-tab="account">🔑 Login</button></div>

<section data-p="theme">
<div class="card"><h2>Theme</h2><p class="sub">Pick a ready-made theme, or choose any color you like. The preview updates instantly.</p>
  <div class="presets"><?php foreach($presets as $p): ?><button type="button" class="chip" title="<?= e($p[0]) ?>" data-a="<?= $p[1] ?>" data-b="<?= $p[2] ?>"><i style="background:<?= $p[2] ?>"></i><b style="background:<?= $p[1] ?>"></b></button><?php endforeach; ?></div>
  <div class="pick">
    <label>Main color<input type="color" id="primary_color" name="primary_color" data-pv value="<?= e($g('primary_color','#911AEE')) ?>"><div class="hex" id="h1"></div></label>
    <label>Background color<input type="color" id="bg_color" name="bg_color" data-pv value="<?= e($g('bg_color','#101010')) ?>"><div class="hex" id="h2"></div></label>
  </div></div>
<div class="card"><?php tog('show_powered_by','Show "Powered by TOME"','A small credit in the footer. Turn it off any time.', !empty($d['show_powered_by']), false); ?></div>
</section>

<section data-p="images" hidden>
<div class="grid2"><?php img_field('logo','Logo','Transparent PNG looks best.',$d); img_field('favicon','Tab icon','The small icon in the browser tab.',$d); ?></div>
<div class="grid2"><?php img_field('hero_bg','Header background','The big image at the top.',$d); img_field('og_image','Share image','Shown when the link is shared on Discord / WhatsApp.',$d); ?></div>
<?php img_field('news_banner','Home page banner','The wide picture inside the news post on the home page.',$d); ?>
</section>

<section data-p="particles" hidden>
<div class="card"><h2>Moving lines &amp; dots</h2><p class="sub">The animated particles in the background. Changes show in the preview right away.</p>
  <?php tog('particles_enabled','Show particles','Turn the whole animation on or off.', $g('particles_enabled',true)); ?>
  <?php tog('particles_lines','Draw connecting lines','Lines between nearby dots.', $g('particles_lines',true)); ?>
  <?php tog('particles_follow','Use my main theme color','Dots and lines always match the Theme tab.', $g('particles_follow',true)); ?>
  <div class="pick" style="margin-top:12px">
    <label>Dot color<input type="color" id="particles_color" name="particles_color" data-pv value="<?= e($g('particles_color',$g('primary_color','#911AEE'))) ?>"></label>
    <label>Line color<input type="color" id="particles_line_color" name="particles_line_color" data-pv value="<?= e($g('particles_line_color',$g('primary_color','#911AEE'))) ?>"></label>
  </div></div>
<div class="card"><h2>Look &amp; feel</h2>
  <?php num_field('particles_count','Number of dots',$d,5); num_field('particles_speed','Speed',$d,0.2); num_field('particles_size','Dot size',$d,1); num_field('particles_distance','Line length',$d,10); num_field('particles_opacity','Dot brightness',$d,0.05); num_field('particles_line_opacity','Line brightness',$d,0.05); num_field('particles_line_width','Line thickness',$d,1); ?>
  <?php tog('particles_hover','Dots move away from the mouse','', $g('particles_hover',true)); tog('particles_click','Click adds more dots','', $g('particles_click',true)); ?></div>
</section>

<section data-p="info" hidden>
<div class="card"><h2>Info</h2><p class="sub">Names and links used across the site.</p>
  <div class="grid2"><label class="f">Site name<input type="text" id="site_name" name="site_name" data-pv value="<?= e($g('site_name','')) ?>"></label>
  <label class="f">Server IP<input type="text" name="server_ip" value="<?= e($g('server_ip','')) ?>"></label>
  <label class="f">Store link<input type="text" name="store_url" value="<?= e($g('store_url','')) ?>"></label>
  <label class="f">Discord invite code<input type="text" name="discord_code" value="<?= e($g('discord_code','')) ?>"></label></div></div>
</section>

<section data-p="text" hidden>
<div class="card"><h2>Page text</h2><p class="sub">Edit every text on your site. Open a section, change the text and press Save. Use <code>{site_name}</code> to insert your site name automatically.</p>
<?php $cur = null; foreach ($fields as $k => $f):
  if ($f['g'] !== $cur) { if ($cur !== null) echo '</div></details>'; $cur = $f['g']; echo '<details class="acc"><summary>'.e($cur).'</summary><div class="accb">'; }
  $val = $d['texts'][$k] ?? $f['d']; ?>
  <label class="f"><?= e($f['l']) ?>
  <?php if ($f['t'] === 'text'): ?><input type="text" name="tx[<?= e($k) ?>]" value="<?= e($val) ?>">
  <?php else: ?><textarea name="tx[<?= e($k) ?>]" rows="<?= in_array($k,['news_body','rules_intro']) ? 9 : 7 ?>"><?= e($val) ?></textarea><?php endif; ?>
  <?php if (!empty($f['h'])) echo '<small>'.e($f['h']).'</small>'; ?></label>
<?php endforeach; if ($cur !== null) echo '</div></details>'; ?>
  <label class="reset" style="margin-top:14px"><input type="checkbox" name="reset_texts" value="1"> Restore ALL texts to the original</label></div>
</section>

<section data-p="account" hidden>
<div class="card"><h2>Login details</h2><p class="sub">Your username and password live in one simple file:</p>
  <p><code>admin/password.php</code></p>
  <p class="sub">Open it in the panel File Manager, change <code>'user'</code> and <code>'pass'</code>, and save. No need to touch anything else.</p></div>
</section>

<div class="save"><button class="btn">Save changes</button></div>
</form>
<aside><div class="sticky"><div class="pvh"><b>Live preview</b><span><select id="pg"><option value="/">Home</option><option value="/rules/">Rules</option><option value="/staff/">Staff</option><option value="/vote/">Vote</option></select> <a href="#" id="rl">↻</a></span></div><iframe id="pv" src="/"></iframe></div></aside></div>
<script>
const $=id=>document.getElementById(id), pv=$('pv'), pg=$('pg'); let t;
function url(){return pg.value+'?pv='+Date.now();}
function collect(){const o={};document.querySelectorAll('[data-pv]').forEach(i=>{o[i.name]=i.type==='checkbox'?(i.checked?1:0):i.value;});return o;}
function push(){ $('h1').textContent=$('primary_color').value.toUpperCase(); $('h2').textContent=$('bg_color').value.toUpperCase();
  clearTimeout(t); t=setTimeout(()=>{document.cookie='tome_pvset='+encodeURIComponent(JSON.stringify(collect()))+';path=/;max-age=600;SameSite=Strict'; pv.src=url();},400); }
document.querySelectorAll('[data-pv]').forEach(i=>i.addEventListener('input',push)); push();
document.querySelectorAll('.chip').forEach(c=>c.onclick=()=>{ $('primary_color').value=c.dataset.a; $('bg_color').value=c.dataset.b; document.querySelectorAll('.chip').forEach(x=>x.classList.remove('on')); c.classList.add('on'); push(); });
document.querySelectorAll('input[type=file]').forEach(i=>i.addEventListener('change',()=>{ const f=i.files[0]; if(f){ $(i.dataset.t).src=URL.createObjectURL(f); i.parentNode.firstChild.textContent=f.name; } }));
$('rl').onclick=e=>{e.preventDefault(); pv.src=url();}; pg.onchange=()=>pv.src=url();
const tabs=document.querySelectorAll('#tabs button'); function show(n){tabs.forEach(b=>b.classList.toggle('on',b.dataset.tab===n));document.querySelectorAll('section[data-p]').forEach(s=>s.hidden=s.dataset.p!==n);try{sessionStorage.setItem('tab',n)}catch(e){}}
tabs.forEach(b=>b.onclick=()=>show(b.dataset.tab)); try{show(sessionStorage.getItem('tab')||'theme')}catch(e){}
<?php if($msg): ?>document.cookie='tome_pvset=;path=/;max-age=0'; pv.src='/?s='+Date.now();<?php endif; ?>
</script></body></html>
