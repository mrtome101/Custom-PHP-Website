<?php
require dirname(__DIR__, 4) . '/inc/config.php';
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-cache');
$main = color('primary_color', '#911AEE');
$follow = s('particles_follow', true);
$dot  = $follow ? $main : color('particles_color', $main);
$line = $follow ? $main : color('particles_line_color', $main);
$n = fn($k,$d,$lo,$hi) => max($lo, min($hi, (float)s($k, $d)));
echo json_encode([
  'particles' => [
    'number' => ['value' => (int)$n('particles_count', 80, 0, 300), 'density' => ['enable' => true, 'value_area' => 800]],
    'color' => ['value' => $dot], 'shape' => ['type' => in_array(s('particles_shape','circle'), ['circle','edge','triangle','star'], true) ? s('particles_shape','circle') : 'circle'],
    'opacity' => ['value' => $n('particles_opacity', 0.5, 0, 1), 'random' => false],
    'size' => ['value' => $n('particles_size', 3, 1, 12), 'random' => true],
    'line_linked' => ['enable' => (bool)s('particles_lines', true), 'distance' => (int)$n('particles_distance', 150, 20, 400), 'color' => $line, 'opacity' => $n('particles_line_opacity', 0.4, 0, 1), 'width' => (int)$n('particles_line_width', 1, 1, 5)],
    'move' => ['enable' => true, 'speed' => $n('particles_speed', 2, 0.2, 12), 'direction' => 'none', 'random' => false, 'straight' => false, 'out_mode' => 'out', 'bounce' => false],
  ],
  'interactivity' => ['detect_on' => 'canvas', 'events' => ['onhover' => ['enable' => (bool)s('particles_hover', true), 'mode' => 'repulse'], 'onclick' => ['enable' => (bool)s('particles_click', true), 'mode' => 'push'], 'resize' => true],
    'modes' => ['repulse' => ['distance' => 100, 'duration' => 0.4], 'push' => ['particles_nb' => 4]]],
  'retina_detect' => true,
], JSON_UNESCAPED_SLASHES);
