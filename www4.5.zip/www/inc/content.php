<?php
// Editable text blocks + renderers for rules / staff / vote pages.
function fields(): array { static $f = null; return $f ??= (require __DIR__.'/fields.php'); }

function fv(string $k): string {              // saved value or the original default
    $f = fields(); $saved = settings_load()['texts'][$k] ?? null;
    return is_string($saved) ? $saved : (string)($f[$k]['d'] ?? '');
}
function tok(string $s, bool $html = false): string {   // {site_name} etc.
    $banner = asset(s('news_banner', 'uploads/BMxBANNER.png'));
    return strtr($s, ['{site_name}'=>e(s('site_name')), '{server_ip}'=>e(s('server_ip')), '{news_banner}'=>$banner]);
}
function t(string $k): string { return e(strtr(fv($k), ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')])); }
function lines(string $k): array { return array_values(array_filter(array_map('trim', preg_split('/\R/', fv($k))), fn($x)=>$x !== '')); }
function hl(string $s): string {              // **bold**  and  [[highlight]]
    $s = e(strtr($s, ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')]));
    $c = color('primary_color', '#911AEE');
    $s = preg_replace('/\*\*(.+?)\*\*/s', '<strong style="color:#fff;">$1</strong>', $s);
    return preg_replace('/\[\[(.+?)\]\]/s', '<span style="color:'.$c.';">$1</span>', $s);
}
function safe_css_color(string $c): string { $c = trim($c); return preg_match('/^#[0-9a-fA-F]{3,8}$/', $c) ? $c : '#FFFFFF'; }
function safe_url(string $u): string { $u = trim($u); return preg_match('~^https?://~i', $u) ? e($u) : '#'; }

function render_rules_home(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <div id="rule-home">
 <h1 style="color:#fff;font-size:24px;font-weight:600;margin:0 0 6px;"><?= t('rules_title') ?></h1>
 <div style="color:#666;font-size:13px;margin-bottom:22px;"><?= t('rules_updated') ?></div>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('rules_intro'))) as $p): if (trim($p) === '') continue; ?>
 <p style="color:#bbb;line-height:1.7;font-size:14.5px;"><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; ?>
 <p style="color:#bbb;"><strong style="color:#fff;"><?= t('rules_signature') ?></strong></p>
 <a href="https://discord.gg/<?= e(s('discord_code')) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;background:<?= $c ?>;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:500;font-size:14px;margin-top:10px;">
 <i class="fa-brands fa-discord"></i> <?= t('rules_join_btn') ?>
 </a>
 </div>
<?php }
function rules_icons(): array {
    return ['cube'=>'fa-solid fa-cube','discord'=>'fa-brands fa-discord','shield'=>'fa-solid fa-shield-halved','gavel'=>'fa-solid fa-gavel','scale'=>'fa-solid fa-scale-balanced','user'=>'fa-solid fa-user-shield','chat'=>'fa-solid fa-comments','star'=>'fa-solid fa-star','ban'=>'fa-solid fa-ban','heart'=>'fa-solid fa-heart','bolt'=>'fa-solid fa-bolt','flag'=>'fa-solid fa-flag','cart'=>'fa-solid fa-cart-shopping','game'=>'fa-solid fa-gamepad','crown'=>'fa-solid fa-crown','lock'=>'fa-solid fa-lock','fire'=>'fa-solid fa-fire','book'=>'fa-solid fa-book'];
}
function rules_sections(): array {           // saved sections, or the original Minecraft + Discord ones
    $raw = settings_load()['texts']['rules_sections'] ?? null;
    if (is_string($raw)) { $j = json_decode($raw, true); if (is_array($j)) return $j; }
    return [
        ['nav'=>fv('rules_nav_mc'), 'title'=>fv('rules_mc_title'), 'icon'=>'cube', 'intro'=>fv('rules_mc_intro'), 'rules'=>lines('rules_mc_list'), 'note'=>fv('rules_mc_note')],
        ['nav'=>fv('rules_nav_dc'), 'title'=>fv('rules_dc_title'), 'icon'=>'discord', 'intro'=>fv('rules_dc_intro'), 'rules'=>lines('rules_dc_list'), 'note'=>fv('rules_dc_note')],
    ];
}
function tx(string $s): string { return e(strtr($s, ['{site_name}'=>s('site_name'), '{server_ip}'=>s('server_ip')])); }
function render_rules_section(int $i, array $sec): void {
    $c = color('primary_color', '#911AEE'); $title = (string)($sec['title'] ?? ''); $intro = trim((string)($sec['intro'] ?? '')); $note = trim((string)($sec['note'] ?? '')); ?>
 <div id="rule-s<?= $i ?>" style="display:none;">
 <h2 style="color:#fff;font-size:22px;font-weight:600;margin:0 0 16px;padding-bottom:10px;border-bottom:1px solid <?= tint(42) ?>;"><?= tx($title) ?></h2>
<?php if ($intro !== ''): ?> <p style="color:#bbb;font-size:14px;"><?= tx($intro) ?></p>
<?php endif; ?>
 <ul style="list-style:none;padding:0;margin:0;">
<?php foreach ((array)($sec['rules'] ?? []) as $li): if (trim((string)$li) === '') continue; ?>
 <li style="padding:6px 0 6px 18px;position:relative;color:#ccc;font-size:14px;"><span style="color:<?= $c ?>;position:absolute;left:0;">•</span> <?= hl((string)$li) ?></li>
<?php endforeach; ?>
 </ul>
<?php if ($note !== ''): ?> <p style="color:#999;font-size:13px;margin-top:14px;"><?= tx($note) ?></p>
<?php endif; ?>
 </div>
<?php }

function render_staff(): void {
    $groups = []; $cur = null;
    foreach (lines('staff_list') as $ln) {
        if (preg_match('/^#+\s*(.+?)\s*(?:\|\s*(#[0-9a-fA-F]{3,8}))?\s*$/', $ln, $m)) {
            $cur = count($groups);
            $groups[] = ['name'=>$m[1], 'color'=>$m[2] ?? '#FFFFFF', 'p'=>[]];
        } elseif ($cur !== null) {
            $groups[$cur]['p'][] = $ln;
        }
    }
    $profiles = settings_load()['staff_profiles'] ?? [];
    $defaultBanner = asset(s('hero_bg', 'uploads/hero-bg.jpg'));
    $primary = color('primary_color', '#911AEE');
    foreach ($groups as $g):
        $rColor = safe_css_color($g['color']); ?>
 <div style="margin-bottom:24px;">
   <div style="color:<?= $rColor ?>;font-weight:700;font-size:15px;margin-bottom:10px;letter-spacing:.3px;"><?= e($g['name']) ?></div>
   <div style="display:flex;flex-wrap:wrap;gap:12px;">
<?php foreach ($g['p'] as $pIdx => $name):
        $skBase = skin_key($name);
        $rkKey = skin_key($g['name'] . '_' . $name . '_' . $pIdx);
        $rkOldKey = skin_key($g['name'] . '_' . $name);
        $pf = is_array($profiles[$rkKey] ?? null) ? $profiles[$rkKey]
            : (is_array($profiles[$rkOldKey] ?? null) ? $profiles[$rkOldKey]
            : (is_array($profiles[$skBase] ?? null) ? $profiles[$skBase] : []));
        $bannerUrl = (!empty($pf['banner']) && is_file(ROOT.'/'.$pf['banner'])) ? asset($pf['banner']) : $defaultBanner;
        $se = skin_entry($rkKey) ?? skin_entry($rkOldKey) ?? skin_entry($skBase);
        $skinKind = ($se && ($se['kind'] ?? '') === 'skin') ? 'skin' : 'img';
        $skinRaw = ($se && !empty($se['path'])) ? asset($se['path']) : 'https://mc-heads.net/avatar/'.rawurlencode(preg_replace('/[^A-Za-z0-9_]/', '', $name) ?: 'Steve').'/100';
        $discord = (string)($pf['discord'] ?? '');
        $registered = (string)($pf['registered'] ?? '1 months ago');
        $lastSeen = (string)($pf['last_seen'] ?? 'Online');
        $focus = (string)($pf['focus'] ?? $g['name']);
        $bio = (string)($pf['bio'] ?? '');
        $showMsg = !array_key_exists('show_msg', $pf) || !empty($pf['show_msg']);
?>
     <div class="staff-card"
          role="button"
          tabindex="0"
          onclick="openStaffGui(this)"
          onkeydown="if(event.key==='Enter'||event.key===' ')openStaffGui(this)"
          data-name="<?= e($name) ?>"
          data-rank="<?= e($g['name']) ?>"
          data-rank-color="<?= e($rColor) ?>"
          data-banner="<?= e($bannerUrl) ?>"
          data-skin-src="<?= e($skinRaw) ?>"
          data-skin-kind="<?= e($skinKind) ?>"
          data-discord="<?= e($discord) ?>"
          data-registered="<?= e($registered) ?>"
          data-last-seen="<?= e($lastSeen) ?>"
          data-focus="<?= e($focus) ?>"
          data-bio="<?= e($bio) ?>"
          data-show-msg="<?= $showMsg ? '1' : '0' ?>"
          style="background:<?= tint(34) ?>;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:11px 16px;display:flex;align-items:center;gap:11px;min-width:165px;cursor:pointer;position:relative;">
       <?php if ($se && ($se['kind'] ?? '') === 'skin') { $sc = 34/8;
         echo '<span style="position:relative;display:inline-block;flex:none;width:34px;height:34px;border-radius:4px;overflow:hidden">'.skin_layer($se,8,8,8,8,$sc,0,0).skin_layer($se,40,8,8,8,$sc,0,0).'</span>';
       } elseif ($se) {
         echo '<img src="'.asset($se['path']).'" alt="" style="width:34px;height:34px;border-radius:4px;object-fit:cover;image-rendering:pixelated;flex:none">';
       } else {
         render_skin_head($name, 34);
       } ?>
       <div style="display:flex;flex-direction:column;">
         <span style="color:#fff;font-size:13.5px;font-weight:600;"><?= e($name) ?></span>
         <span style="color:rgba(255,255,255,.45);font-size:11px;">Click for profile</span>
       </div>
     </div>
<?php endforeach; ?>
   </div>
 </div>
<?php endforeach; ?>

<!-- Staff Profile GUI Modal (About Only - No Feed / No Forum) -->
<div id="staffGuiOverlay" style="display:none;position:fixed;inset:0;z-index:10050;background:rgba(0,0,0,.82);backdrop-filter:blur(6px);align-items:center;justify-content:center;padding:16px;">
  <div id="staffGuiBox" style="background:<?= tint(22) ?>;border:1px solid rgba(255,255,255,.1);border-radius:14px;width:100%;max-width:760px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.78);position:relative;animation:spModalIn .22s cubic-bezier(.16,1,.3,1);">
    <button type="button" onclick="closeStaffGui()" aria-label="Close" style="position:absolute;top:14px;right:14px;z-index:20;width:36px;height:36px;border-radius:50%;border:1px solid rgba(255,255,255,.16);background:rgba(12,12,16,.72);color:#fff;font-size:18px;cursor:pointer;display:grid;place-items:center;">&times;</button>

    <!-- Custom Top Banner Image -->
    <div id="spGuiBanner" style="height:185px;width:100%;background-size:cover;background-position:center;background-color:<?= tint(30) ?>;position:relative;">
      <div style="position:absolute;inset:0;background:linear-gradient(to bottom, rgba(0,0,0,.1) 35%, <?= tint(22) ?> 100%);"></div>
    </div>

    <!-- Header Card: Left Skin Avatar + Name + Rank Badge -->
    <div style="padding:0 26px;margin-top:-46px;position:relative;z-index:5;">
      <div style="background:<?= tint(28) ?>;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;box-shadow:0 8px 24px rgba(0,0,0,.35);">
        <canvas id="spGuiAvatar" width="56" height="56" style="width:56px;height:56px;border-radius:8px;background:#111;border:2px solid rgba(255,255,255,.12);image-rendering:pixelated;flex:none;"></canvas>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
          <h2 id="spGuiName" style="margin:0;font-size:22px;font-weight:700;color:#ff3b3b;letter-spacing:.2px;">AmaNwastaken</h2>
          <span id="spGuiRank" style="background:#00f0ff;color:#051316;font-weight:800;font-size:12.5px;padding:4px 12px;border-radius:6px;letter-spacing:.4px;">Owner</span>
        </div>
      </div>

      <!-- Single "About" Tab (Forum & Feed completely removed) -->
      <div style="margin-top:14px;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;">
        <div id="spGuiTab" style="padding:9px 4px;color:<?= $primary ?>;font-weight:600;font-size:14px;border-bottom:3px solid <?= $primary ?>;display:inline-flex;align-items:center;gap:7px;">
          <i class="fa-solid fa-circle-info"></i> About
        </div>
      </div>
    </div>

    <!-- Staff Details Body -->
    <div style="padding:20px 26px 26px;">
      <!-- Staff Custom Message Box (Toggleable ON/OFF from Admin) -->
      <div id="spGuiMsgBox" style="display:none;margin-bottom:16px;background:<?= tint(26) ?>;border:1px solid rgba(255,255,255,.08);border-left:3px solid <?= $primary ?>;border-radius:10px;padding:13px 16px;">
        <div id="spGuiBio" style="color:rgba(255,255,255,.88);font-size:14px;line-height:1.65;white-space:pre-line;"></div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;background:<?= tint(26) ?>;padding:14px 16px;border-radius:10px;border:1px solid rgba(255,255,255,.06);">
        <div style="display:flex;align-items:center;gap:12px;">
          <i class="fa-solid fa-id-card" style="font-size:21px;color:rgba(255,255,255,.45);"></i>
          <div>
            <div style="font-size:12px;color:rgba(255,255,255,.5);">Registered:</div>
            <div id="spGuiReg" style="font-size:13.5px;color:#fff;font-weight:600;">1 months ago</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <i class="fa-solid fa-street-view" style="font-size:21px;color:rgba(255,255,255,.45);"></i>
          <div>
            <div style="font-size:12px;color:rgba(255,255,255,.5);">Last Seen:</div>
            <div id="spGuiSeen" style="font-size:13.5px;color:#fff;font-weight:600;">Online</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <i class="fa-solid fa-shield-halved" style="font-size:21px;color:rgba(255,255,255,.45);"></i>
          <div>
            <div style="font-size:12px;color:rgba(255,255,255,.5);">Role:</div>
            <div id="spGuiFocus" style="font-size:13.5px;color:#fff;font-weight:600;">Owner</div>
          </div>
        </div>
        <div id="spGuiDcRow" style="display:none;align-items:center;gap:12px;">
          <i class="fa-brands fa-discord" style="font-size:21px;color:rgba(255,255,255,.45);"></i>
          <div>
            <div style="font-size:12px;color:rgba(255,255,255,.5);">Discord:</div>
            <div id="spGuiDc" style="font-size:13.5px;color:#fff;font-weight:600;"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
@keyframes spModalIn { from { opacity:0; transform:scale(.94) translateY(8px); } to { opacity:1; transform:scale(1) translateY(0); } }
.staff-card { transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease; }
.staff-card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,.45); border-color: <?= $primary ?> !important; }
</style>

<script>
(function(){
  function drawModalSkin(src, kind) {
    var cv = document.getElementById('spGuiAvatar');
    if (!cv) return;
    var ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, cv.width, cv.height);
    var im = new Image();
    im.crossOrigin = 'anonymous';
    im.onload = function() {
      if (kind === 'skin' && im.width % 64 === 0) {
        var f = im.width / 64;
        ctx.drawImage(im, 8*f, 8*f, 8*f, 8*f, 0, 0, cv.width, cv.height);
        ctx.drawImage(im, 40*f, 8*f, 8*f, 8*f, 0, 0, cv.width, cv.height);
      } else {
        ctx.drawImage(im, 0, 0, cv.width, cv.height);
      }
    };
    im.src = src;
  }

  window.openStaffGui = function(el) {
    var d = el.dataset;
    var rColor = d.rankColor || '#00F0FF';
    document.getElementById('spGuiBanner').style.backgroundImage = 'url("' + (d.banner || '') + '")';
    var nameEl = document.getElementById('spGuiName');
    nameEl.textContent = d.name || '';
    nameEl.style.color = '#ff3b3b';

    var rankEl = document.getElementById('spGuiRank');
    rankEl.textContent = d.rank || 'Staff';
    rankEl.style.background = rColor;
    var hex = rColor.replace('#','');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    var r = parseInt(hex.substr(0,2),16)||0, g = parseInt(hex.substr(2,2),16)||0, b = parseInt(hex.substr(4,2),16)||0;
    rankEl.style.color = ((r*299 + g*587 + b*114)/1000) > 145 ? '#061316' : '#ffffff';

    var tabEl = document.getElementById('spGuiTab');
    tabEl.style.color = rColor;
    tabEl.style.borderBottomColor = rColor;

    document.getElementById('spGuiReg').textContent = d.registered || '1 months ago';
    document.getElementById('spGuiSeen').textContent = d.lastSeen || 'Online';
    document.getElementById('spGuiFocus').textContent = d.focus || d.rank || 'Staff';

    var dcRow = document.getElementById('spGuiDcRow');
    if (d.discord && d.discord.trim() !== '') {
      dcRow.style.display = 'flex';
      document.getElementById('spGuiDc').textContent = d.discord;
    } else {
      dcRow.style.display = 'none';
    }

    var msgBox = document.getElementById('spGuiMsgBox');
    var bioEl = document.getElementById('spGuiBio');
    var showMsg = d.showMsg !== '0';
    if (showMsg && d.bio && d.bio.trim() !== '') {
      bioEl.textContent = d.bio;
      msgBox.style.borderLeftColor = rColor;
      msgBox.style.display = 'block';
    } else {
      bioEl.textContent = '';
      msgBox.style.display = 'none';
    }

    drawModalSkin(d.skinSrc, d.skinKind);

    var ov = document.getElementById('staffGuiOverlay');
    ov.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  };

  window.closeStaffGui = function() {
    var ov = document.getElementById('staffGuiOverlay');
    if (ov) ov.style.display = 'none';
    document.body.style.overflow = '';
  };

  var ov = document.getElementById('staffGuiOverlay');
  if (ov) {
    ov.addEventListener('click', function(e) {
      if (e.target === ov) closeStaffGui();
    });
  }
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeStaffGui();
  });
})();
</script>
<?php }

function render_vote_links(): void {
    $c = color('primary_color', '#911AEE'); ?>
 <style>.vote-btn,.staff-card{transition:transform .18s ease,box-shadow .18s ease}.vote-btn:hover{transform:translateY(-3px);box-shadow:0 10px 22px rgba(<?= rgb($c) ?>,.38);filter:brightness(1.06)}.staff-card:hover{transform:translateY(-2px);box-shadow:0 6px 14px rgba(0,0,0,.35)}</style>
 <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
<?php foreach (lines('vote_links') as $ln): [$label, $url] = array_pad(array_map('trim', explode('|', $ln, 2)), 2, ''); if ($url === '') { $url = $label; } ?>
 <a class="vote-btn" href="<?= safe_url($url) ?>" target="_blank" rel="noopener" style="display:flex;align-items:center;justify-content:center;gap:8px;background:<?= $c ?>;color:#fff;text-decoration:none;padding:14px 20px;border-radius:8px;font-weight:600;font-size:14px;"><?= e($label) ?> <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:12px;opacity:0.8;"></i></a>
<?php endforeach; ?>
 </div>
<?php }

function render_news_body(): void { ?>
 <p style="margin:0 0 12px 0;"><img src="<?= asset(s('news_banner', 'uploads/BMxBANNER.png')) ?>" alt="" style="width:100%;border-radius:6px;display:block;"></p>
<?php foreach (preg_split('/\R\s*\R/', trim(fv('news_body'))) as $p): if (trim($p) === '') continue; ?>
 <p><?= nl2br(hl(trim($p))) ?></p>
<?php endforeach; }

function render_credit(): void {
    if (!s('show_powered_by', true)) return; ?>
<div style="display:flex;justify-content:center;padding:14px 0 22px;position:relative;z-index:50">
 <a href="https://github.com/mrtome101" target="_blank" rel="noopener" title="github.com/mrtome101" style="display:inline-flex;align-items:center;gap:9px;color:#fff;opacity:.6;font-size:12.5px;font-family:inherit;text-decoration:none;padding:6px 10px;border-radius:8px">
 <span>Created by TOME</span><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg></a>
</div>
<?php }
function font_choices(): array {
    return ['default'=>'Original', 'Poppins'=>'Poppins', 'Inter'=>'Inter', 'Montserrat'=>'Montserrat', 'Rubik'=>'Rubik', 'Nunito'=>'Nunito', 'Outfit'=>'Outfit', 'Roboto'=>'Roboto', 'Oswald'=>'Oswald', 'Orbitron'=>'Orbitron (techy)', 'Press Start 2P'=>'Press Start 2P (pixel / Minecraft)'];
}
function render_head_extras(): void {
    $css = '';
    if (!s('show_footer_play', true))  $css .= '.footer .footer-about{display:none!important}';
    if (!s('show_footer_links', true)) $css .= '.footer .footer-col:nth-of-type(2){display:none!important}';
    if (!s('show_footer_store', true)) $css .= '.footer .footer-col:nth-of-type(3){display:none!important}';
    if (s('themed_scrollbar', false)) { $m = color('primary_color', '#911AEE'); $css .= "html{scrollbar-color:$m ".color('bg_color','#101010')."}::-webkit-scrollbar{width:11px}::-webkit-scrollbar-track{background:".color('bg_color','#101010')."}::-webkit-scrollbar-thumb{background:$m;border-radius:8px}"; }
    if ($css !== '') echo "<style>$css</style>\n";
    $f = (string)s('font', 'default'); $ok = font_choices();
    if ($f === 'default' || !isset($ok[$f])) return;
    $fam = str_replace(' ', '+', $f); $w = ($f === 'Press Start 2P' || $f === 'Orbitron') ? '' : ':wght@400;500;600;700'; ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=<?= $fam . $w ?>&display=swap">
<style>body, body *:not(i):not([class^="fa-"]):not([class*=" fa-"]):not(svg):not(path){font-family:'<?= e($f) ?>',system-ui,sans-serif !important}</style>
<?php }

// ---- dark panel colours follow the chosen background (keeps original look on the default theme)
function tint(int $lv): string {
    [$r, $g, $b] = array_map('hexdec', str_split(ltrim(color('bg_color', '#101010'), '#'), 2));
    $d = $lv - 16; $cl = fn($x) => max(0, min(255, $x + $d));
    return sprintf('#%02X%02X%02X', $cl($r), $cl($g), $cl($b));
}
// ---- skins
function skin_key(string $n): string { return preg_replace('/[^a-z0-9_]/', '', strtolower($n)); }
function skin_entry(string $key): ?array {
    $e = settings_load()['skins'][$key] ?? null;
    return (is_array($e) && !empty($e['path']) && is_file(ROOT.'/'.$e['path'])) ? $e : null;
}
function skin_layer(array $e, float $x, float $y, float $w, float $h, float $sc, float $left, float $top, bool $flip = false): string {
    $bw = 64*$sc; $bh = 64*$sc*($e['h']/$e['w']);
    return '<span style="position:absolute;left:'.$left.'px;top:'.$top.'px;width:'.($w*$sc).'px;height:'.($h*$sc).'px;background:url('.asset($e['path']).') -'.($x*$sc).'px -'.($y*$sc).'px / '.$bw.'px '.$bh.'px no-repeat;image-rendering:pixelated;'.($flip ? 'transform:scaleX(-1);' : '').'"></span>';
}
function render_skin_head(string $name, int $size = 32): void {
    $e = skin_entry(skin_key($name));
    if ($e && $e['kind'] === 'skin') { $sc = $size/8;
        echo '<span style="position:relative;display:inline-block;flex:none;width:'.$size.'px;height:'.$size.'px;border-radius:4px;overflow:hidden">'.skin_layer($e,8,8,8,8,$sc,0,0).skin_layer($e,40,8,8,8,$sc,0,0).'</span>';
    } elseif ($e) {
        echo '<img src="'.asset($e['path']).'" alt="" style="width:'.$size.'px;height:'.$size.'px;border-radius:4px;object-fit:cover;image-rendering:pixelated;flex:none">';
    } else {
        echo '<img src="https://mc-heads.net/avatar/'.e(preg_replace('/[^A-Za-z0-9_]/', '', $name)).'/'.$size.'" style="width:'.$size.'px;height:'.$size.'px;border-radius:4px;image-rendering:pixelated;" alt="">';
    }
}
function render_home_skin(): void {
    $e = skin_entry('__home'); $name = preg_replace('/[^A-Za-z0-9_]/', '', (string)s('home_skin_name', 'Steve')) ?: 'Steve';
    if ($e && $e['kind'] === 'skin') { $sc = 150/32; $o = $e["h"] / $e["w"];
        $legacy = $o < 0.75;
        echo '<span class="full-body" style="position:relative;display:inline-block;width:'.(16*$sc).'px;height:'.(32*$sc).'px;max-width:none">';
        echo skin_layer($e,8,8,8,8,$sc,4*$sc,0).skin_layer($e,40,8,8,8,$sc,4*$sc,0);
        echo skin_layer($e,20,20,8,12,$sc,4*$sc,8*$sc);
        echo skin_layer($e,44,20,4,12,$sc,0,8*$sc);
        echo $legacy ? skin_layer($e,44,20,4,12,$sc,12*$sc,8*$sc,true) : skin_layer($e,36,52,4,12,$sc,12*$sc,8*$sc);
        echo skin_layer($e,4,20,4,12,$sc,4*$sc,20*$sc);
        echo $legacy ? skin_layer($e,4,20,4,12,$sc,8*$sc,20*$sc,true) : skin_layer($e,20,52,4,12,$sc,8*$sc,20*$sc);
        echo '</span>';
    } elseif ($e) { echo '<img class="full-body" src="'.asset($e['path']).'" alt="">';
    } else { echo '<img class="full-body" src="https://mc-heads.net/body/'.e($name).'/left.png" alt="'.e($name).'">'; }
}
// ---- news link, announcement bar, maintenance mode
function news_href(): string { $l = trim((string)s('news_link', '')); return ($l !== '' && preg_match('~^(https?://|/)~i', $l)) ? ' href="'.e($l).'"' : ''; }
function render_announce(): void {
    $t = trim((string)s('announce_text', '')); if (!s('announce_on', false) || $t === '') return;
    $bg = color('announce_bg', '#19D3DA'); $fg = color('announce_fg', '#021A1C'); $l = trim((string)s('announce_link', ''));
    $inner = e($t); if ($l !== '' && preg_match('~^(https?://|/)~i', $l)) $inner = '<a href="'.e($l).'" style="color:inherit;text-decoration:underline">'.$inner.'</a>'; ?>
<div style="background:<?= $bg ?>;color:<?= $fg ?>;text-align:center;padding:10px 16px;font-size:14px;font-weight:600;position:relative;z-index:9999"><?= $inner ?></div>
<?php }
function is_admin_visitor(): bool { $a = auth_load(); return $a && !empty($_COOKIE['tome_pv']) && hash_equals(hash('sha256', $a['hash']), (string)$_COOKIE['tome_pv']); }
function maintenance_check(): void {
    if (!s('maintenance', false)) return;
    if (isset($_GET['pv']) && is_admin_visitor()) return;   // only the live-preview frame inside /admin; nobody else gets past

    http_response_code(503); header('Retry-After: 3600'); $c = color('primary_color', '#911AEE'); $bg = color('bg_color', '#101010'); $rgb = rgb($c); ?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e(s('site_name')) ?></title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:<?= $bg ?>;color:#fff;font-family:system-ui,Segoe UI,Roboto,sans-serif;text-align:center;padding:24px;overflow:hidden;position:relative}
body:before{content:"";position:absolute;width:520px;height:520px;max-width:90vw;max-height:90vw;border-radius:50%;background:radial-gradient(circle,rgba(<?= $rgb ?>,.18),transparent 70%);top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none}
.b{position:relative;max-width:520px}
.code{font-size:clamp(88px,22vw,168px);font-weight:800;line-height:1;letter-spacing:4px;margin:0;color:<?= $c ?>;opacity:.9;text-shadow:0 0 40px rgba(<?= $rgb ?>,.35)}
.b h1{margin:14px 0 8px;font-size:clamp(18px,4vw,24px);font-weight:600;color:rgba(255,255,255,.9)}
.b p{margin:0;font-size:15px;line-height:1.6;color:rgba(255,255,255,.55)}
</style></head>
<body><div class="b"><div class="code">404</div><h1><?= e(s('maint_title', 'We will be back soon')) ?></h1><p><?= nl2br(e(s('maint_text', 'The website is being updated. Please check back in a little while.'))) ?></p></div></body></html>
<?php exit; }
