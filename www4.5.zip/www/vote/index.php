<?php require dirname(__DIR__).'/vote.php';
