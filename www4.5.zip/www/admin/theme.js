/* Shared admin theme + effects.
   Loaded on the login page AND on the panel, so the theme works on every admin page. */
(function () {
  'use strict';
  var ATH = [['dark', 'Aqua Dark', '#19d3da'], ['light', 'Light', '#0ea5b0'], ['purple', 'Purple', '#a855f7'], ['blue', 'Blue', '#4f8cff'],
             ['green', 'Green', '#22c55e'], ['orange', 'Orange', '#ff8a1f'], ['pink', 'Pink', '#ec4899'], ['slate', 'Slate', '#cbd5e1']];
  var body = document.body;

  function current() { try { return localStorage.getItem('adm') || 'dark'; } catch (e) { return 'dark'; } }
  function paint(n) {
    body.className = body.className.replace(/\b(light|th-\w+)\b/g, '').replace(/\s+/g, ' ').trim();
    if (n === 'light') body.classList.add('light'); else if (n !== 'dark') body.classList.add('th-' + n);
    document.documentElement.style.colorScheme = n === 'light' ? 'light' : 'dark';
  }
  function setTheme(n) {
    if (!ATH.some(function (t) { return t[0] === n; })) n = 'dark';
    paint(n);
    try { localStorage.setItem('adm', n); } catch (e) {}
    document.dispatchEvent(new CustomEvent('admthemechange', { detail: n }));
  }
  window.setTheme = setTheme;
  window.ADM_THEMES = ATH;
  paint(current());
  window.addEventListener('storage', function (e) { if (e.key === 'adm') { paint(current()); document.dispatchEvent(new CustomEvent('admthemechange', { detail: current() })); } });

  function markActive() {
    var c = current();
    [].forEach.call(document.querySelectorAll('[data-th]'), function (el) { el.classList.toggle('on', el.dataset.th === c); });
  }
  document.addEventListener('admthemechange', markActive);

  /* ---- big theme cards (Admin / Theme tab) ---- */
  var grid = document.getElementById('adm-theme-cards');
  if (grid) ATH.forEach(function (t) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'adm-th-card'; b.dataset.th = t[0];
    b.innerHTML = '<span class="adm-th-swatch" style="background:' + t[2] + ';box-shadow:0 0 14px ' + t[2] + '66"></span><span class="adm-th-name">' + t[1] + '</span>';
    b.onclick = function () { setTheme(t[0]); };
    grid.appendChild(b);
  });

  /* ---- quick theme popover (palette button on every page) ---- */
  var pop = document.createElement('div');
  pop.className = 'thp'; pop.id = 'thp'; pop.hidden = true; pop.setAttribute('role', 'menu');
  ATH.forEach(function (t) {
    var b = document.createElement('button');
    b.type = 'button'; b.dataset.th = t[0]; b.setAttribute('role', 'menuitemradio');
    b.innerHTML = '<i style="background:' + t[2] + '"></i>' + t[1];
    b.onclick = function () { setTheme(t[0]); };
    pop.appendChild(b);
  });
  body.appendChild(pop);
  function place(btn) {
    var r = btn.getBoundingClientRect(), pw = pop.offsetWidth || 230, ph = pop.offsetHeight || 170, m = 8;
    var left = Math.min(Math.max(m, r.left), window.innerWidth - pw - m);
    var top = r.top - ph - m; if (top < m) top = Math.min(r.bottom + m, window.innerHeight - ph - m);
    pop.style.left = left + 'px'; pop.style.top = Math.max(m, top) + 'px';
  }
  var openBtn = null;
  function closePop() { pop.hidden = true; openBtn = null; }
  [].forEach.call(document.querySelectorAll('[data-theme-open]'), function (btn) {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (!pop.hidden && openBtn === btn) { closePop(); return; }
      openBtn = btn; pop.hidden = false; place(btn); markActive();
    });
  });
  document.addEventListener('click', function (e) { if (!pop.hidden && !pop.contains(e.target)) closePop(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });
  window.addEventListener('resize', function () { if (openBtn) place(openBtn); });
  markActive();

  /* ---- toggleable effects ---- */
  var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var DEF = { particles: !calm, btnShine: true, cardLift: true, navSlide: true, clickRipple: !calm, savePulse: !calm };
  var st = {}; for (var k in DEF) st[k] = DEF[k];
  try { var raw = localStorage.getItem('adm_fx_v1'); if (raw) { var o = JSON.parse(raw); for (var k2 in o) st[k2] = o[k2]; } } catch (e) {}
  var clsMap = { particles: 'afx-particles', btnShine: 'afx-btn-shine', cardLift: 'afx-card-lift', navSlide: 'afx-nav-slide', clickRipple: 'afx-click-ripple', savePulse: 'afx-save-pulse' };
  var loop = null;
  function applyFx() {
    Object.keys(clsMap).forEach(function (k) { body.classList.toggle(clsMap[k], !!st[k]); });
    [].forEach.call(document.querySelectorAll('[data-adm-fx]'), function (el) { el.checked = !!st[el.dataset.admFx]; });
    if (st.particles) startParticles(); else stopParticles();
  }
  [].forEach.call(document.querySelectorAll('[data-adm-fx]'), function (el) {
    el.addEventListener('change', function () {
      st[el.dataset.admFx] = el.checked;
      try { localStorage.setItem('adm_fx_v1', JSON.stringify(st)); } catch (e) {}
      applyFx();
    });
  });

  document.addEventListener('click', function (e) {
    if (!st.clickRipple) return;
    if (!e.target.closest('button,a,.chip,.drop')) return;
    var r = document.createElement('span');
    r.className = 'adm-click-burst'; r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
    body.appendChild(r); setTimeout(function () { r.remove(); }, 520);
  });

  /* ambient particles behind the panel */
  var cv = document.getElementById('adm-bg-particles'), ctx = cv && cv.getContext('2d'), W = 0, H = 0, pts = [];
  function size() { W = cv.width = window.innerWidth; H = cv.height = window.innerHeight; }
  function seed() {
    var n = Math.min(48, Math.max(22, Math.floor(W * H / 32000))); pts = [];
    for (var i = 0; i < n; i++) pts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .38, vy: (Math.random() - .5) * .38, r: 1.2 + Math.random() * 1.8 });
  }
  function tick() {
    ctx.clearRect(0, 0, W, H);
    var col = getComputedStyle(body).getPropertyValue('--aqua').trim() || '#19d3da';
    ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineWidth = 1;
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i]; p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.globalAlpha = .35; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
      for (var j = i + 1; j < pts.length; j++) {
        var q = pts[j], d = Math.hypot(p.x - q.x, p.y - q.y);
        if (d < 125) { ctx.globalAlpha = (1 - d / 125) * .14; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
      }
    }
    loop = requestAnimationFrame(tick);
  }
  function startParticles() { if (!cv || loop) return; size(); if (!pts.length) seed(); loop = requestAnimationFrame(tick); }
  function stopParticles() { if (loop) { cancelAnimationFrame(loop); loop = null; } if (ctx) ctx.clearRect(0, 0, W, H); }
  if (cv) window.addEventListener('resize', function () { size(); seed(); });
  applyFx();
})();
