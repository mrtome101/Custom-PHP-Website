/* Live Earth radar (admin sidebar).
   Dot-matrix globe built from a real land mask, sharp on HiDPI screens, resizes with the sidebar,
   follows the admin theme, drag to spin, pauses when hidden. */
(function () {
  'use strict';
  var LAND = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH///8AEf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH////n////////AAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAB/////////////wAAAAA/wAAD4AAAAAAP4AAAAAAAAAAAAAAAAAAAAAAAAAAA///+A////////AAAAD//wAAAAAAAAAAH8gAAAAAAAAAAAAAAAAAAAAAAAcH3P//5////////+AAAAB/+AAAAAAAAAAAAH4AAAAAAAAAAAAAAAAAAAAAA8cABwP/A////////+AAAAAPHAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAH+DB/+//Af///////+AAAAAAAAAAAAAf4AAAAP/+AAAAAAAAAAAAAAAAAAAAAP/x/3/8AAAf/////+AAAAAAAAAAAAP+AAAB////AAAB/uAAAAAAAAAAAAAAeA8AA8/8AAAP/////8AAAAAAAAAAAAfAAAAP///8AAAAgBAAAAAAAAAAAAAAf+AYe+d/gAAD/////8AAAAAAAAAAAB4AAAP/////+HwAPAAAAAAAAAAAAAAA//+4/4//wAAB/////wAAAAAAAAAAADwAHt////////4Af4AAAAAwAABAAAAAff/8P4///AAD/////wAAAAAAAAAAAHwAf/////////4///wAAABAAA//wAACAP//B8f//8AB/////wAAAAAAF/gAAAIA/v/////////////8AAAAAB///+P//n//v+D4f+AB/////AAAAAAA//8AAAA+f////////////////v+wAf////////5+Hfz4f+AAf///4AAAAAAD///4OH/////////////////////+AH/////////////4Z/wA///4AAAAAAAP///+O////v//////////////////4P/////////////wD/8A///wAwYAAAAf///+////////////////////////8//////////////A/+4Af/8AA/8AAAA/+f+D///////////////////////Bwf/////////////x//gAP/wAAf8AAAD/9/+f//////////////////////+AOB////////////HcA/gAP/gAADgAAAP/z/////////////////////////+AAH///////////8Ay6PgAD/AAAAAAAB//H//////////////////////////AAP///////////4AA/gAAD/AAAAAAAB//H//////////////////////3v/AAAf//3////////wAA/4AAAOAAAAAAAB//n//////////////////////A/8AAAB/7gH///////wAA/4wAAAAAAAAAAB//g/////////////////////+D4AAAAAv4AA///////4AA//4AAAAAAAAA4A5+B///////////////////8AAPgAAAAAD8AAD//////9AAf/8AAAAAAAAA8AG+H///////////////////wAA/gAAAAAOAAAB///////wAf/+AAAAAAAAA8AO8H///////////////////AAB/gAAAAB4AAAA///////+A///AAAAAAAAA+AN4H//////////////////+AAB/AAAAAGAAAAAf///////z///4AAAAAAAHPAOn///////////////////+AAB/AAAAAAAAAABP///////x///8AAAAAAAPfB//////////////////////+AB+AAAAAAAAAAAn///////5///+AAAAAAAPfz///////////////////////AA4AAAAAAAAAAAD///////////+AAAAAAAEfn///////////////////////AAwAAAAAAAAAAAH///////////sAAAAAAAA8f//////////////////////7AAAAAAAAAAAAAAB/////////+MPAAAAAAAAD///////////////////////7gAAAAAAAAAAAAAAf/////////wfgAAAAAAAf///////////////////////yAAAAAAAAAAAAAAAf/////////gfwAAAAAAAH///////////////////////yAAAAAAAAAAAAAAAP/////////9AgAAAAAAAD//////v/x//////////////jAAAAAAAAAAAAAAAP//////////AAAAAAAAAB/////P//B//////////////AAAAAAAAAAAAAAAAP////////+4AAAAAAAAAD//n/+Gf+H/////////////+HAAAAAAAAAAAAAAAf////////wgAAAAAAAAH//zz/+AH/H/////////////4PwAAAAAAAAAAAAAAf////////wAAAAAAAAAH/4N4/8AB/D////////////+APAAAAAAAAAAAAAAAP////////wAAAAAAAAAH/4E+f+fh/g////////////8AMAAAAAAAAAAAAAAAf///////+AAAAAAAAAAH/gMPfv///x////////////8AMAAAAAAAAAAAAAAAP///////8AAAAAAAAAAP/AMGPP///h///////////bwAMAAAAAAAAAAAAAAAP///////4AAAAAAAAAAP/AAGHP///g//////////8B4AcAAAAAAAAAAAAAAAH///////4AAAAAAAAAAH+AE8HH///w//////////+x4A4AAAAAAAAAAAAAAAD///////wAAAAAAAAAAB8/+ACD///////////////w8D4AAAAAAAAAAAAAAAB///////4AAAAAAAAAAA7/+AAwE//////////////A8/4AAAAAAAAAAAAAAAB///////gAAAAAAAAAAB//+AAAJ//////////////Ax/gAAAAAAAAAAAAAAAAP//////AAAAAAAAAAAD//+AAAB//////////////gH8AAAAAAAAAAAAAAAAAH/////8AAAAAAAAAAAP///4OAB//////////////gDAAAAAAAAAAAAAAAAAAH/////4AAAAAAAAAAAP///8P87//////////////wDAAAAAAAAAAAAAAAAAADf////4AAAAAAAAAAAP/////////////////////wAAAAAAAAAAAAAAAAAAADf///i4AAAAAAAAAAAP/////////v///////////wAAAAAAAAAAAAAAAAAAABv//gAcAAAAAAAAAAA//////////n///////////wAAAAAAAAAAAAAAAAAAAB3/+AAcAAAAAAAAAAD///////9//j///////////gAAAAAAAAAAAAAAAAAAAA7/+AANgAAAAAAAAAH///////8//wv//////////AAAAAAAAAAAAAAAAAAAAAZ/+AAMAAAAAAAAAAH///////+f/8f//////////AAAAAAAAAAAAAAAAAAAAAM/+AABgAAAAAAAAAP////////f/84Af///////+wAAAAAAAAAAAAAAAAAAAAGf+AAAAAAAAAAAAAP////////P//+AP///////8wAAAAAAAAAAAAAAAAAAAAAP8AA/AAAAAAAAAAf////////n///AH///////ggAAAAAAAAAAAACAAAAAAAAP+A4DwAAAAAAAAAf////////n///AH//+P//8AAAAAAAAAAAAAABgAAAAAAAP+B4A8AAAAAAAAAf////////n//+AAf/4P/+IAAAAAAAAAAAAAAAgAAAAAAAH/B4AB4AAAAAAAAf////////z//8AAf/wH/84AAAAAAAAAAAAAAAAAAAAAAAD//wAj9AAAAAAAAf////////x//4AAf/AD/8QAwAAAAAAAAAAAAAAAAAAAAAA//wAgAAAAAAAAAf////////4//wAAf+AD/+AA4AAAAAAAAAAAAAAAAAAAAAAP/wAAAAAAAAAAAf////////4//AAAf8AD//AA4AAAAAAAAAAAAAAAAAAAAAABP/gAAAAAAAAAAf////////8/8AAAP4ABf/gAwAAAAAAAAAAAAAAAAAAAAAAAD/gAAAAAAAAAA/////////+fwAAAPwAAP/gA4AAAAAAAAAAAAAAAAAAAAAAAB/gAAAAAAAAAAf//////////AAAAP4AAP/wA8AAAAAAAAAAAAAAAAAAAAAAAAPgAgAAAAAAAAf/////////4AAAAHwAAP/wATAAAAAAAAAAAAAAAAAAAAAAAAHgF4AAAAAAAAP/////////w4AAAHwAAMfgALAAAAAAAAAAAAAAAAAAAAAAAADgP/+AAAAAAAH//////////4AAADwAAMfABOAAAAAAAAAAAAAAAAAAAAAAAABzP/+AAAAAAAD//////////4AAADoAAMGACNAAAAAAAAAAAAAAAAAAAAAAAAA////AAAAAAAB//////////4AAABcAAOAAEHgAAAAAAAAAAAAAAAAAAAAAAAAM///wAAAAAAB//////////wAAAAcAAGAAAPgAAAAAAAAAAAAAAAAAAAAAAAAA///4AAAAAAA//////////gAAAAMAADAAMDgAAAAAAAAAAAAAAAAAAAAAAAAA////gAAAAAAP/h///////gAAAAAABDgAeAAAAAAAAAAAAAAAAAAAAAAAAAAA////4AAAAAAHAB///////AAAAAAAB7wA+AAAAAAAAAAAAAAAAAAAAAAAAAAA////4AAAAAAAAAH/////+AAAAAAAAdwB8AAAAAAAAAAAAAAAAAAAAAAAAAAB////8AAAAAAAAAH/////+AAAAAAAAfwH8AAAAAAAAAAAAAAAAAAAAAAAAAAB////8AAAAAAAAAH/////4AAAAAAAAPwf+AYAAAAAAAAAAAAAAAAAAAAAAAAD////8AAAAAAAAAH/////wAAAAAAAAHwf8+YAAAAAAAAAAAAAAAAAAAAAAAAH/////gAAAAAAAAH/////gAAAAAAAADwf9gRwAAAAAAAAAAAAAAAAAAAAAAAH/////4AAAAAAAAH/////AAAAAAAAAD4P54BxgAAAAAAAAAAAAAAAAAAAAAAH//////AAAAAAAAH////+AAAAAAAAAB8P5wA74AAAAAAAAAAAAAAAAAAAAAAH//////8AAAAAAAD////8AAAAAAAAAA8D54u//AIAAAAAAAAAAAAAAAAAAAAP//////+AAAAAAAB////8AAAAAAAAAAcAB4AH/wYAAAAAAAAAAAAAAAAAAAAH///////gAAAAAAA////4AAAAAAAAAAMABoAJ/7yAAAAAAAAAAAAAAAAAAAAH///////gAAAAAAA////4AAAAAAAAAAHsAAAI/9hgAAAAAAAAAAAAAAAAAAAD///////wAAAAAAA////8AAAAAAAAAAD+AAAA/8AIAAAAAAAAAAAAAAAAAAAB///////gAAAAAAAf///8AAAAAAAAAAAHm5gAvOAEAAAAAAAAAAAAAAAAAAAB///////gAAAAAAAf///8AAAAAAAAAAAABjAACHAHAAAAAAAAAAAAAAAAAAAA///////AAAAAAAAf///+AAAAAAAAAAAAAAAAADgBAAAAAAAAAAAAAAAAAAAA//////+AAAAAAAAf///+AAAAAAAAAAAAAAAwCAAAAAAAAAAAAAAAAAAAAAAAf/////8AAAAAAAAf///+AQAAAAAAAAAAAAD+HAAAAAAAAAAAAAAAAAAAAAAAf/////8AAAAAAAA////+AwAAAAAAAAAAAAD+HAAAAAAAAAAAAAAAAAAAAAAAP/////4AAAAAAAA////+BwAAAAAAAAAAAB/8HgAAAAAAAAAAAAAAAAAAAAAAH/////4AAAAAAAA////+D4AAAAAAAAAAAD/+HwAADAAAAAAAAAAAAAAAAAAAD/////4AAAAAAAB////8PwAAAAAAAAAAAH//HwAABABAAAAAAAAAAAAAAAAAA/////4AAAAAAAB////wPwAAAAAAAAAAAP///wAAAAGAAAAAAAAAAAAAAAAAAf////4AAAAAAAA////gPwAAAAAAAAAAAf///4AAAAAAAAAAAAAAAAAAAAAAAP////wAAAAAAAA////APgAAAAAAAAAAA////8AAAAAAAAAAAAAAAAAAAAAAAP////wAAAAAAAAf//+APgAAAAAAAAAAP////+AAIAAAAAAAAAAAAAAAAAAAAP////gAAAAAAAAf//+AfgAAAAAAAAAAf/////AAGAAAAAAAAAAAAAAAAAAAAf////gAAAAAAAAP///AfAAAAAAAAAAB//////gACAAAAAAAAAAAAAAAAAAAAf///8AAAAAAAAAP///AfAAAAAAAAAAB//////gAAAAAAAAAAAAAAAAAAAAAAf///gAAAAAAAAAP//+APAAAAAAAAAAB//////4AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAP//4AEAAAAAAAAAAB//////4AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAH//4AAAAAAAAAAAAB//////4AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAH//4AAAAAAAAAAAAA//////8AAAAAAAAAAAAAAAAAAAAAA///+AAAAAAAAAAD//4AAAAAAAAAAAAA//////8AAAAAAAAAAAAAAAAAAAAAA///8AAAAAAAAAAB//wAAAAAAAAAAAAAf/////8AAAAAAAAAAAAAAAAAAAAAA///8AAAAAAAAAAB//gAAAAAAAAAAAAAf/////4AAAAAAAAAAAAAAAAAAAAAA///4AAAAAAAAAAA//AAAAAAAAAAAAAAf/////4AAAAAAAAAAAAAAAAAAAAAA///wAAAAAAAAAAA/+AAAAAAAAAAAAAAf/Af//4AAAAAAAAAAAAAAAAAAAAAA///gAAAAAAAAAAA/4AAAAAAAAAAAAAAf8AH//wAAAAAAAAAAAAAAAAAAAAAA///AAAAAAAAAAAAcAAAAAAAAAAAAAAAfAAF//gAABAAAAAAAAAAAAAAAAAAB//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//gAABgAAAAAAAAAAAAAAAAAB//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/AAAAwAAAAAAAAAAAAAAAAAD//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/AAAAyAAAAAAAAAAAAAAAAAD//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHYAAAA+AAAAAAAAAAAAAAAAAD/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAAAAAAAAAAAAAAAD/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYAAAAAAAAAAAAAAAAAD/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAADwAAAAAAAAAAAAAAAAAH/4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcAAAHAAAAAAAAAAAAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAeAAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAAAAAAAAAAAAAAAAH+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAAAAAAAAAAAAAAAAAP+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+AAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH4BwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAB8AAAAAAAAAAAAAAAAAAH8AAAAGAB8P4P3+AAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAD//nAAH//////////wAAAAAAAAAAAAAAAAAAAAAAADwAAAAAAAAAAAAAAACB////8A////////////yAAAAAAAAAAAAAAAAAAAAAA/4AAAAAAAAAAAAAAAf3////8H/////////////4AAAAAAAAAAAAAAAAAAAAA/8AAAAAAAAAAB//////////4f//////////////wAAAAAAAAAAAAAAAgAAAH/+AAAAAAAAf////////////5////////////////4AAAAAAAAAAAAAB/AAAF7+AAAAAAAD//////////////////////////////4AAAAAAAAABngAD///3z/+AAAAAAAP//////////////////////////////wAAAAAAAA////8A//////8AAAAAAAP/////////////////////////////+AAAAAAAD/////////////wAAAAAAH//////////////////////////////4AAAAAAAP////////////wAAAAAAf///////////////////////////////wAAAAAH/////////////8AAAAAAH////////////////////////////////wAAAADz/////////////gAAAD+A/////////////////////////////////+AAAAB4D////////////gABAH+A/////////////////////////////////AAAAAAAAP////////////g/A/8AB///////////////////////////////+AAAAAAA///////////////4ADg//////////////////////////////////AAAAAAAH///////////////j////////////////////////////////////8AAAAAAP/////////////////////////////////////////////////////gA//gAA///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////';
  var cv = document.getElementById('er-globe-cv'), box = document.getElementById('earth-radar-box');
  var elC = document.getElementById('er-country'), elI = document.getElementById('er-ip');
  if (!cv || !box || !cv.getContext) return;
  var ctx = cv.getContext('2d');
  var calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var TAU = Math.PI * 2;

  /* ---------- theme ---------- */
  var PAL = {
    dark:   { accent: '#19d3da', deep: '#07171d', pin: '#ff3b6b' },
    light:  { accent: '#0ea5b0', deep: '#0a2d36', pin: '#e11d48' },
    purple: { accent: '#a855f7', deep: '#160b29', pin: '#38bdf8' },
    blue:   { accent: '#4f8cff', deep: '#0b1836', pin: '#facc15' },
    green:  { accent: '#22c55e', deep: '#082112', pin: '#fb7185' },
    orange: { accent: '#ff8a1f', deep: '#241305', pin: '#38bdf8' },
    pink:   { accent: '#ec4899', deep: '#240919', pin: '#facc15' },
    slate:  { accent: '#cbd5e1', deep: '#12161f', pin: '#ff3b6b' }
  };
  function rgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/./g, '$&$&'); var n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  var th;
  function readTheme() {
    var key = 'dark', cl = document.body.classList;
    if (cl.contains('light')) key = 'light'; else for (var k in PAL) if (cl.contains('th-' + k)) { key = k; break; }
    var b = PAL[key] || PAL.dark, css = getComputedStyle(document.body).getPropertyValue('--aqua').trim();
    th = { acc: rgb(/^#[0-9a-f]{3,6}$/i.test(css) ? css : b.accent), deep: rgb(b.deep), pin: rgb(b.pin), light: key === 'light' };
    box.style.setProperty('--er-accent', rgba(th.acc, 1));
    box.style.setProperty('--er-glow', rgba(th.acc, .28));
    redraw();
  }

  /* ---------- land dots (from a 1-degree land mask) ---------- */
  var bin = atob(LAND), MW = 360, MH = 180;
  function isLand(lat, lon) {
    var x = Math.floor(lon + 180), y = Math.floor(90 - lat);
    x = x < 0 ? 0 : x >= MW ? MW - 1 : x; y = y < 0 ? 0 : y >= MH ? MH - 1 : y;
    var i = y * MW + x; return (bin.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1;
  }
  var DX = [], DY = [], DZ = [];
  (function () {
    var step = 3, row = 0;
    for (var lat = -78; lat <= 84; lat += step, row++) {
      var la = lat * Math.PI / 180, cl = Math.cos(la), n = Math.max(1, Math.round(360 * cl / step));
      for (var i = 0; i < n; i++) {
        var lon = -180 + (i + (row % 2 ? .5 : 0)) * 360 / n;
        if (!isLand(lat, lon)) continue;
        var lr = lon * Math.PI / 180;
        DX.push(cl * Math.sin(lr)); DY.push(-Math.sin(la)); DZ.push(cl * Math.cos(lr));
      }
    }
  })();
  var NB = 6, bx = [], by = [], br = [], bn = [];
  for (var q = 0; q < NB; q++) { bx.push(new Float32Array(DX.length)); by.push(new Float32Array(DX.length)); br.push(new Float32Array(DX.length)); bn.push(0); }

  /* ---------- state ---------- */
  var W = 0, H = 0, dpr = 1;
  var yaw = 0.9, vel = 0, spin = 0.5, drag = false, hover = false, lastX = 0;
  var focus = 0, hold = 0, target = 0, mk = null, running = true, raf = 0, lastTs = 0;
  var TILT = 0.36, cT = Math.cos(TILT), sT = Math.sin(TILT);
  var LX = -0.45, LY = -0.38, LZ = 0.81;
  var stars = []; (function () { var s = 7; for (var i = 0; i < 26; i++) { s = (s * 9301 + 49297) % 233280; var a = s / 233280; s = (s * 9301 + 49297) % 233280; stars.push([a, s / 233280, .5 + (i % 3) * .35, i]); } })();

  function fit() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = box.clientWidth; H = box.clientHeight;
    cv.width = Math.max(1, Math.round(W * dpr)); cv.height = Math.max(1, Math.round(H * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function wrap(a) { return ((a + Math.PI) % TAU + TAU) % TAU - Math.PI; }
  function view(x0, y0, z0) {            // yaw then tilt -> screen space (z>0 faces the viewer)
    var cy = Math.cos(yaw), sy = Math.sin(yaw);
    var x = x0 * cy + z0 * sy, z = z0 * cy - x0 * sy;
    return [x, y0 * cT + z * sT, -y0 * sT + z * cT];
  }
  function ring(cx, cy, rx, ry, half, alpha, sat) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-.38);
    ctx.strokeStyle = rgba(th.acc, alpha); ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
    ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, half ? 0 : Math.PI, half ? Math.PI : TAU); ctx.stroke(); ctx.setLineDash([]);
    var s = Math.sin(sat);
    if ((s > 0) === !!half) {
      var px = rx * Math.cos(sat), py = ry * s;
      ctx.fillStyle = rgba(th.acc, .25); ctx.beginPath(); ctx.arc(px, py, 4.2, 0, TAU); ctx.fill();
      ctx.fillStyle = th.light ? rgba(th.acc, 1) : '#fff'; ctx.beginPath(); ctx.arc(px, py, 1.7, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }

  function draw(ts) {
    if (!th || !W || !H) return;
    var t = ts / 1000, a = th.acc, textH = 30;
    var rad = Math.max(18, Math.min((W / 2 - 4) / 1.32, (H - textH) / 2 - 6));
    var cx = W / 2, cy = (H - textH) / 2 + 2;
    ctx.clearRect(0, 0, W, H);

    for (var i = 0; i < stars.length; i++) {           // faint stars
      var s = stars[i]; ctx.globalAlpha = (.18 + .3 * (.5 + .5 * Math.sin(t * 1.4 + s[3]))) * (th.light ? .8 : 1);
      ctx.fillStyle = th.light ? rgba(a, 1) : '#fff'; ctx.fillRect(s[0] * W, s[1] * (H - textH * .6), s[2], s[2]);
    }
    ctx.globalAlpha = 1;
    var sat = t * .8;
    ring(cx, cy, rad * 1.3, rad * .36, false, .16, sat);   // back half of orbit

    var g = ctx.createRadialGradient(cx, cy, rad * .88, cx, cy, rad * 1.3);   // atmosphere
    g.addColorStop(0, rgba(a, .34)); g.addColorStop(.4, rgba(a, .1)); g.addColorStop(1, rgba(a, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, rad * 1.3, 0, TAU); ctx.fill();

    ctx.fillStyle = rgba(th.deep, 1); ctx.beginPath(); ctx.arc(cx, cy, rad, 0, TAU); ctx.fill();   // ocean
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, rad, 0, TAU); ctx.clip();
    g = ctx.createRadialGradient(cx + LX * rad * .8, cy + LY * rad * .8, 0, cx + LX * rad * .8, cy + LY * rad * .8, rad * 1.5);
    g.addColorStop(0, rgba(a, .34)); g.addColorStop(1, rgba(a, 0));
    ctx.fillStyle = g; ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);

    ctx.strokeStyle = rgba(a, .11); ctx.lineWidth = .7;     // graticule
    var la, lo, p, p2, started;
    for (la = -60; la <= 60; la += 30) { started = false; ctx.beginPath();
      for (lo = -180; lo <= 180; lo += 10) { var cl = Math.cos(la * Math.PI / 180), lr = lo * Math.PI / 180;
        p = view(cl * Math.sin(lr), -Math.sin(la * Math.PI / 180), cl * Math.cos(lr));
        if (p[2] > 0) { if (started) ctx.lineTo(cx + p[0] * rad, cy + p[1] * rad); else { ctx.moveTo(cx + p[0] * rad, cy + p[1] * rad); started = true; } } else started = false; }
      ctx.stroke(); }
    for (lo = -180; lo < 180; lo += 30) { started = false; ctx.beginPath();
      for (la = -80; la <= 80; la += 10) { var c2 = Math.cos(la * Math.PI / 180), l2 = lo * Math.PI / 180;
        p = view(c2 * Math.sin(l2), -Math.sin(la * Math.PI / 180), c2 * Math.cos(l2));
        if (p[2] > 0) { if (started) ctx.lineTo(cx + p[0] * rad, cy + p[1] * rad); else { ctx.moveTo(cx + p[0] * rad, cy + p[1] * rad); started = true; } } else started = false; }
      ctx.stroke(); }

    for (var b = 0; b < NB; b++) bn[b] = 0;                  // land dots, lit from the top-left
    var base = Math.max(.6, rad * .0185);
    for (i = 0; i < DX.length; i++) {
      p = view(DX[i], DY[i], DZ[i]); if (p[2] <= 0.02) continue;
      var lf = p[0] * LX + p[1] * LY + p[2] * LZ; lf = lf < 0 ? 0 : lf;
      var k = Math.min(NB - 1, Math.floor((.12 + .88 * Math.pow(lf, .85)) * NB)), n = bn[k]++;
      bx[k][n] = cx + p[0] * rad; by[k][n] = cy + p[1] * rad; br[k][n] = base * (.45 + .55 * p[2]);
    }
    for (b = 0; b < NB; b++) {
      ctx.fillStyle = rgba(a, .22 + .78 * (b + .5) / NB); ctx.beginPath();
      for (i = 0; i < bn[b]; i++) { ctx.moveTo(bx[b][i] + br[b][i], by[b][i]); ctx.arc(bx[b][i], by[b][i], br[b][i], 0, TAU); }
      ctx.fill();
    }

    g = ctx.createRadialGradient(cx + LX * rad * .35, cy + LY * rad * .35, rad * .5, cx, cy, rad * 1.02);   // night side
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.55)');
    ctx.fillStyle = g; ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);

    var sw = (t * 1.5) % TAU;                                 // radar sweep
    if (ctx.createConicGradient) {
      g = ctx.createConicGradient(sw, cx, cy); g.addColorStop(0, rgba(a, 0)); g.addColorStop(.8, rgba(a, 0)); g.addColorStop(1, rgba(a, .3));
      ctx.fillStyle = g; ctx.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);
    }
    ctx.strokeStyle = rgba(a, .5); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(sw) * rad, cy + Math.sin(sw) * rad); ctx.stroke();

    if (mk) {                                                 // your location
      p = view(mk.x, mk.y, mk.z); var mx = cx + p[0] * rad, my = cy + p[1] * rad, pin = th.pin;
      if (p[2] > .02) {
        for (var r = 0; r < 2; r++) { var ph = (t * .85 + r * .5) % 1; ctx.strokeStyle = rgba(pin, (1 - ph) * .85); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(mx, my, 3 + ph * 15, 0, TAU); ctx.stroke(); }
        ctx.fillStyle = rgba(pin, 1); ctx.beginPath(); ctx.arc(mx, my, 3.4, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2; ctx.stroke();
      } else {
        var ang = Math.atan2(p[1], p[0]); ctx.fillStyle = rgba(pin, .5 + .4 * Math.sin(t * 4)); ctx.beginPath();
        ctx.arc(cx + Math.cos(ang) * (rad - 3), cy + Math.sin(ang) * (rad - 3), 2.6, 0, TAU); ctx.fill();
      }
    }
    ctx.restore();

    g = ctx.createRadialGradient(cx, cy, rad * .8, cx, cy, rad);   // rim light + edge
    g.addColorStop(0, rgba(a, 0)); g.addColorStop(1, rgba(a, .3));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, rad, 0, TAU); ctx.fill();
    ctx.strokeStyle = rgba(a, .85); ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(cx, cy, rad, 0, TAU); ctx.stroke();
    ring(cx, cy, rad * 1.3, rad * .36, true, .34, sat);        // front half of orbit
  }

  /* ---------- animation ---------- */
  function step(ts) {
    var dt = Math.min(.05, (ts - lastTs) / 1000 || 0); lastTs = ts;
    if (!drag) {
      if (focus === 1) { var d = wrap(target - yaw); yaw += d * Math.min(1, dt * 2.6); if (Math.abs(d) < .015) { focus = 2; hold = 2.4; } }
      else if (focus === 2) { hold -= dt; if (hold <= 0) focus = 0; }
      else { yaw += vel * dt + spin * (hover ? .3 : 1) * dt; vel *= Math.pow(.03, dt); }
    }
    draw(ts); raf = running ? requestAnimationFrame(step) : 0;
  }
  function redraw() { if (calm || !running) requestAnimationFrame(draw); }
  function start() { if (calm) { requestAnimationFrame(draw); return; } if (!raf && running) { lastTs = performance.now(); raf = requestAnimationFrame(step); } }

  box.addEventListener('pointerdown', function (e) { drag = true; lastX = e.clientX; vel = 0; focus = 0; try { box.setPointerCapture(e.pointerId); } catch (x) {} box.classList.add('grab'); });
  box.addEventListener('pointermove', function (e) { if (!drag) return; var dx = e.clientX - lastX; lastX = e.clientX; yaw += dx * .012; vel = dx * .7; if (calm) requestAnimationFrame(draw); });
  function up() { drag = false; box.classList.remove('grab'); }
  box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
  box.addEventListener('pointerenter', function () { hover = true; }); box.addEventListener('pointerleave', function () { hover = false; });

  if ('ResizeObserver' in window) new ResizeObserver(function () { fit(); redraw(); }).observe(box); else window.addEventListener('resize', function () { fit(); redraw(); });
  if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { running = en[0].isIntersecting; if (running) { raf = 0; start(); } }).observe(box);
  document.addEventListener('admthemechange', readTheme);

  /* ---------- where are you? ---------- */
  function show(d) {
    elI.textContent = d.ip || 'Unknown'; elC.textContent = (d.country || 'Unknown') + (d.code ? ' (' + d.code + ')' : '');
    box.title = [elC.textContent, elI.textContent].join('\n');
    var lat = +d.lat, lon = +d.lon;
    if (d.code && isFinite(lat) && isFinite(lon)) {
      var la = lat * Math.PI / 180, lr = lon * Math.PI / 180;
      mk = { x: Math.cos(la) * Math.sin(lr), y: -Math.sin(la), z: Math.cos(la) * Math.cos(lr) };
      target = -lr; if (calm) yaw = target; else focus = 1;
      redraw();
    }
  }
  function geo() {
    try { var c = JSON.parse(sessionStorage.getItem('adm_geo') || 'null'); if (c && c.d && c.d.code && Date.now() - c.t < 18e5) { show(c.d); return; } } catch (e) {}
    function keep(d) { try { if (d.code) sessionStorage.setItem('adm_geo', JSON.stringify({ t: Date.now(), d: d })); } catch (e) {} show(d); }
    fetch('?geo=1&_=' + Date.now(), { credentials: 'same-origin' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
      if (d && d.code) return keep(d);
      return fetch('https://ipapi.co/json/').then(function (r) { return r.json(); }).then(function (j) {
        if (j && j.ip) keep({ ip: j.ip, country: j.country_name, code: j.country_code, lat: j.latitude, lon: j.longitude }); else if (d) show(d);
      });
    }).catch(function () { elC.textContent = 'Offline'; });
  }

  fit(); readTheme(); start(); geo();
})();
