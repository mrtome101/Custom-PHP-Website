<?php
// =====================================================
//  ADMIN LOGIN  -  edit the two lines below, then save.
//  Login page:  yoursite.com/admin/
// =====================================================
return [
    'user' => 'admin',
    'pass' => 'admin',
];
