<?php
// Keep the address clean: /admin/index.php -> /admin/
$__path = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
$ADMIN_URL = preg_replace('~index\.php$~', '', $__path); if (substr($ADMIN_URL, -1) !== '/') $ADMIN_URL .= '/';
if (in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET','HEAD'], true) && substr($__path, -10) === '/index.php') {
    $q = (string)($_SERVER['QUERY_STRING'] ?? ''); header('Location: '.$ADMIN_URL.($q !== '' ? '?'.$q : ''), true, 301); exit;
}

require dirname(__DIR__).'/inc/config.php';
session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>!empty($_SERVER['HTTPS'])]);
ini_set('session.gc_maxlifetime','2592000');
session_start();
$auth = auth_load(); $msg = ''; $err = '';
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
function csrf_ok(): bool { return hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? ''); }
function head(string $t): void { echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($t).'</title><link rel="stylesheet" href="'.e(BASE_URL).'core/assets/vendor/fortawesome/fontawesome-free/css/all.min.css"><style>'.file_get_contents(__DIR__.'/style.css').'</style></head><body><script>try{var v=localStorage.getItem("adm");if(v==="light")document.body.classList.add("light");else if(v&&v!=="dark")document.body.classList.add("th-"+v)}catch(e){}</script>'; }

if (!$auth) { head('Error'); echo '<div class="login"><h1>Login file missing</h1><p>Create <code>admin/password.php</code> with a user and pass.</p></div></body></html>'; exit; }
if (isset($_GET['logout'])) { setcookie('tome_pv','',time()-3600,'/'); setcookie('tome_pvset','',time()-3600,'/'); session_destroy(); header('Location: '.$ADMIN_URL); exit; }

if (isset($_GET['geo']) && !empty($_SESSION['in'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $ip = (string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
    if (strpos($ip, ',') !== false) $ip = trim(explode(',', $ip)[0]);
    $ipClean = preg_replace('/[^0-9a-fA-F:.]/', '', $ip);
    $country = 'Local / Private';
    $code = '';
    $lat = 20.5937;
    $lon = 78.9629;
    $isPublic = filter_var($ipClean, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    if ($isPublic) {
        $ctx = stream_context_create(['http' => ['timeout' => 4, 'user_agent' => 'TomeAdminRadar/1.0']]);
        $raw = @file_get_contents('http://ip-api.com/json/' . rawurlencode($ipClean) . '?fields=status,country,countryCode,lat,lon', false, $ctx);
        if (is_string($raw) && $raw !== '') {
            $j = json_decode($raw, true);
            if (is_array($j) && ($j['status'] ?? '') === 'success') {
                $country = (string)($j['country'] ?? $country);
                $code = (string)($j['countryCode'] ?? '');
                if (isset($j['lat'], $j['lon']) && is_numeric($j['lat']) && is_numeric($j['lon'])) {
                    $lat = (float)$j['lat'];
                    $lon = (float)$j['lon'];
                }
            }
        }
    }
    echo json_encode([
        'ip' => $ipClean ?: 'Unknown',
        'country' => $country,
        'code' => $code,
        'lat' => $lat,
        'lon' => $lon
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (empty($_SESSION['in'])) {                   // login
    if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_ok()) {
        usleep(400000);
        if (hash_equals($auth['user'], (string)($_POST['user'] ?? '')) && hash_equals($auth['pass'], (string)($_POST['pass'] ?? ''))) {
            session_regenerate_id(true); $_SESSION['in'] = true; $_SESSION['csrf'] = bin2hex(random_bytes(16));
            if (!empty($_POST['remember']))
                setcookie(session_name(), session_id(), ['expires'=>time()+2592000,'path'=>'/','httponly'=>true,'samesite'=>'Strict','secure'=>!empty($_SERVER['HTTPS'])]);
            header('Location: '.$ADMIN_URL); exit;
        } $err = 'Wrong username or password.';
    }
    head('Sign in'); ?>
<canvas id="adm-bg-particles" aria-hidden="true"></canvas>
<div class="auth">
  <div class="auth-l"><div class="auth-box">
    <div class="auth-logo"><i class="fa-solid fa-sliders"></i><span>Site Customizer</span></div>
    <h1>Sign in</h1><p class="sub">Customize your website in one click.</p>
    <form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
      <?php if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
      <label class="lab">Username</label>
      <div class="inp"><i class="fa-solid fa-at"></i><input type="text" name="user" placeholder="Your username" autocomplete="username" required autofocus></div>
      <label class="lab">Password</label>
      <div class="inp"><i class="fa-solid fa-key"></i><input type="password" name="pass" id="pw" placeholder="Your password" autocomplete="current-password" required><button type="button" class="eye" id="eye" aria-label="Show password"><i class="fa-regular fa-eye"></i></button></div>
      <label class="keep"><input type="checkbox" name="remember" value="1"><span class="cb"></span> Keep me signed in</label>
      <button class="btn">Sign in</button>
    </form>
    <div class="auth-alt"><a href="#" id="fg">Forgot your password?</a>
      <div class="hint" id="fgh" hidden>Open <code>admin/password.php</code> in your File Manager. Your username and password are written there.</div></div>
    <div class="auth-foot">Site Customizer</div>
  </div></div>
  <div class="auth-r" style="background-image:linear-gradient(90deg,var(--bg) 0,rgba(6,9,13,.35) 40%,rgba(6,9,13,.8) 100%),url('<?= asset(s('hero_bg')) ?>')">
    <button type="button" class="mode round" id="mode" title="Admin theme" data-theme-open aria-label="Admin theme"><i class="fa-solid fa-palette"></i></button>
    <div class="auth-cap"><h2>Site Customizer</h2><p>Change your logo, colors, texts and more. No code needed.</p></div>
  </div>
</div>
<script>
document.getElementById('eye').onclick=()=>{const p=document.getElementById('pw');p.type=p.type==='password'?'text':'password';};
document.getElementById('fg').onclick=e=>{e.preventDefault();document.getElementById('fgh').hidden=false;};
</script>
<script src="<?= e($ADMIN_URL) ?>theme.js?v=<?= (int)@filemtime(__DIR__.'/theme.js') ?>"></script>
</body></html><?php exit;
}
// logged in: allow live-preview cookie
setcookie('tome_pv', hash('sha256', $auth['hash']), ['path'=>'/','httponly'=>true,'samesite'=>'Strict']);

const DEFAULTS = ['logo'=>'uploads/1024x_HD.png','favicon'=>'uploads/favicons/favicon-32x32.png','hero_bg'=>'uploads/hero-bg.jpg','og_image'=>'uploads/1024x_HD.png','news_banner'=>'uploads/BMxBANNER.png','vote_key'=>'uploads/vote_key.webp'];
function upload_image(string $field, string $old): string {
    if (empty($_FILES[$field]['tmp_name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return $old;
    $f = $_FILES[$field];
    if ($f['size'] > 5*1024*1024) throw new Exception('Image is larger than 5 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $map = ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/gif'=>'gif','image/x-icon'=>'ico','image/vnd.microsoft.icon'=>'ico'];
    if (!isset($map[$mime])) throw new Exception('Only PNG, JPG, WEBP, GIF or ICO images are allowed.');
    if ($map[$mime] !== 'ico' && !@getimagesize($f['tmp_name'])) throw new Exception('That file is not a valid image.');
    $dir = ROOT.'/uploads/custom'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $name = $field.'-'.bin2hex(random_bytes(5)).'.'.$map[$mime];
    if (!@move_uploaded_file($f['tmp_name'], "$dir/$name")) throw new Exception('Could not save the image. Make the "uploads" folder writable.');
    return 'uploads/custom/'.$name;
}
const NUMS = ['particles_count'=>[80,0,300],'particles_speed'=>[2,0.2,12],'particles_size'=>[3,1,12],'particles_distance'=>[150,20,400],'particles_opacity'=>[0.5,0,1],'particles_line_opacity'=>[0.4,0,1],'particles_line_width'=>[1,1,5]];
$fields = fields(); $d = settings_raw();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!csrf_ok()) $err = 'Your session expired. Reload the page and try again.';
    elseif (isset($_POST['do_reset'])) {            // restore the website exactly as it was originally
        @unlink(SETTINGS_FILE);
        foreach (glob(ROOT.'/uploads/custom/*') ?: [] as $fx) if (is_file($fx)) @unlink($fx);
        setcookie('tome_pvset','',time()-3600,'/');
        $d = settings_raw(); $msg = 'Done! Your website is back to the original.';
    }
    else try {
        foreach (['site_name','server_ip','store_url','discord_code','site_description'] as $k) $d[$k] = trim(strip_tags($_POST[$k] ?? ''));
        $d['logo_height'] = max(60, min(400, (int)($_POST['logo_height'] ?? 250)));
        $d['font'] = isset(font_choices()[$_POST['font'] ?? '']) ? $_POST['font'] : 'default';
        foreach (['primary_color','bg_color','particles_color','particles_line_color'] as $k) if (preg_match('/^#[0-9a-fA-F]{6}$/', $_POST[$k] ?? '')) $d[$k] = strtoupper($_POST[$k]);
        foreach (['show_powered_by','particles_enabled','particles_follow','particles_lines','particles_hover','particles_click'] as $k) $d[$k] = !empty($_POST[$k]);
        foreach (NUMS as $k => [$def,$lo,$hi]) $d[$k] = max($lo, min($hi, is_numeric($_POST[$k] ?? null) ? 0 + $_POST[$k] : $def));
        foreach (['show_news','show_nav_rules','show_nav_vote','show_nav_store','show_nav_staff','show_footer_play','show_footer_links','show_footer_store','themed_scrollbar','announce_on','maintenance','fx_web_btn_shine','fx_web_btn_pulse','fx_web_card_lift','fx_web_logo_float','fx_web_nav_glow','fx_web_click_spark'] as $k) $d[$k] = !empty($_POST[$k]);
        foreach (['announce_text','announce_link','news_link','maint_title','maint_text'] as $k) $d[$k] = trim(strip_tags((string)($_POST[$k] ?? '')));
        foreach (['announce_bg','announce_fg'] as $k) if (preg_match('/^#[0-9a-fA-F]{6}$/', $_POST[$k] ?? '')) $d[$k] = strtoupper($_POST[$k]);
        $d['particles_shape'] = in_array($_POST['particles_shape'] ?? '', ['circle','triangle','edge','star'], true) ? $_POST['particles_shape'] : 'circle';
        $d['home_skin_name'] = substr(preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['home_skin_name'] ?? '')), 0, 16) ?: 'Steve';
        foreach (DEFAULTS as $k => $def) $d[$k] = !empty($_POST['reset_'.$k]) ? $def : upload_image($k, $d[$k] ?? $def);
        if (!empty($_POST['reset_texts'])) unset($d['texts']);
        elseif (isset($_POST['tx']) && is_array($_POST['tx'])) {
            $d['texts'] = [];
            foreach ($fields as $k => $f) if (isset($_POST['tx'][$k])) {
                $v = trim(str_replace("\r\n", "\n", (string)$_POST['tx'][$k]));
                if ($k === 'rules_sections') {
                    $j = json_decode($v, true); $out = [];
                    if (is_array($j)) foreach (array_slice($j, 0, 30) as $sx) {
                        if (!is_array($sx)) continue;
                        $cl = fn($x, $n) => substr(trim(strip_tags((string)$x)), 0, $n);
                        $rl = []; foreach (array_slice((array)($sx['rules'] ?? []), 0, 300) as $r) { $r = $cl($r, 600); if ($r !== '') $rl[] = $r; }
                        $out[] = ['nav'=>$cl($sx['nav'] ?? '', 60), 'title'=>$cl($sx['title'] ?? '', 120), 'icon'=>isset(rules_icons()[$sx['icon'] ?? '']) ? $sx['icon'] : 'scale', 'intro'=>$cl($sx['intro'] ?? '', 600), 'rules'=>$rl, 'note'=>$cl($sx['note'] ?? '', 600)];
                    }
                    if (is_array($j)) $d['texts'][$k] = json_encode($out, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                    continue;
                }
                $v = strip_tags($v);
                if ($v !== trim($f['d'])) $d['texts'][$k] = $v;
            }
        }
        // ---- skins (home page + staff players)
        $staffText = $d['texts']['staff_list'] ?? $fields['staff_list']['d'];
        $keep = ['__home'];
        $staffSlots = [];
        $curRankName = '';
        $rankIdxMap = [];
        foreach (preg_split('/\R/', $staffText) as $ln) {
            $ln = trim($ln);
            if ($ln === '') continue;
            if (preg_match('/^#+\s*(.+?)\s*(?:\|\s*(#[0-9a-fA-F]{3,8}))?\s*$/', $ln, $m)) {
                $curRankName = $m[1];
                $rankIdxMap[$curRankName] = 0;
            } elseif ($curRankName !== '') {
                $pIdx = $rankIdxMap[$curRankName]++;
                $slotKey = skin_key($curRankName . '_' . $ln . '_' . $pIdx);
                $baseKey = skin_key($ln);
                $keep[] = $slotKey;
                $keep[] = $baseKey;
                $staffSlots[] = ['slot' => $slotKey, 'base' => $baseKey, 'rank_base' => skin_key($curRankName . '_' . $ln)];
            }
        }
        $keep = array_values(array_unique(array_filter($keep, fn($x) => $x !== '')));
        $skins = (isset($d['skins']) && is_array($d['skins'])) ? $d['skins'] : [];
        foreach ((array)($_POST['skin_reset'] ?? []) as $k => $_) { $k = skin_key((string)$k); if (isset($skins[$k])) { @unlink(ROOT.'/'.$skins[$k]['path']); unset($skins[$k]); } }
        $todo = [];                                   // key => [temp file, size, is a real upload?]
        if (!empty($_FILES['skinf']['name']) && is_array($_FILES['skinf']['name'])) foreach ($_FILES['skinf']['name'] as $k => $_) {
            $key = skin_key((string)$k); if ($key === '' || ($_FILES['skinf']['error'][$k] ?? 4) !== UPLOAD_ERR_OK) continue;
            $todo[$key] = [$_FILES['skinf']['tmp_name'][$k], (int)$_FILES['skinf']['size'][$k], true];
        }
        foreach ((array)($_POST['skinurl'] ?? []) as $k => $url) {      // skin from a link
            $key = skin_key((string)$k); $url = trim((string)$url); if ($key === '' || $url === '' || isset($todo[$key])) continue;
            $tmp = fetch_image_url($url); $todo[$key] = [$tmp, (int)filesize($tmp), false];
        }
        foreach ($todo as $key => [$tmp, $size, $isUp]) {
            if ($size > 2*1024*1024) throw new Exception('Skin image is larger than 2 MB.');
            $info = @getimagesize($tmp); $okT = [IMAGETYPE_PNG=>'png', IMAGETYPE_JPEG=>'jpg', IMAGETYPE_WEBP=>'webp', IMAGETYPE_GIF=>'gif'];
            if (!$info || !isset($okT[$info[2]])) throw new Exception('Skins must be PNG, JPG, WEBP or GIF images.');
            [$w, $h] = $info; $kind = ($w % 64 === 0 && ($h === $w || $h * 2 === $w)) ? 'skin' : 'img';
            $dir = ROOT.'/uploads/custom'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
            $name = 'skin-'.bin2hex(random_bytes(5)).'.'.$okT[$info[2]];
            $saved = $isUp ? @move_uploaded_file($tmp, "$dir/$name") : (@rename($tmp, "$dir/$name") || @copy($tmp, "$dir/$name"));
            if (!$saved) throw new Exception('Could not save the skin. Make the "uploads" folder writable.');
            if (isset($skins[$key])) @unlink(ROOT.'/'.$skins[$key]['path']);
            $skins[$key] = ['path'=>'uploads/custom/'.$name, 'kind'=>$kind, 'w'=>$w, 'h'=>$h];
        }
        foreach ($skins as $k => $e) if (!in_array($k, $keep, true)) { @unlink(ROOT.'/'.($e['path'] ?? '')); unset($skins[$k]); }
        $d['skins'] = $skins;
        // ---- staff profile details & custom top banners
        $oldProfiles = (isset($d['staff_profiles']) && is_array($d['staff_profiles'])) ? $d['staff_profiles'] : [];
        $newProfiles = [];
        $postedProfiles = (isset($_POST['sp']) && is_array($_POST['sp'])) ? $_POST['sp'] : [];
        foreach ($staffSlots as $sl) {
            $skKey = $sl['slot'];
            $in = is_array($postedProfiles[$skKey] ?? null) ? $postedProfiles[$skKey]
                : (is_array($postedProfiles[$sl['rank_base']] ?? null) ? $postedProfiles[$sl['rank_base']] : []);
            $oldPf = is_array($oldProfiles[$skKey] ?? null) ? $oldProfiles[$skKey]
                : (is_array($oldProfiles[$sl['rank_base']] ?? null) ? $oldProfiles[$sl['rank_base']]
                : (is_array($oldProfiles[$sl['base']] ?? null) ? $oldProfiles[$sl['base']] : []));
            $oldB = (string)($oldPf['banner'] ?? '');
            $bannerPath = $oldB;
            if (!empty($_POST['sp_banner_reset'][$skKey])) {
                if ($oldB !== '' && is_file(ROOT.'/'.$oldB)) @unlink(ROOT.'/'.$oldB);
                $bannerPath = '';
            } elseif (!empty($_FILES['sp_banner']['name'][$skKey]) && ($_FILES['sp_banner']['error'][$skKey] ?? 4) === UPLOAD_ERR_OK) {
                $bTmp = $_FILES['sp_banner']['tmp_name'][$skKey];
                $bSz  = (int)$_FILES['sp_banner']['size'][$skKey];
                if ($bSz > 5*1024*1024) throw new Exception('Staff banner image is larger than 5 MB.');
                $bInf = @getimagesize($bTmp);
                $bMap = [IMAGETYPE_PNG=>'png', IMAGETYPE_JPEG=>'jpg', IMAGETYPE_WEBP=>'webp', IMAGETYPE_GIF=>'gif'];
                if (!$bInf || !isset($bMap[$bInf[2]])) throw new Exception('Staff banner must be PNG, JPG, WEBP or GIF.');
                $dir = ROOT.'/uploads/custom'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
                $bName = 'staff-banner-'.bin2hex(random_bytes(5)).'.'.$bMap[$bInf[2]];
                if (!@move_uploaded_file($bTmp, "$dir/$bName")) throw new Exception('Could not save staff banner.');
                if ($oldB !== '' && is_file(ROOT.'/'.$oldB)) @unlink(ROOT.'/'.$oldB);
                $bannerPath = 'uploads/custom/'.$bName;
            }
            $newProfiles[$skKey] = [
                'banner'     => $bannerPath,
                'discord'    => substr(trim(strip_tags((string)($in['discord'] ?? ''))), 0, 64),
                'registered' => substr(trim(strip_tags((string)($in['registered'] ?? '1 months ago'))), 0, 64),
                'last_seen'  => substr(trim(strip_tags((string)($in['last_seen'] ?? 'Online'))), 0, 64),
                'focus'      => substr(trim(strip_tags((string)($in['focus'] ?? ''))), 0, 64),
                'bio'        => substr(trim(strip_tags((string)($in['bio'] ?? ''))), 0, 1000),
                'show_msg'   => !empty($in['show_msg']),
            ];
        }
        $d['staff_profiles'] = $newProfiles;
        if (!settings_save($d)) throw new Exception('Could not write data/settings.json. Make the "data" folder writable.');
        setcookie('tome_pvset','',time()-3600,'/');
        $msg = 'Saved! Your site is updated.';
    } catch (Exception $ex) { $err = $ex->getMessage(); }
}
$g = fn($k,$def) => $d[$k] ?? $def;
$presets = [['Purple','#911AEE','#101010'],['Midnight','#4F8CFF','#0A0F1C'],['Ocean','#00B4D8','#07141C'],['Aqua','#19D3DA','#071113'],['Emerald','#10B981','#07120E'],['Forest','#4ADE80','#0B130C'],['Lime','#A3E635','#12150B'],['Gold','#F5B301','#15120A'],['Amber','#FF9F1C','#171009'],['Sunset','#FF6B6B','#1A1015'],['Crimson','#E11D48','#16080C'],['Rose','#FB7185','#180B0E'],['Candy','#EC4899','#160B12'],['Magenta','#D946EF','#150A17'],['Violet','#8B5CF6','#0F0B1A'],['Slate','#94A3B8','#0F141B'],['Mono','#E5E5E5','#0B0B0B'],['Pure black','#19D3DA','#000000']];
function img_field(string $k, string $label, string $hint, array $d): void { global $g; ?>
<div class="card"><h2><?= e($label) ?></h2><p class="sub"><?= e($hint) ?></p>
  <div class="img"><img class="thumb" id="t_<?= $k ?>" src="<?= asset($d[$k] ?? DEFAULTS[$k]) ?>" alt="">
    <label class="drop">Click to choose an image<input type="file" name="<?= $k ?>" accept="image/*" data-t="t_<?= $k ?>"></label></div>
  <label class="reset"><input type="checkbox" name="reset_<?= $k ?>" value="1"> Restore original</label></div>
<?php }
function num_field(string $k, string $label, array $d, float $step): void { [$def,$lo,$hi] = NUMS[$k]; $v = $d[$k] ?? $def; ?>
  <label class="f"><span class="rl"><?= e($label) ?> <b id="v_<?= $k ?>"><?= e($v) ?></b></span><input type="range" class="rng" name="<?= $k ?>" data-pv min="<?= $lo ?>" max="<?= $hi ?>" step="<?= $step ?>" value="<?= e($v) ?>" oninput="document.getElementById('v_<?= $k ?>').textContent=this.value"></label>
<?php }
function fetch_image_url(string $url): string {          // download a skin link to a temp file (direct image links only)
    $u = parse_url(trim($url));
    if (!$u || !in_array(strtolower($u['scheme'] ?? ''), ['http','https'], true) || empty($u['host'])) throw new Exception('The skin link must start with http:// or https://');
    $ips = @gethostbynamel($u['host']) ?: [];
    if (!$ips) throw new Exception('Could not reach the skin link. Check that it is correct.');
    foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) throw new Exception('That skin link is not allowed.');
    $ctx = stream_context_create(['http'=>['timeout'=>10,'follow_location'=>0,'ignore_errors'=>false,'user_agent'=>'Mozilla/5.0 (SkinFetch)']]);
    $data = @file_get_contents(trim($url), false, $ctx, 0, 2*1024*1024+1);
    if ($data === false || $data === '') throw new Exception('Could not download the skin from that link. Use a direct link to the image (it should end in .png).');
    if (strlen($data) > 2*1024*1024) throw new Exception('Skin image is larger than 2 MB.');
    $tmp = tempnam(sys_get_temp_dir(), 'skn'); file_put_contents($tmp, $data); return $tmp;
}
function tog(string $k, string $label, string $sub, bool $on, bool $pv = true): void { ?>
  <label class="switch row"><span><b><?= e($label) ?></b><small><?= e($sub) ?></small></span><input type="checkbox" name="<?= $k ?>" value="1" <?= $pv ? 'data-pv' : '' ?> <?= $on ? 'checked' : '' ?>><span class="tg"></span></label>
<?php }
head('Site Customizer'); ?>
<canvas id="adm-bg-particles" aria-hidden="true"></canvas>
<div class="app">
<div class="mob-bar">
  <button type="button" class="mob-menu-btn" id="mob-open" aria-label="Open navigation menu" aria-expanded="false">
    <i class="fa-solid fa-bars"></i>
  </button>
  <div class="mob-brand"><i class="fa-solid fa-sliders"></i><b>Site Customizer</b></div>
  <button type="button" class="mob-ext" data-theme-open title="Theme" aria-label="Theme"><i class="fa-solid fa-palette"></i></button>
  <a href="/" target="_blank" class="mob-ext" title="View Site" aria-label="View Site"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
</div>
<div class="side-backdrop" id="side-backdrop" hidden></div>
<nav class="side" id="side-nav" aria-label="Admin Navigation">
  <div class="mob-side-head">
    <div class="side-brand" style="margin:0;padding:0;border:0">
      <div class="brand-ico"><i class="fa-solid fa-sliders"></i></div>
      <b>Site Customizer</b>
    </div>
    <button type="button" class="mob-close-btn" id="mob-close" aria-label="Close navigation menu"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <div class="side-sep"></div>
  <div class="side-nav" id="tabs">
    <button type="button" data-tab="theme" class="on"><i class="fa-solid fa-palette"></i><span>Theme</span></button>
    <button type="button" data-tab="images"><i class="fa-solid fa-folder-open"></i><span>Images</span></button>
    <button type="button" data-tab="particles"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Particles</span></button>
    <button type="button" data-tab="info"><i class="fa-solid fa-server"></i><span>Info</span></button>
    <button type="button" data-tab="rules"><i class="fa-solid fa-scale-balanced"></i><span>Rules</span></button>
    <button type="button" data-tab="people"><i class="fa-solid fa-users"></i><span>Staff &amp; Vote</span></button>
    <button type="button" data-tab="text"><i class="fa-solid fa-file-lines"></i><span>Page Text</span></button>
    <button type="button" data-tab="extras"><i class="fa-solid fa-toggle-on"></i><span>Extras</span></button>
    <button type="button" data-tab="admintheme"><i class="fa-solid fa-droplet"></i><span>Admin / Theme</span></button>
    <button type="button" data-tab="account"><i class="fa-solid fa-wrench"></i><span>Admin &amp; Reset</span></button>
  </div>
  <div class="earth-radar-box" id="earth-radar-box" title="Live Admin IP & Country Radar">
    <canvas id="er-globe-cv" width="200" height="200"></canvas>
    <div class="er-overlay">
      <div class="er-country" id="er-country">Scanning IP...</div>
      <div class="er-ip" id="er-ip">IP: --</div>
    </div>
  </div>

  <div class="side-sep"></div>
  <div class="side-foot">
    <button type="button" data-theme-open title="Change admin theme"><i class="fa-solid fa-palette"></i><span>Theme</span></button>
    <a href="/" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>View Site</span></a>
    <a href="?logout=1" class="logout-lnk"><i class="fa-solid fa-right-from-bracket"></i><span>Log Out</span></a>
  </div>
</nav>
<main class="wrap"><form method="post" enctype="multipart/form-data" id="f">
<input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
<?php if($msg) echo '<div class="alert ok">✔ '.e($msg).'</div>'; if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>


<section data-p="theme">
<div class="card"><h2>Theme</h2><p class="sub">Pick a ready-made theme, or choose any color you like. Panels and cards follow the background color. The preview updates instantly.</p>
  <div class="presets"><?php foreach($presets as $p): ?><button type="button" class="chip" title="<?= e($p[0]) ?>" data-a="<?= $p[1] ?>" data-b="<?= $p[2] ?>"><i style="background:<?= $p[2] ?>"></i><b style="background:<?= $p[1] ?>"></b></button><?php endforeach; ?></div>
  <div class="pick">
    <label>Main color<input type="color" id="primary_color" name="primary_color" data-pv value="<?= e($g('primary_color','#A3E635')) ?>"><div class="hex" id="h1"></div></label>
    <label>Background color<input type="color" id="bg_color" name="bg_color" data-pv value="<?= e($g('bg_color','#12150B')) ?>"><div class="hex" id="h2"></div></label>
  </div></div>
<div class="card"><?php tog('show_powered_by','Show "Created by TOME"','A small credit and GitHub icon in the footer. Turn it off any time.', !empty($d['show_powered_by']), false); ?></div>
</section>

<section data-p="images" hidden>
<div class="grid2"><?php img_field('logo','Logo','Transparent PNG looks best.',$d); img_field('favicon','Tab icon','The small icon in the browser tab.',$d); ?></div>
<div class="grid2"><?php img_field('hero_bg','Header background','The big image at the top.',$d); img_field('og_image','Share image','Shown when the link is shared on Discord / WhatsApp.',$d); ?></div>
<div class="grid2"><?php img_field('news_banner','Home page banner','The wide picture inside the news post on the home page.',$d); img_field('vote_key','Vote page key icon','The small key picture on the Vote page.',$d); ?></div>
</section>

<section data-p="particles" hidden>
<div class="card"><h2>Moving lines &amp; dots</h2><p class="sub">The animated particles in the background. Changes show in the preview right away.</p>
  <?php tog('particles_enabled','Show particles','Turn the whole animation on or off.', $g('particles_enabled',true)); ?>
  <?php tog('particles_lines','Draw connecting lines','Lines between nearby dots.', $g('particles_lines',true)); ?>
  <?php tog('particles_follow','Use my main theme color','Dots and lines always match the Theme tab.', $g('particles_follow',true)); ?>
  <div class="pick" style="margin-top:12px">
    <label>Dot color<input type="color" id="particles_color" name="particles_color" data-pv value="<?= e($g('particles_color',$g('primary_color','#A3E635'))) ?>"></label>
    <label>Line color<input type="color" id="particles_line_color" name="particles_line_color" data-pv value="<?= e($g('particles_line_color',$g('primary_color','#A3E635'))) ?>"></label>
  </div></div>
<div class="card"><h2>Look &amp; feel</h2>
  <?php num_field('particles_count','Number of dots',$d,5); num_field('particles_speed','Speed',$d,0.2); num_field('particles_size','Dot size',$d,1); num_field('particles_distance','Line length',$d,10); num_field('particles_opacity','Dot brightness',$d,0.05); num_field('particles_line_opacity','Line brightness',$d,0.05); num_field('particles_line_width','Line thickness',$d,1); ?>
  <label class="f">Dot shape<select class="big" name="particles_shape" data-pv><?php foreach (['circle'=>'Circle','triangle'=>'Triangle','edge'=>'Square','star'=>'Star'] as $sk=>$sl): ?><option value="<?= $sk ?>" <?= $g('particles_shape','circle')===$sk ? 'selected' : '' ?>><?= $sl ?></option><?php endforeach; ?></select></label>
  <?php tog('particles_hover','Dots move away from the mouse','', $g('particles_hover',true)); tog('particles_click','Click adds more dots','', $g('particles_click',true)); ?></div>
</section>

<section data-p="info" hidden>
<div class="card"><h2>Info</h2><p class="sub">Names and links used across the site.</p>
  <div class="grid2"><label class="f">Site name<input type="text" id="site_name" name="site_name" data-pv value="<?= e($g('site_name','')) ?>"></label>
  <label class="f">Server IP<input type="text" name="server_ip" value="<?= e($g('server_ip','')) ?>"></label>
  <label class="f">Store link<input type="text" name="store_url" value="<?= e($g('store_url','')) ?>"></label>
  <label class="f">Discord invite code<input type="text" name="discord_code" value="<?= e($g('discord_code','')) ?>"></label></div>
  <label class="f">Short site description<input type="text" name="site_description" value="<?= e($g('site_description','')) ?>"><small>Shown in Google results and link previews.</small></label></div>
<div class="card"><h2>Look</h2><p class="sub">Logo size and font.</p>
  <?php [$lh] = [(int)$g('logo_height',250)]; ?>
  <label class="f"><span class="rl">Logo size <b id="v_logo_height"><?= $lh ?></b></span><input type="range" class="rng" name="logo_height" data-pv min="60" max="400" step="5" value="<?= $lh ?>" oninput="document.getElementById('v_logo_height').textContent=this.value"></label>
  <label class="f">Font<select class="big" name="font" data-pv><?php foreach (font_choices() as $fk => $fl): ?><option value="<?= e($fk) ?>" <?= $g('font','default')===$fk ? 'selected' : '' ?>><?= e($fl) ?></option><?php endforeach; ?></select></label></div>
</section>

<section data-p="rules" hidden>
<div class="card"><h2>Rules page</h2><p class="sub">The first page of your rules: title, welcome text and the Discord button. Use <code>**bold**</code> for white bold text and <code>[[text]]</code> to color it in your main color. <code>{site_name}</code> is replaced by your site name.</p>
  <label class="f">Side menu title<input type="text" name="tx[rules_side_title]" value="<?= e($d['texts']['rules_side_title'] ?? $fields['rules_side_title']['d']) ?>"></label>
  <label class="f">Side menu name for this first page<input type="text" name="tx[rules_nav_home]" value="<?= e($d['texts']['rules_nav_home'] ?? $fields['rules_nav_home']['d']) ?>"></label>
  <label class="f">Main title<input type="text" name="tx[rules_title]" value="<?= e($d['texts']['rules_title'] ?? $fields['rules_title']['d']) ?>"></label>
  <label class="f">"Last updated" line<input type="text" name="tx[rules_updated]" value="<?= e($d['texts']['rules_updated'] ?? $fields['rules_updated']['d']) ?>"></label>
  <label class="f">Welcome text (leave an empty line between paragraphs)<textarea name="tx[rules_intro]" rows="8"><?= e($d['texts']['rules_intro'] ?? $fields['rules_intro']['d']) ?></textarea></label>
  <label class="f">Signature line<input type="text" name="tx[rules_signature]" value="<?= e($d['texts']['rules_signature'] ?? $fields['rules_signature']['d']) ?>"></label>
  <label class="f">Discord button text<input type="text" name="tx[rules_join_btn]" value="<?= e($d['texts']['rules_join_btn'] ?? $fields['rules_join_btn']['d']) ?>"></label></div>
<div class="card"><h2>Rule sections</h2><p class="sub">Each section is one page in the rules side menu (for example Minecraft, Discord, Staff, Store). Add as many as you like, then add, edit, delete or move the rules inside. Press Enter in a rule to add the next one.</p>
  <div id="rules-ui"></div><button type="button" class="btn ghost sm" id="add-sec"><i class="fa-solid fa-plus"></i> Add section</button>
  <input type="hidden" name="tx[rules_sections]" id="rules_sections"></div>
</section>

<section data-p="people" hidden>
<?php
$staffText = $d['texts']['staff_list'] ?? $fields['staff_list']['d'];
$voteText  = $d['texts']['vote_links'] ?? $fields['vote_links']['d'];
$groups = [];
foreach (preg_split('/\R/', $staffText) as $ln) { $ln = trim($ln); if ($ln === '') continue;
    if (preg_match('/^#+\s*(.+?)\s*(?:\|\s*(#[0-9a-fA-F]{3,8}))?\s*$/', $ln, $m)) $groups[] = ['name'=>$m[1], 'color'=>$m[2] ?? '#FFFFFF', 'players'=>[]];
    elseif ($groups) $groups[count($groups)-1]['players'][] = $ln; }
$votes = []; foreach (preg_split('/\R/', $voteText) as $ln) { $ln = trim($ln); if ($ln === '') continue; $pp = array_map('trim', explode('|', $ln, 2)); $votes[] = ['label'=>$pp[0], 'url'=>$pp[1] ?? '']; }
$sk = []; foreach (($d['skins'] ?? []) as $k => $e) if (!empty($e['path']) && is_file(ROOT.'/'.$e['path'])) $sk[$k] = ['url'=>asset($e['path']), 'kind'=>$e['kind']];
?>
<?php
$spOut = [];
foreach (($d['staff_profiles'] ?? []) as $k => $pf) {
    $spOut[$k] = $pf;
    $spOut[$k]['banner_url'] = (!empty($pf['banner']) && is_file(ROOT.'/'.$pf['banner'])) ? asset($pf['banner']) : '';
}
?>
<script>window.RULES=<?= json_encode(['sections'=>rules_sections(), 'icons'=>array_keys(rules_icons())], JSON_HEX_TAG|JSON_HEX_AMP|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>;window.PEOPLE=<?= json_encode(['staff'=>$groups, 'vote'=>$votes, 'skins'=>$sk, 'profiles'=>$spOut, 'home'=>$g('home_skin_name','Steve')], JSON_HEX_TAG|JSON_HEX_AMP|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>;</script>
<div class="card"><h2>Home page author &amp; skin</h2><p class="sub">Edit the home page news author name and the Minecraft character shown next to it. Type a Minecraft name, or upload your own 64x64 skin PNG / image.</p>
  <div class="img"><canvas id="hs_c" class="thumb tall" width="64" height="128"></canvas>
    <div style="flex:1">
    <div class="grid2">
      <label class="f" style="margin-top:0">Home News Author Name<input type="text" id="hs_author_mirror" maxlength="32" value="<?= e($d['texts']['news_author'] ?? $fields['news_author']['d']) ?>"><small>Displayed as the post author on the Home page.</small></label>
      <label class="f" style="margin-top:0">Skin Minecraft Username<input type="text" name="home_skin_name" id="hs_name" maxlength="16" value="<?= e($g('home_skin_name','Steve')) ?>"><small>Fetches 3D skin if no custom image is uploaded.</small></label>
    </div>
    <label class="drop" style="display:block;margin-top:10px"><span id="hs_lab">Upload a skin</span><input type="file" id="hs_file" accept="image/*"></label>
    <label class="f">Or paste a skin link<input type="text" id="hs_url" placeholder="https://.../skin.png" autocomplete="off"><small>A direct link to the skin image (ends in .png). It is saved on your site when you press Save.</small></label>
    <label class="reset"><input type="checkbox" name="skin_reset[__home]" value="1" id="hs_reset"> Remove my skin, use the name above</label></div></div></div>
<div class="card"><h2>Staff team</h2><p class="sub">Add ranks and players. Click the upload icon next to a player to give them a custom skin. Without one, the Minecraft name is used.</p>
  <div id="staff-ui"></div><button type="button" class="btn ghost sm" id="add-rank"><i class="fa-solid fa-plus"></i> Add rank</button>
  <input type="hidden" name="tx[staff_list]" id="staff_list"></div>
<div class="card"><h2>Vote buttons</h2><p class="sub">Add your own vote links. Each button needs a name and a full link (https://...). On the website they lift slightly when the mouse is over them.</p>
  <div id="vote-ui"></div><button type="button" class="btn ghost sm" id="add-vote"><i class="fa-solid fa-plus"></i> Add vote link</button>
  <input type="hidden" name="tx[vote_links]" id="vote_links"></div>
</section>

<section data-p="text" hidden>
<div class="card"><h2>Page text</h2><p class="sub">Edit every text on your site (staff and vote buttons have their own tab). Open a section, change the text and press Save. Use <code>{site_name}</code> to insert your site name automatically.</p>
<?php $cur = null; foreach ($fields as $k => $f): if (in_array($k, ['staff_list','vote_links'], true) || strpos($k, 'rules_') === 0 || in_array($k, ['footer_play_title','footer_play_text'], true)) continue;
  if ($f['g'] !== $cur) { if ($cur !== null) echo '</div></details>'; $cur = $f['g']; echo '<details class="acc"><summary>'.e($cur).'</summary><div class="accb">'; }
  $val = $d['texts'][$k] ?? $f['d']; ?>
  <label class="f"><?= e($f['l']) ?>
  <?php if ($f['t'] === 'text'): ?><input type="text" name="tx[<?= e($k) ?>]" value="<?= e($val) ?>">
  <?php else: ?><textarea name="tx[<?= e($k) ?>]" rows="<?= in_array($k,['news_body','rules_intro']) ? 9 : 7 ?>"><?= e($val) ?></textarea><?php endif; ?>
  <?php if (!empty($f['h'])) echo '<small>'.e($f['h']).'</small>'; ?></label>
<?php endforeach; if ($cur !== null) echo '</div></details>'; ?>
  <label class="reset" style="margin-top:14px"><input type="checkbox" name="reset_texts" value="1"> Restore ALL texts to the original</label></div>
</section>

<section data-p="extras" hidden>
<div class="card"><h2>Show or hide parts of the website</h2><p class="sub">Switch things on or off. Hidden parts are simply not shown to visitors.</p>
  <?php tog('show_news','Home page news post','The big announcement card on the home page.', $g('show_news',true), false);
        tog('show_nav_rules','Menu: Rules','', $g('show_nav_rules',true), false); tog('show_nav_vote','Menu: Vote','', $g('show_nav_vote',true), false);
        tog('show_nav_store','Menu: Store','', $g('show_nav_store',true), false); tog('show_nav_staff','Menu: Staff','', $g('show_nav_staff',true), false);
        tog('show_footer_play','Footer: Play Now column','', $g('show_footer_play',true), false); tog('show_footer_links','Footer: Links column','', $g('show_footer_links',true), false);
        tog('show_footer_store','Footer: Store column','', $g('show_footer_store',true), false); ?>
  <label class="f">Footer "Play Now" title<input type="text" name="tx[footer_play_title]" value="<?= e($d['texts']['footer_play_title'] ?? $fields['footer_play_title']['d']) ?>"></label>
  <label class="f">Footer "Play Now" text<textarea name="tx[footer_play_text]" rows="3"><?= e($d['texts']['footer_play_text'] ?? $fields['footer_play_text']['d']) ?></textarea><small>The small text at the bottom of every page, under the title. Use <code>{site_name}</code> to insert your site name.</small></label>
  <label class="f">News post link<input type="text" name="news_link" value="<?= e($g('news_link','')) ?>" placeholder="https://..."><small>Where the news post goes when clicked. Leave empty for no link.</small></label></div>

<div class="card"><h2>Announcement bar</h2><p class="sub">A colored bar at the very top of every page. Great for events and news.</p>
  <?php tog('announce_on','Show announcement bar','', $g('announce_on',false), false); ?>
  <label class="f">Text<input type="text" name="announce_text" value="<?= e($g('announce_text','')) ?>" placeholder="Double XP weekend is live!"></label>
  <label class="f">Link (optional)<input type="text" name="announce_link" value="<?= e($g('announce_link','')) ?>" placeholder="https://..."></label>
  <div class="pick" style="margin-top:12px"><label>Bar color<input type="color" name="announce_bg" value="<?= e($g('announce_bg','#19D3DA')) ?>"></label><label>Text color<input type="color" name="announce_fg" value="<?= e($g('announce_fg','#021A1C')) ?>"></label></div></div>

<div class="card"><h2>Maintenance mode</h2><p class="sub">While ON, every page of the website (even for you) shows a centered 404 page with your title and message below it. Only /admin keeps working.</p>
  <?php tog('maintenance','Turn on maintenance mode','', $g('maintenance',false), false); ?>
  <label class="f">Title<input type="text" name="maint_title" value="<?= e($g('maint_title','We will be back soon')) ?>"></label>
  <label class="f">Message<textarea name="maint_text" rows="3"><?= e($g('maint_text','The website is being updated. Please check back in a little while.')) ?></textarea></label></div>

<div class="card"><h2>Website Animations &amp; Button Effects (Public Site)</h2><p class="sub">Turn individual animations on or off for your main website visitors. Preview updates immediately.</p>
  <?php tog('fx_web_btn_shine','Button Shine Sweep &amp; Hover Lift','Glossy light sweep and subtle lift when hovering over Play, Vote &amp; Store buttons.', $g('fx_web_btn_shine',true), true);
        tog('fx_web_btn_pulse','Store &amp; Vote Button Glow Pulse','Soft breathing theme-color glow around Store &amp; Vote CTA buttons.', $g('fx_web_btn_pulse',true), true);
        tog('fx_web_card_lift','Card &amp; Staff Hover Lift','Smooth elevation and theme border glow when hovering over cards.', $g('fx_web_card_lift',true), true);
        tog('fx_web_logo_float','Floating Header Logo','Gentle up-and-down floating motion on the main server logo.', $g('fx_web_logo_float',true), true);
        tog('fx_web_nav_glow','Navbar Underline Glide','Animated theme underline when hovering or viewing navigation links.', $g('fx_web_nav_glow',true), true);
        tog('fx_web_click_spark','Click Particle Burst','Small theme-colored particle sparks wherever visitors click on the site.', $g('fx_web_click_spark',true), true); ?></div>



<div class="card"><h2>Advanced</h2>
  <?php tog('themed_scrollbar','Colored scrollbar','The page scrollbar uses your main color.', $g('themed_scrollbar',false), false); ?></div>
</section>

<section data-p="admintheme" hidden>
<div class="card"><h2>Admin / Theme</h2><p class="sub">Choose your admin theme. It applies to the login page and every admin tab, and the Earth radar matches it. You can also use the Theme button in the side menu.</p>
  <div class="adm-theme-grid" id="adm-theme-cards"></div>
</div>
<div class="card"><h2>Effects</h2><p class="sub">Only for this admin panel, saved in your browser.</p>
  <label class="switch row"><span><b>Background particles</b><small>Soft moving dots behind the panel.</small></span><input type="checkbox" data-adm-fx="particles"><span class="tg"></span></label>
  <label class="switch row"><span><b>Button shine</b><small>Shimmer and lift when you hover buttons.</small></span><input type="checkbox" data-adm-fx="btnShine"><span class="tg"></span></label>
  <label class="switch row"><span><b>Card lift</b><small>Cards rise slightly on hover.</small></span><input type="checkbox" data-adm-fx="cardLift"><span class="tg"></span></label>
  <label class="switch row"><span><b>Menu glide</b><small>Side menu items slide on hover.</small></span><input type="checkbox" data-adm-fx="navSlide"><span class="tg"></span></label>
  <label class="switch row"><span><b>Click ripple</b><small>A small ring where you click.</small></span><input type="checkbox" data-adm-fx="clickRipple"><span class="tg"></span></label>
  <label class="switch row"><span><b>Save button pulse</b><small>The save button gently glows.</small></span><input type="checkbox" data-adm-fx="savePulse"><span class="tg"></span></label>
</div>
</section>

<section data-p="account" hidden>
<div class="card danger-zone"><h2>Reset website</h2><p class="sub">Brings your website back to exactly how it was when you first uploaded it: all colors, texts, images and settings. Cannot be undone.</p>
  <button type="button" class="btn danger" onclick="if(confirm('Restore the website to the original? All your changes will be lost.')){dirty=false;document.getElementById('rf').submit()}">Reset to original</button></div>
<div class="card"><h2>Login details</h2><p class="sub">Your username and password live in one simple file:</p>
  <p><code>admin/password.php</code></p>
  <p class="sub">Open it in the panel File Manager, change <code>'user'</code> and <code>'pass'</code>, and save. No need to touch anything else.</p></div>
</section>

<div class="save"><button class="btn" id="sv">Save changes</button><button type="button" class="btn ghost" onclick="location.reload()" title="Throw away changes you have not saved">Undo unsaved</button></div>
</form>
<form method="post" id="rf" hidden><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="do_reset" value="1"></form>
<aside><div class="sticky"><div class="pvh"><b>Live preview</b><span class="pv-ctrls"><span class="pv-modes" role="group" aria-label="Preview view mode"><button type="button" class="pv-mbtn on" data-pvmode="mobile" title="Mobile view"><i class="fa-solid fa-mobile-screen-button"></i></button><button type="button" class="pv-mbtn" data-pvmode="pc" title="PC desktop view"><i class="fa-solid fa-desktop"></i></button></span><select id="pg"><option value="/">Home</option><option value="/rules/">Rules</option><option value="/staff/">Staff</option><option value="/vote/">Vote</option></select> <a href="#" id="rl" title="Reload preview">↻</a></span></div><div class="pv-stage is-mobile" id="pv-stage"><iframe id="pv" src="/"></iframe></div></div></aside></main></div>
<script>
const $=id=>document.getElementById(id), pv=$('pv'), pg=$('pg'); let t;
function url(){return pg.value+'?pv='+Date.now();}
function collect(){const o={};document.querySelectorAll('[data-pv]').forEach(i=>{o[i.name]=i.type==='checkbox'?(i.checked?1:0):i.value;});return o;}
function push(){ $('h1').textContent=$('primary_color').value.toUpperCase(); $('h2').textContent=$('bg_color').value.toUpperCase();
  clearTimeout(t); t=setTimeout(()=>{document.cookie='tome_pvset='+encodeURIComponent(JSON.stringify(collect()))+';path=/;max-age=600;SameSite=Strict'; pv.src=url();},400); }
document.querySelectorAll('[data-pv]').forEach(i=>i.addEventListener('input',push)); push();
document.querySelectorAll('.chip').forEach(c=>c.onclick=()=>{ $('primary_color').value=c.dataset.a; $('bg_color').value=c.dataset.b; document.querySelectorAll('.chip').forEach(x=>x.classList.remove('on')); c.classList.add('on'); push(); });
document.querySelectorAll('input[type=file]').forEach(i=>i.addEventListener('change',()=>{ const f=i.files[0]; if(f){ if(i.dataset.t&&$(i.dataset.t))$(i.dataset.t).src=URL.createObjectURL(f); i.parentNode.firstChild.textContent=f.name; } }));
$('rl').onclick=e=>{e.preventDefault(); pv.src=url();}; pg.onchange=()=>pv.src=url();
(function(){
  const stage=$('pv-stage'), btns=document.querySelectorAll('.pv-mbtn');
  function applyPvMode(m){
    const isPc=(m==='pc');
    stage.classList.toggle('is-pc',isPc);
    stage.classList.toggle('is-mobile',!isPc);
    btns.forEach(b=>b.classList.toggle('on',b.dataset.pvmode===m));
    if(isPc){
      const w=stage.clientWidth||380;
      const targetW=1280;
      const sc=Math.min(1, w/targetW);
      pv.style.width=targetW+'px';
      pv.style.height=Math.round((stage.clientHeight||640)/sc)+'px';
      pv.style.transform='scale('+sc+')';
      pv.style.transformOrigin='top left';
    }else{
      pv.style.width='';
      pv.style.height='';
      pv.style.transform='';
      pv.style.transformOrigin='';
    }
    try{localStorage.setItem('adm_pv_mode',m);}catch(e){}
  }
  btns.forEach(b=>b.onclick=()=>applyPvMode(b.dataset.pvmode));
  window.addEventListener('resize',()=>{if(stage.classList.contains('is-pc'))applyPvMode('pc');});
  let saved='mobile'; try{saved=localStorage.getItem('adm_pv_mode')||'mobile';}catch(e){}
  applyPvMode(saved);
})();

(function(){
const D=window.PEOPLE||{staff:[],vote:[],skins:{},home:'Steve'}, $=id=>document.getElementById(id);
const key=n=>String(n).toLowerCase().replace(/[^a-z0-9_]/g,''), clean=n=>String(n).replace(/[^A-Za-z0-9_ ]/g,'').trim();
const hex6=c=>{c=String(c||'#ffffff');if(/^#[0-9a-f]{3}$/i.test(c))c='#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return /^#[0-9a-f]{6}/i.test(c)?c.slice(0,7):'#ffffff'};
const load=src=>new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.onerror=()=>r(null);i.src=src});
const isSkin=im=>im.width%64===0&&(im.height===im.width||im.height*2===im.width);
async function drawHead(cv,src,kind){const c=cv.getContext('2d');c.imageSmoothingEnabled=false;c.clearRect(0,0,cv.width,cv.height);const im=await load(src);if(!im)return;
 if(kind==='skin'){const f=im.width/64;c.drawImage(im,8*f,8*f,8*f,8*f,0,0,cv.width,cv.height);c.drawImage(im,40*f,8*f,8*f,8*f,0,0,cv.width,cv.height)}else c.drawImage(im,0,0,cv.width,cv.height)}
async function drawBody(cv,src,kind){const c=cv.getContext('2d');c.imageSmoothingEnabled=false;c.clearRect(0,0,cv.width,cv.height);const im=await load(src);if(!im)return;
 if(kind==='skin'){const f=im.width/64,s=cv.width/16,leg=im.height*2===im.width;
  const P=(sx,sy,w,h,dx,dy,fl)=>{c.save();if(fl){c.translate((dx+w)*s,dy*s);c.scale(-1,1);c.drawImage(im,sx*f,sy*f,w*f,h*f,0,0,w*s,h*s)}else c.drawImage(im,sx*f,sy*f,w*f,h*f,dx*s,dy*s,w*s,h*s);c.restore()};
  P(8,8,8,8,4,0);P(40,8,8,8,4,0);P(20,20,8,12,4,8);P(44,20,4,12,0,8);leg?P(44,20,4,12,12,8,true):P(36,52,4,12,12,8);P(4,20,4,12,4,20);leg?P(4,20,4,12,8,20,true):P(20,52,4,12,8,20)}
 else{const r=Math.min(cv.width/im.width,cv.height/im.height),w=im.width*r,h=im.height*r;c.drawImage(im,(cv.width-w)/2,(cv.height-h)/2,w,h)}}
const head=n=>'https://mc-heads.net/avatar/'+encodeURIComponent(clean(n)||'Steve')+'/64';
const kindOf=(file)=>new Promise(r=>{const u=URL.createObjectURL(file);load(u).then(im=>r({u,kind:im&&isSkin(im)?'skin':'img'}))});

/* ---- home skin ---- */
let hsUrl=null,hsKind=null;const hs=D.skins['__home'];
function hsDraw(){const nm=$('hs_name').value||'Steve';if(hsUrl)drawBody($('hs_c'),hsUrl,hsKind);else if(hs&&!$('hs_reset').checked)drawBody($('hs_c'),hs.url,hs.kind);else drawBody($('hs_c'),'https://mc-heads.net/body/'+encodeURIComponent(nm)+'/left.png','img')}
$('hs_name').addEventListener('input',()=>{clearTimeout(window._hsT);window._hsT=setTimeout(hsDraw,400)});
const authMir=$('hs_author_mirror'), authTx=document.querySelector('input[name="tx[news_author]"]');
if(authMir && authTx){
  authMir.addEventListener('input',()=>{
    authTx.value=authMir.value;
    const cleanMc=authMir.value.replace(/[^A-Za-z0-9_]/g,'').slice(0,16);
    if(cleanMc && ($('hs_name').value==='Steve' || $('hs_name').dataset.linked==='1')){
      $('hs_name').value=cleanMc; $('hs_name').dataset.linked='1';
      clearTimeout(window._hsT);window._hsT=setTimeout(hsDraw,400);
    }
  });
  authTx.addEventListener('input',()=>{ authMir.value=authTx.value; });
}
$('hs_reset').addEventListener('change',()=>{hsUrl=null;$('hs_file').value='';$('hs_url').value='';$('hs_lab').textContent='Upload a skin';hsDraw()});
$('hs_file').addEventListener('change',async e=>{const f=e.target.files[0];if(!f)return;const r=await kindOf(f);hsUrl=r.u;hsKind=r.kind;$('hs_reset').checked=false;$('hs_lab').textContent=f.name;hsDraw()});
$('hs_url').addEventListener('input',()=>{clearTimeout(window._hsU);window._hsU=setTimeout(async()=>{const u=$('hs_url').value.trim();if(!u){hsUrl=null;hsDraw();return}const im=await load(u);if(!im)return;hsUrl=u;hsKind=isSkin(im)?'skin':'img';$('hs_reset').checked=false;hsDraw()},500)});
hsDraw();

/* ---- staff ---- */
const sUI=$('staff-ui');
function playerEl(name, rankName, pIdx){
  const wrap=document.createElement('div');
  wrap.style.cssText='background:rgba(255,255,255,.025);border:1px solid var(--line);border-radius:10px;padding:8px;margin-bottom:8px;';
  const row=document.createElement('div');row.className='pl';row.style.marginBottom='0';
  row.innerHTML='<canvas class="face" width="40" height="40"></canvas>'
    +'<input type="text" class="t nm" placeholder="Minecraft name" maxlength="32">'
    +'<button type="button" class="x det" title="Edit Profile Banner & About"><i class="fa-solid fa-id-card"></i></button>'
    +'<label class="up" title="Upload a custom skin"><i class="fa-solid fa-upload"></i><input type="file" accept="image/*" hidden></label>'
    +'<button type="button" class="x lk" title="Use a skin from a link"><i class="fa-solid fa-link"></i></button>'
    +'<button type="button" class="x rs" title="Remove custom skin"><i class="fa-solid fa-rotate-left"></i></button>'
    +'<button type="button" class="x del" title="Remove player"><i class="fa-solid fa-xmark"></i></button>';

  const kSlot = key((rankName||'') + '_' + name + '_' + (pIdx||0));
  const kRankBase = key((rankName||'') + '_' + name);
  const kBase = key(name);
  const pf = (D.profiles && (D.profiles[kSlot] || D.profiles[kRankBase] || D.profiles[kBase])) || {};

  const drawer=document.createElement('div');
  drawer.style.cssText='margin-top:10px;padding-top:10px;border-top:1px dashed var(--line);display:none;gap:8px;flex-direction:column;';
  drawer.innerHTML=`
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <img class="sp-bprev" src="${pf.banner_url || '<?= asset(s('hero_bg')) ?>'}" style="width:110px;height:46px;object-fit:cover;border-radius:6px;border:1px solid var(--line);background:#111;">
      <label class="btn ghost sm" style="cursor:pointer;margin:0;"><i class="fa-solid fa-image"></i> Upload Top Banner<input type="file" class="sp-bfi" accept="image/*" hidden></label>
      <label style="font-size:12px;opacity:.75;display:inline-flex;align-items:center;gap:5px;"><input type="checkbox" class="sp-brst"> Reset Banner</label>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
      <input type="text" class="t sp-dc" placeholder="Discord (e.g. user)" value="${(pf.discord||'').replace(/"/g,'&quot;')}">
      <input type="text" class="t sp-reg" placeholder="Registered (e.g. 1 months ago)" value="${(pf.registered||'1 months ago').replace(/"/g,'&quot;')}">
      <input type="text" class="t sp-seen" placeholder="Last Seen (e.g. Online)" value="${(pf.last_seen||'Online').replace(/"/g,'&quot;')}">
      <input type="text" class="t sp-foc" placeholder="Role Focus (e.g. Server Owner)" value="${(pf.focus||'').replace(/"/g,'&quot;')}">
    </div>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:6px 10px;background:rgba(255,255,255,.03);border:1px solid var(--line);border-radius:8px;">
      <span style="font-size:12.5px;font-weight:600;">Show Staff Message Box</span>
      <label class="switch" style="margin:0;"><input type="checkbox" class="sp-show-msg" ${pf.show_msg !== false ? 'checked' : ''}><span class="tg"></span></label>
    </div>
    <textarea class="t sp-bio" rows="2" placeholder="Write staff message shown in profile GUI...">${pf.bio||''}</textarea>
  `;

  wrap.appendChild(row);
  wrap.appendChild(drawer);

  row.querySelector('.det').onclick=()=>{
    const open = drawer.style.display === 'none';
    drawer.style.display = open ? 'flex' : 'none';
  };


  const bFi = drawer.querySelector('.sp-bfi');
  const bPrev = drawer.querySelector('.sp-bprev');
  bFi.addEventListener('change', ()=>{
    if (bFi.files && bFi.files[0]) bPrev.src = URL.createObjectURL(bFi.files[0]);
  });

  const nm=row.querySelector('.nm'),cv=row.querySelector('.face'),fi=row.querySelector('input[type=file]');
  nm.value=name||'';row._srv=D.skins[kSlot]||D.skins[kRankBase]||D.skins[kBase]||null;row._file=null;row._reset=false;
  const draw=()=>{if(row._file)drawHead(cv,row._file.u,row._file.kind);else if(row._srv&&!row._reset)drawHead(cv,row._srv.url,row._srv.kind);else drawHead(cv,head(nm.value),'img')};
  nm.addEventListener('input',()=>{if(row._srv&&key(nm.value)!==row._key){row._srv=null}clearTimeout(row._t);row._t=setTimeout(draw,400);ser()});row._key=key(name);
  fi.addEventListener('change',async()=>{const f=fi.files[0];if(!f)return;row._file=await kindOf(f);row._reset=false;draw()});
  row._url='';row.querySelector('.lk').onclick=async()=>{const u=prompt('Paste a link to the skin image (https://...png). Leave empty to cancel.',row._url||'');if(!u||!u.trim())return;row._url=u.trim();fi.value='';const im=await load(row._url);row._file={u:row._url,kind:im&&isSkin(im)?'skin':'img'};row._reset=false;draw();ser()};
  row.querySelector('.rs').onclick=()=>{row._url='';fi.value='';row._file=null;row._reset=!!row._srv||row._reset;if(row._srv)row._reset=true;draw();ser()};
  row.querySelector('.del').onclick=()=>{wrap.remove();ser()};
  wrap._row=row; wrap._drawer=drawer; row._fi=fi; row._nm=nm; draw();
  return wrap;
}
function rankEl(r){const el=document.createElement('div');el.className='rank';
 el.innerHTML='<div class="rhead"><input type="color" class="rc"><input type="text" class="t rn" placeholder="Rank name"><button type="button" class="x rdel" title="Remove this rank"><i class="fa-solid fa-trash"></i></button></div><div class="players"></div><button type="button" class="btn ghost sm addp"><i class="fa-solid fa-plus"></i> Add player</button>';
 el.querySelector('.rc').value=hex6(r.color);el.querySelector('.rn').value=r.name||'';const box=el.querySelector('.players');(r.players||[]).forEach((p,idx)=>box.appendChild(playerEl(p, r.name, idx)));
 el.querySelector('.addp').onclick=()=>{const p=playerEl('', el.querySelector('.rn').value, box.children.length);box.appendChild(p);p._nm.focus()};el.querySelector('.rdel').onclick=()=>{if(confirm('Remove this rank and its players?')){el.remove();ser()}};return el}
D.staff.forEach(r=>sUI.appendChild(rankEl(r)));
$('add-rank').onclick=()=>{const e=rankEl({name:'New rank',color:'#19d3da',players:[]});sUI.appendChild(e);e.querySelector('.rn').select()};

/* ---- vote ---- */
const vUI=$('vote-ui');
function voteEl(v){const row=document.createElement('div');row.className='vr';row.innerHTML='<input type="text" class="t vl" placeholder="Button text, e.g. Vote on site 1"><input type="text" class="t vu" placeholder="https://..."><button type="button" class="x" title="Remove"><i class="fa-solid fa-xmark"></i></button>';
 row.querySelector('.vl').value=v.label||'';row.querySelector('.vu').value=v.url||'';row.querySelector('.x').onclick=()=>{row.remove();ser()};return row}
D.vote.forEach(v=>vUI.appendChild(voteEl(v)));$('add-vote').onclick=()=>{const e=voteEl({label:'VOTE #'+(vUI.children.length+1),url:''});vUI.appendChild(e);e.querySelector('.vu').focus()};

/* ---- write back to hidden fields ---- */
function ser(){let s=[];sUI.querySelectorAll('.rank').forEach(r=>{const n=r.querySelector('.rn').value.replace(/[\r\n|]/g,' ').trim()||'Rank';s.push('## '+n+' | '+r.querySelector('.rc').value.toUpperCase());r.querySelectorAll('.pl').forEach(p=>{const v=clean(p._nm.value);if(v)s.push(v)});s.push('')});
 $('staff_list').value=s.join('\n').trim();
 $('vote_links').value=[...vUI.querySelectorAll('.vr')].map(r=>{const l=r.querySelector('.vl').value.replace(/[\r\n|]/g,' ').trim(),u=r.querySelector('.vu').value.trim();return u?(l||'Vote')+' | '+u:''}).filter(Boolean).join('\n')}
document.querySelector('[data-p=people]').addEventListener('input',ser);ser();
$('f').addEventListener('submit',()=>{ser();
 document.querySelectorAll('.sp-dyn').forEach(el=>el.remove());
 sUI.querySelectorAll('.rank').forEach(r=>{
   const rName=(r.querySelector('.rn').value.replace(/[\r\n|]/g,' ').trim()||'Rank');
   let pIdx=0;
   r.querySelectorAll('.pl').forEach(p=>{
     const nmVal=clean(p._nm.value);
     if(!nmVal) return;
     const k=key(rName+'_'+nmVal+'_'+pIdx);
     pIdx++;
     if(p._file&&k&&p._fi.files&&p._fi.files[0]){p._fi.disabled=false;p._fi.name='skinf['+k+']'}else p._fi.disabled=true;
     if(p._reset&&k){const h=document.createElement('input');h.type='hidden';h.className='sp-dyn';h.name='skin_reset['+k+']';h.value='1';$('f').appendChild(h)}
     if(p._url&&k&&!p._reset&&!p._fi.files[0]){const h=document.createElement('input');h.type='hidden';h.className='sp-dyn';h.name='skinurl['+k+']';h.value=p._url;$('f').appendChild(h)}
     const wrap=p.parentElement, dr=wrap._drawer;
     if(!dr) return;
     const bFi=dr.querySelector('.sp-bfi');
     if(bFi && bFi.files && bFi.files[0]){ bFi.disabled=false; bFi.name='sp_banner['+k+']'; } else if(bFi){ bFi.disabled=true; }
     if(dr.querySelector('.sp-brst').checked){
       const h=document.createElement('input');h.type='hidden';h.className='sp-dyn';h.name='sp_banner_reset['+k+']';h.value='1';$('f').appendChild(h);
     }
     const dc=dr.querySelector('.sp-dc').value.trim();
     const reg=dr.querySelector('.sp-reg').value.trim();
     const seen=dr.querySelector('.sp-seen').value.trim();
     const foc=dr.querySelector('.sp-foc').value.trim();
     const bio=dr.querySelector('.sp-bio').value.trim();
     const showMsg=dr.querySelector('.sp-show-msg').checked?'1':'0';
     [['discord',dc],['registered',reg||'1 months ago'],['last_seen',seen||'Online'],['focus',foc],['bio',bio],['show_msg',showMsg]].forEach(([fKey,val])=>{
       const h=document.createElement('input');h.type='hidden';h.className='sp-dyn';h.name='sp['+k+']['+fKey+']';h.value=val;$('f').appendChild(h);
     });
   });
 });
 if($('hs_file').files && $('hs_file').files[0]){ $('hs_file').disabled=false; $('hs_file').name='skinf[__home]'; } else { $('hs_file').disabled=true; }
 if(!$('hs_file').files[0]&&$('hs_url').value.trim()&&!$('hs_reset').checked){const h=document.createElement('input');h.type='hidden';h.name='skinurl[__home]';h.value=$('hs_url').value.trim();$('f').appendChild(h)}});
})();


/* ---- rules ---- */
(function(){
const R=window.RULES||{sections:[],icons:[]},U=$('rules-ui'),I={cube:'Cube',discord:'Discord',shield:'Shield',gavel:'Gavel',scale:'Scales',user:'Person shield',chat:'Chat',star:'Star',ban:'Ban',heart:'Heart',bolt:'Bolt',flag:'Flag',cart:'Cart',game:'Game',crown:'Crown',lock:'Lock',fire:'Fire',book:'Book'};
const ser=()=>{$('rules_sections').value=JSON.stringify([...U.querySelectorAll('.rsec')].map(s=>({nav:s.querySelector('.sn').value.trim()||'SECTION',title:s.querySelector('.st').value.trim()||'Rules',icon:s.querySelector('.si').value,intro:s.querySelector('.sin').value,note:s.querySelector('.sno').value,rules:[...s.querySelectorAll('.rr .rt')].map(i=>i.value.trim()).filter(Boolean)})))};
const mv=(el,d)=>{const sib=d<0?el.previousElementSibling:el.nextElementSibling;if(!sib||!sib.matches(el.className.split(' ').map(c=>'.'+c).join('')))return;d<0?el.parentNode.insertBefore(el,sib):el.parentNode.insertBefore(sib,el);ser()};
function ruleEl(v,focusNext){const r=document.createElement('div');r.className='rr';
 r.innerHTML='<input type="text" class="t rt" placeholder="Write a rule..." maxlength="600"><button type="button" class="x up1" title="Move up"><i class="fa-solid fa-arrow-up"></i></button><button type="button" class="x dn1" title="Move down"><i class="fa-solid fa-arrow-down"></i></button><button type="button" class="x del" title="Delete rule"><i class="fa-solid fa-xmark"></i></button>';
 const i=r.querySelector('.rt');i.value=v||'';r.querySelector('.up1').onclick=()=>mv(r,-1);r.querySelector('.dn1').onclick=()=>mv(r,1);r.querySelector('.del').onclick=()=>{r.remove();ser()};
 i.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const n=ruleEl('');r.after(n);n.querySelector('.rt').focus();ser()}});return r}
function secEl(s){const el=document.createElement('div');el.className='rsec rank';
 el.innerHTML='<div class="rhead"><select class="si big" style="width:auto;margin:0" title="Icon"></select><input type="text" class="t st" style="margin:0;flex:1;font-weight:700" placeholder="Section title (shown on the page)" maxlength="120"><button type="button" class="x su" title="Move up"><i class="fa-solid fa-arrow-up"></i></button><button type="button" class="x sd" title="Move down"><i class="fa-solid fa-arrow-down"></i></button><button type="button" class="x rdel" title="Delete section"><i class="fa-solid fa-trash"></i></button></div>'
 +'<label class="f" style="margin-top:0">Side menu name<input type="text" class="sn" maxlength="60" placeholder="e.g. MINECRAFT SERVER"></label><label class="f">Short intro line (optional)<input type="text" class="sin" maxlength="600"></label>'
 +'<div class="f" style="margin-top:12px"><b style="font-size:13px">Rules</b></div><div class="rlist" style="margin-top:6px"></div><button type="button" class="btn ghost sm addr"><i class="fa-solid fa-plus"></i> Add rule</button>'
 +'<label class="f">Note at the end (optional)<input type="text" class="sno" maxlength="600"></label><small style="display:block;margin-top:8px;opacity:.7">Tip: <code>[[text]]</code> colors a word in your main color, <code>**text**</code> makes it bold.</small>';
 const si=el.querySelector('.si');R.icons.forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=I[k]||k;si.appendChild(o)});
 si.value=R.icons.includes(s.icon)?s.icon:'scale';el.querySelector('.st').value=s.title||'';el.querySelector('.sn').value=s.nav||'';el.querySelector('.sin').value=s.intro||'';el.querySelector('.sno').value=s.note||'';
 const rl=el.querySelector(".rlist");(s.rules||[]).forEach(x=>rl.appendChild(ruleEl(x)));
 el.querySelector('.addr').onclick=()=>{const n=ruleEl('');rl.appendChild(n);n.querySelector('.rt').focus();ser()};
 el.querySelector('.su').onclick=()=>mv(el,-1);el.querySelector('.sd').onclick=()=>mv(el,1);
 el.querySelector('.rdel').onclick=()=>{if(confirm('Delete this whole section and all its rules?')){el.remove();ser()}};return el}
R.sections.forEach(s=>U.appendChild(secEl(s)));
$('add-sec').onclick=()=>{const e=secEl({title:'New section',nav:'NEW SECTION',icon:'scale',rules:['']});U.appendChild(e);e.querySelector('.st').select();ser()};
document.querySelector('[data-p=rules]').addEventListener('input',ser);$('f').addEventListener('submit',ser);ser();
})();

let dirty=false; document.getElementById('f').addEventListener('input',()=>dirty=true); document.getElementById('f').addEventListener('change',()=>dirty=true);
document.getElementById('f').addEventListener('submit',()=>dirty=false); 
window.addEventListener('beforeunload',e=>{ if(dirty){ e.preventDefault(); e.returnValue=''; } });
const tabs=document.querySelectorAll('#tabs button');
const sideEl=document.getElementById('side-nav'), backdropEl=document.getElementById('side-backdrop'), mobOpenBtn=document.getElementById('mob-open'), mobCloseBtn=document.getElementById('mob-close');
function setDrawer(open){
  if(!sideEl||!backdropEl)return;
  const isMob=window.innerWidth<=800;
  sideEl.classList.toggle('open',isMob&&open);
  if(isMob&&open){backdropEl.hidden=false;requestAnimationFrame(()=>backdropEl.classList.add('show'));}
  else{backdropEl.classList.remove('show');setTimeout(()=>{if(!sideEl.classList.contains('open'))backdropEl.hidden=true;},200);}
  if(mobOpenBtn)mobOpenBtn.setAttribute('aria-expanded',String(isMob&&open));
}
if(mobOpenBtn)mobOpenBtn.onclick=()=>setDrawer(!sideEl.classList.contains('open'));
if(mobCloseBtn)mobCloseBtn.onclick=()=>setDrawer(false);
if(backdropEl)backdropEl.onclick=()=>setDrawer(false);
document.addEventListener('keydown',e=>{if(e.key==='Escape')setDrawer(false);});
window.addEventListener('resize',()=>{if(window.innerWidth>800)setDrawer(false);});
function show(n){tabs.forEach(b=>b.classList.toggle('on',b.dataset.tab===n));document.querySelectorAll('section[data-p]').forEach(s=>s.hidden=s.dataset.p!==n);try{sessionStorage.setItem('tab',n)}catch(e){}}
tabs.forEach(b=>b.onclick=()=>{show(b.dataset.tab);setDrawer(false);}); try{show(sessionStorage.getItem('tab')||'theme')}catch(e){}
<?php if($msg): ?>document.cookie='tome_pvset=;path=/;max-age=0'; pv.src='/?s='+Date.now();<?php endif; ?>
</script>
<script src="<?= e($ADMIN_URL) ?>theme.js?v=<?= (int)@filemtime(__DIR__.'/theme.js') ?>"></script>
<script src="<?= e($ADMIN_URL) ?>earth.js?v=<?= (int)@filemtime(__DIR__.'/earth.js') ?>"></script>
</body></html>
